{pkgs}: {
  deps = [
    pkgs.apktool
    pkgs.jdk
  ];
}
