/**
 * Office Suite Express Routes
 * Handles file upload, conversion, PowerPoint and Word generation,
 * Excel AI processing, and text-to-docx export
 */
import { Router, type IRouter } from "express";
import multer from "multer";
import { convertFile, getSupportedConversions } from "../hayo/services/file-converter";
import { generatePresentation } from "../hayo/services/presentation-generator";
import { generateReport } from "../hayo/services/report-generator";
import { callOfficeAI } from "../hayo/providers";

const router: IRouter = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

// GET /api/office/conversions
router.get("/office/conversions", (_req, res) => {
  res.json(getSupportedConversions());
});

// POST /api/office/convert
router.post("/office/convert", upload.single("file"), async (req: any, res: any) => {
  try {
    if (!req.file) return res.status(400).json({ error: "لم يتم إرسال ملف" });
    const from = (req.file.originalname.split(".").pop() || "").toLowerCase();
    const to = (req.body.toFormat || "").toLowerCase();
    if (!to) return res.status(400).json({ error: "يرجى تحديد صيغة الهدف" });
    const result = await convertFile(req.file.buffer, from, to);
    const safeName = req.file.originalname.replace(/\.[^.]+$/, "").replace(/[^a-zA-Z0-9_\u0600-\u06FF\s-]/g, "");
    const filename = `${safeName}.${result.ext}`;
    res.setHeader("Content-Type", result.mime);
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    res.setHeader("Content-Length", result.buffer.length);
    res.send(result.buffer);
  } catch (err: any) {
    res.status(500).json({ error: err.message || "فشل التحويل" });
  }
});

// POST /api/office/generate-pptx
router.post("/office/generate-pptx", async (req: any, res: any) => {
  try {
    const { topic, details, slideCount, style, language } = req.body;
    if (!topic) return res.status(400).json({ error: "يرجى إدخال موضوع العرض" });
    const buf = await generatePresentation(
      topic,
      Math.min(Math.max(parseInt(slideCount) || 10, 5), 20),
      style || "professional",
      language || "ar",
      details || ""
    );
    const filename = `${topic.slice(0, 30)}.pptx`;
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    res.send(buf);
  } catch (err: any) {
    res.status(500).json({ error: err.message || "فشل إنشاء العرض" });
  }
});

// POST /api/office/generate-report
router.post("/office/generate-report", async (req: any, res: any) => {
  try {
    const { topic, details, type, language, pageCount } = req.body;
    if (!topic) return res.status(400).json({ error: "يرجى إدخال موضوع التقرير" });
    const buf = await generateReport(
      topic,
      type || "business",
      language || "ar",
      Math.min(parseInt(pageCount) || 5, 20),
      details || ""
    );
    const filename = `تقرير-${topic.slice(0, 20)}.docx`;
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(filename)}`);
    res.send(buf);
  } catch (err: any) {
    res.status(500).json({ error: err.message || "فشل إنشاء التقرير" });
  }
});

// POST /api/office/process-excel  — Excel AI processing (server-side)
router.post("/office/process-excel", upload.single("file"), async (req: any, res: any) => {
  try {
    if (!req.file) return res.status(400).json({ error: "لم يتم إرسال ملف" });
    const instruction = (req.body.instruction || "").trim();
    if (!instruction) return res.status(400).json({ error: "يرجى إدخال التعليمات" });

    const XLSX = await import("xlsx");
    const wb = XLSX.read(req.file.buffer, { type: "buffer" });
    const sheetName = wb.SheetNames[0];
    const ws = wb.Sheets[sheetName];
    const rawData: any[][] = XLSX.utils.sheet_to_json(ws, { header: 1, defval: "" });

    if (rawData.length < 2) {
      return res.status(400).json({ error: "الملف فارغ أو لا يحتوي بيانات كافية" });
    }

    const headers = (rawData[0] as string[]).map(h => String(h || ""));
    const rows = rawData.slice(1).filter((r: any[]) => r.some((c: any) => c !== "")).slice(0, 500);

    const dataPreview = JSON.stringify({ headers, rows: rows.slice(0, 100) }, null, 2);

    const aiContent = await callOfficeAI(
      `أنت محلل بيانات Excel خبير على مستوى عالمي. مهمتك تنفيذ التعليمات بدقة متناهية.

قواعد صارمة:
- نفّذ التعليمات حرفياً على البيانات المُعطاة
- أضف أعمدة حسابية دقيقة (مجموع، متوسط، نسبة مئوية، فرق، نمو)
- الترتيب: رتب البيانات فعلياً حسب المطلوب
- الحذف: احذف الصفوف/الأعمدة المطلوبة
- التصفية: أعد فقط الصفوف المطابقة للشرط
- القيم الرقمية = أرقام وليس نصوص
- أعد جميع البيانات المعالجة (ليس عينة)
- إذا طُلبت صيغ: احسب النتيجة الفعلية
- أضف صف إجمالي في نهاية البيانات إذا كان منطقياً`,
      `البيانات:\n${dataPreview}\n\nالتعليمات: ${instruction}\n\nأعد JSON فقط:\n{"headers":["عمود1"...],"rows":[[قيمة...]...],"summary":"وصف تفصيلي لما تم تنفيذه"}`,
      8192,
      "claude-sonnet-4-6" as any
    );

    const cleaned = aiContent.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return res.status(500).json({ error: "لم تُعِد AI نتيجة صالحة، حاول مرة أخرى" });

    const parsed = JSON.parse(jsonMatch[0]);
    if (!parsed.headers || !parsed.rows) {
      return res.status(500).json({ error: "تنسيق البيانات المُعادة غير صحيح" });
    }

    // Normalize rows: ensure each row is an array (AI sometimes returns objects)
    const normalizedRows: any[][] = parsed.rows.map((row: any) => {
      if (Array.isArray(row)) return row;
      return parsed.headers.map((h: string) => row[h] ?? "");
    });

    // Generate modified Excel
    const XLSX2 = await import("xlsx");
    const newWb = XLSX2.utils.book_new();
    const data = [parsed.headers, ...normalizedRows];
    XLSX2.utils.book_append_sheet(newWb, XLSX2.utils.aoa_to_sheet(data), "Sheet1");
    const excelBuf: Buffer = XLSX2.write(newWb, { type: "buffer", bookType: "xlsx" });

    res.json({
      headers: parsed.headers,
      rows: normalizedRows,
      summary: parsed.summary || "تمت المعالجة بنجاح",
      xlsxBase64: Buffer.from(excelBuf).toString("base64"),
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || "فشلت المعالجة" });
  }
});

// POST /api/office/text-to-docx — Convert plain text/AI output to DOCX
router.post("/office/text-to-docx", async (req: any, res: any) => {
  try {
    const { text, filename } = req.body;
    if (!text) return res.status(400).json({ error: "يرجى إرسال النص" });

    const { Document, Packer, Paragraph, TextRun, AlignmentType } = await import("docx");
    const lines: string[] = text.split("\n");
    const children: any[] = [];

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) {
        children.push(new Paragraph({ spacing: { after: 80 } }));
      } else if (trimmed.startsWith("## ")) {
        children.push(new Paragraph({
          children: [new TextRun({ text: trimmed.replace(/^##\s+/, ""), bold: true, size: 32, font: "Arial", color: "1a1a2e" })],
          spacing: { before: 400, after: 200 },
        }));
      } else if (trimmed.startsWith("### ")) {
        children.push(new Paragraph({
          children: [new TextRun({ text: trimmed.replace(/^###\s+/, ""), bold: true, size: 26, font: "Arial", color: "374151" })],
          spacing: { before: 250, after: 120 },
        }));
      } else if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
        children.push(new Paragraph({
          children: [new TextRun({ text: "• " + trimmed.substring(2), size: 22, font: "Arial" })],
          spacing: { after: 80 },
          indent: { left: 720 },
        }));
      } else {
        const parts = trimmed.split(/\*\*(.+?)\*\*/g);
        children.push(new Paragraph({
          children: parts.map((p, i) => new TextRun({ text: p, bold: i % 2 === 1, size: 22, font: "Arial" })),
          spacing: { after: 120 },
        }));
      }
    }

    const doc = new Document({ sections: [{ children }] });
    const buf = await Packer.toBuffer(doc);
    const fname = encodeURIComponent((filename || "document") + ".docx");
    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${fname}`);
    res.send(Buffer.from(buf));
  } catch (err: any) {
    res.status(500).json({ error: err.message || "فشل إنشاء الملف" });
  }
});

// POST /api/office/run-tool — AI text tools (no auth required, server-side AI)
router.post("/office/run-tool", async (req: any, res: any) => {
  try {
    const { toolId, text, language, extraOption } = req.body;
    if (!text?.trim()) return res.status(400).json({ error: "يرجى إدخال النص" });

    const lang = language === "ar" ? "العربية" : "الإنجليزية";
    const langLabel = language === "ar" ? "Arabic" : "English";

    const prompts: Record<string, string> = {
      summarize: `لخّص النص التالي بدقة واحتفظ بجميع النقاط الجوهرية والتفاصيل المهمة. قدّم التلخيص بشكل منظم بعناوين فرعية إن أمكن:\n\n${text}`,
      translate: `ترجم النص التالي إلى ${extraOption || (language === "ar" ? "English" : "العربية")} مع الحفاظ التام على التنسيق والمعنى الأصلي:\n\n${text}`,
      grammar: `أصلح جميع الأخطاء النحوية والإملائية والأسلوبية في النص التالي. قدّم النص المُصحَّح فقط:\n\n${text}`,
      email: `اكتب إيميلاً مهنياً احترافياً ${language === "ar" ? "باللغة العربية" : "in English"} بناءً على النقاط التالية. أضف: سطر الموضوع، التحية، المتن المفصّل، الخاتمة، والتوقيع:\n\n${text}`,
      minutes: `حوّل ملاحظات الاجتماع التالية إلى محضر رسمي ${language === "ar" ? "باللغة العربية" : "in English"} يشمل: التاريخ والوقت، قائمة الحضور، جدول الأعمال المفصّل، القرارات المتخذة، الإجراءات المطلوبة مع المسؤول والموعد:\n\n${text}`,
      letter: `اكتب خطاباً رسمياً ${language === "ar" ? "باللغة العربية" : "in English"} بناءً على التفاصيل التالية. اتبع جميع قواعد الخطابات الرسمية:\n\n${text}`,
      contract: `أنشئ عقداً قانونياً ${language === "ar" ? "باللغة العربية" : "in English"} بناءً على التفاصيل التالية. أضف: بنود واضحة، حقوق والتزامات الطرفين، شروط الإنهاء، التوقيعات:\n\n${text}`,
      cv: `أنشئ سيرة ذاتية احترافية ${language === "ar" ? "باللغة العربية" : "in English"} بناءً على البيانات التالية. اجعلها منظمة مع أقسام واضحة (معلومات شخصية، الخبرات، التعليم، المهارات):\n\n${text}`,
      proposal: `اكتب مقترح مشروع احترافي ${language === "ar" ? "باللغة العربية" : "in English"} يشمل: ملخص تنفيذي، الأهداف، المنهجية، الجدول الزمني، الميزانية، والتوصيات:\n\n${text}`,
      invoice: `أنشئ فاتورة احترافية ${language === "ar" ? "باللغة العربية" : "in English"} بناءً على البيانات التالية. أضف: رقم الفاتورة، التاريخ، بيانات العميل، الخدمات/المنتجات، الأسعار، الإجمالي:\n\n${text}`,
    };

    const systemPrompts: Record<string, string> = {
      summarize: `You are an expert summarizer. Create comprehensive, well-structured summaries in ${langLabel}.`,
      translate: `You are a professional translator. Translate accurately while preserving tone, style, and formatting.`,
      grammar: `You are a language expert. Fix ALL grammatical, spelling, and stylistic errors. Return ONLY the corrected text.`,
      email: `You are a professional business writer. Create formal, clear, and effective business emails in ${langLabel}.`,
      minutes: `You are a professional meeting secretary. Create formal, structured meeting minutes in ${langLabel}.`,
      letter: `You are an expert in formal correspondence. Write professional formal letters in ${langLabel}.`,
      contract: `You are a legal document specialist. Create professional contracts in ${langLabel} with clear clauses and proper structure.`,
      cv: `You are a CV/Resume expert. Create polished, ATS-friendly resumes in ${langLabel}.`,
      proposal: `You are a business proposal writer. Create detailed, persuasive project proposals in ${langLabel}.`,
      invoice: `You are a financial document specialist. Create clear, professional invoices in ${langLabel}.`,
    };

    const complexTools = ["email", "minutes", "letter", "contract", "cv", "proposal", "invoice"];
    const model = complexTools.includes(toolId) ? "claude-sonnet-4-6" : "claude-haiku-4-5";
    const result = await callOfficeAI(
      systemPrompts[toolId] || `You are a professional writing assistant in ${langLabel}.`,
      prompts[toolId] || text,
      8192,
      model as any
    );

    res.json({ result });
  } catch (err: any) {
    res.status(500).json({ error: err.message || "فشل تنفيذ الأداة" });
  }
});

// POST /api/office/ai-document-chat — Chat with AI about uploaded document content
router.post("/office/ai-document-chat", async (req: any, res: any) => {
  try {
    const { documentText, question, language } = req.body;
    if (!documentText?.trim()) return res.status(400).json({ error: "يرجى رفع مستند أولاً" });
    if (!question?.trim()) return res.status(400).json({ error: "يرجى إدخال سؤال" });

    const lang = language === "ar" ? "العربية" : "الإنجليزية";
    const result = await callOfficeAI(
      `أنت محلل مستندات ذكي. لديك مستند وسيسألك المستخدم أسئلة عنه. أجب بدقة واستند للمحتوى فقط. أجب بـ${lang}.`,
      `المستند:\n---\n${documentText.substring(0, 30000)}\n---\n\nالسؤال: ${question}`,
      4096,
      "claude-sonnet-4-6" as any
    );
    res.json({ answer: result });
  } catch (err: any) {
    res.status(500).json({ error: err.message || "فشل التحليل" });
  }
});

// POST /api/office/smart-template — Generate document from template with AI
router.post("/office/smart-template", async (req: any, res: any) => {
  try {
    const { templateId, fields, language } = req.body;
    if (!templateId) return res.status(400).json({ error: "يرجى اختيار قالب" });

    const lang = language === "ar" ? "العربية" : "الإنجليزية";
    const fieldsStr = Object.entries(fields || {}).map(([k, v]) => `${k}: ${v}`).join("\n");

    const result = await callOfficeAI(
      `أنت كاتب مستندات محترف. أنشئ مستنداً احترافياً بـ${lang} بناءً على القالب والبيانات. اجعله جاهزاً للاستخدام مباشرة.`,
      `القالب: ${templateId}\nالبيانات:\n${fieldsStr}\n\nأنشئ المستند كاملاً ومفصلاً.`,
      8192,
      "claude-sonnet-4-6" as any
    );
    res.json({ result });
  } catch (err: any) {
    res.status(500).json({ error: err.message || "فشل إنشاء المستند" });
  }
});

export default router;
