import { Router, type IRouter } from "express";
import healthRouter from "./health";
import telegramRouter from "./telegram";
import officeRouter from "./office";
import chatStreamRouter from "./chat-stream";
import extractArchiveRouter from "./extract-archive";
import reverseRouter from "./reverse";
import promptFactoryRouter from "./prompt-factory";
import studiesRouter from "./studies";

const router: IRouter = Router();

router.use(healthRouter);
router.use(telegramRouter);
router.use(officeRouter);
router.use(chatStreamRouter);
router.use(extractArchiveRouter);
router.use(reverseRouter);
router.use(promptFactoryRouter);
router.use(studiesRouter);

export default router;
