/**
 * HAYO Super Bot — AI Agent with Inline Keyboard Buttons
 *
 * Navigation flow:
 *   /start → Main Menu (buttons)
 *   📊 تحليل → اختر زوج → اختر إطار → تحليل تلقائي
 *   💻 / 🌍 / etc → يطلب الإدخال → ينفذ
 */

import { Router, type IRouter } from "express";
import Anthropic from "@anthropic-ai/sdk";

const router: IRouter = Router();

// ─── Conversation + Button Session Memory ────────────────────────────────────

const conversationMemory = new Map<string, Anthropic.MessageParam[]>();
const MAX_MEMORY = 20;

interface BotSession {
  step?: "pair" | "tf" | "translate" | "summarize" | "prompt" | "research" | "code" | "app" | "explain";
  pair?: string;
}
const buttonSessions = new Map<string, BotSession>();

function getMemory(key: string): Anthropic.MessageParam[] {
  if (!conversationMemory.has(key)) conversationMemory.set(key, []);
  return conversationMemory.get(key)!;
}
function addToMemory(key: string, msgs: Anthropic.MessageParam[]): void {
  const mem = getMemory(key);
  mem.push(...msgs);
  if (mem.length > MAX_MEMORY) mem.splice(0, mem.length - MAX_MEMORY);
}
function getSession(key: string): BotSession {
  if (!buttonSessions.has(key)) buttonSessions.set(key, {});
  return buttonSessions.get(key)!;
}
function clearSession(key: string): void {
  buttonSessions.set(key, {});
}

// ─── Telegram API ─────────────────────────────────────────────────────────────

type InlineBtn = { text: string; callback_data: string };
type InlineRow = InlineBtn[];

async function tgPost(token: string, method: string, body: Record<string, any>): Promise<any> {
  const r = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  return r.json();
}

function splitMessage(text: string, limit = 4000): string[] {
  const parts: string[] = [];
  while (text.length > limit) {
    let cut = text.lastIndexOf("\n", limit);
    if (cut < limit * 0.5) cut = limit;
    parts.push(text.slice(0, cut));
    text = text.slice(cut).trimStart();
  }
  if (text) parts.push(text);
  return parts;
}

async function sendText(
  token: string,
  chatId: number,
  text: string,
  keyboard?: InlineRow[],
): Promise<void> {
  for (const part of splitMessage(text.trim())) {
    const body: Record<string, any> = {
      chat_id: chatId,
      text: part,
      parse_mode: "HTML",
    };
    if (keyboard) {
      body.reply_markup = { inline_keyboard: keyboard };
    }
    const r = await tgPost(token, "sendMessage", body);
    // If HTML parse fails, retry plain
    if (!r.ok && keyboard) {
      await tgPost(token, "sendMessage", {
        ...body,
        text: part.replace(/<[^>]+>/g, ""),
      });
    } else if (!r.ok) {
      await tgPost(token, "sendMessage", { chat_id: chatId, text: part.replace(/<[^>]+>/g, "") });
    }
  }
}

async function editText(
  token: string,
  chatId: number,
  messageId: number,
  text: string,
  keyboard?: InlineRow[],
): Promise<void> {
  const body: Record<string, any> = {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: "HTML",
  };
  if (keyboard) body.reply_markup = { inline_keyboard: keyboard };
  await tgPost(token, "editMessageText", body).catch(() =>
    sendText(token, chatId, text, keyboard)
  );
}

async function answerCallback(token: string, callbackId: string, text = ""): Promise<void> {
  await tgPost(token, "answerCallbackQuery", { callback_query_id: callbackId, text });
}

async function sendDocument(
  token: string,
  chatId: number,
  filename: string,
  content: string,
  caption?: string,
): Promise<void> {
  const form = new FormData();
  form.append("chat_id", String(chatId));
  form.append("document", new Blob([content], { type: "text/plain" }), filename);
  if (caption) form.append("caption", caption.slice(0, 1024));
  await fetch(`https://api.telegram.org/bot${token}/sendDocument`, { method: "POST", body: form });
}

async function sendTyping(token: string, chatId: number): Promise<void> {
  await tgPost(token, "sendChatAction", { chat_id: chatId, action: "typing" }).catch(() => {});
}

// ─── Keyboards ────────────────────────────────────────────────────────────────

const MAIN_MENU: InlineRow[] = [
  [{ text: "📊 تحليل الأسواق المالية", callback_data: "menu:market" }],
  [
    { text: "💻 بناء تطبيق", callback_data: "menu:app" },
    { text: "🔧 توليد كود", callback_data: "menu:code" },
  ],
  [
    { text: "🌍 ترجمة النصوص", callback_data: "menu:translate" },
    { text: "📝 تلخيص",       callback_data: "menu:summarize" },
  ],
  [
    { text: "⚗️ هندسة Prompt", callback_data: "menu:prompt" },
    { text: "🔬 بحث عميق",    callback_data: "menu:research" },
  ],
  [{ text: "🔄 شرح / تحليل كود", callback_data: "menu:explain" }],
  [
    { text: "🗑️ مسح الذاكرة",  callback_data: "action:clear" },
    { text: "⚙️ الحالة",       callback_data: "action:status" },
  ],
];

const PAIRS_KEYBOARD: InlineRow[] = [
  [
    { text: "🇪🇺🇺🇸 EUR/USD", callback_data: "pair:EUR/USD" },
    { text: "🇬🇧🇺🇸 GBP/USD", callback_data: "pair:GBP/USD" },
  ],
  [
    { text: "🇺🇸🇯🇵 USD/JPY", callback_data: "pair:USD/JPY" },
    { text: "🇬🇧🇯🇵 GBP/JPY", callback_data: "pair:GBP/JPY" },
  ],
  [
    { text: "🥇 XAU/USD (ذهب)", callback_data: "pair:XAU/USD" },
    { text: "₿ BTC/USD",       callback_data: "pair:BTC/USD" },
  ],
  [{ text: "✏️ زوج / رمز مخصص", callback_data: "pair:custom" }],
  [{ text: "◀️ القائمة الرئيسية", callback_data: "action:main" }],
];

function tfKeyboard(pair: string): InlineRow[] {
  return [
    [
      { text: "1 دقيقة",  callback_data: `tf:${pair}:1min` },
      { text: "5 دقائق",  callback_data: `tf:${pair}:5min` },
      { text: "15 دقيقة", callback_data: `tf:${pair}:15min` },
    ],
    [
      { text: "30 دقيقة",   callback_data: `tf:${pair}:30min` },
      { text: "ساعة",       callback_data: `tf:${pair}:1h` },
      { text: "4 ساعات",   callback_data: `tf:${pair}:4h` },
    ],
    [{ text: "◀️ تغيير الزوج", callback_data: "menu:market" }],
  ];
}

const BACK_MAIN: InlineRow[] = [
  [{ text: "◀️ القائمة الرئيسية", callback_data: "action:main" }],
];

const AFTER_ANALYSIS: InlineRow[] = [
  [
    { text: "🔄 تحليل مجدداً",        callback_data: "action:reanalyze" },
    { text: "📊 زوج مختلف",           callback_data: "menu:market" },
  ],
  [{ text: "◀️ القائمة الرئيسية", callback_data: "action:main" }],
];

// ─── Market Analysis ──────────────────────────────────────────────────────────

function smaN(arr: number[], n: number): number {
  if (arr.length < n) return arr.at(-1) ?? 0;
  return arr.slice(-n).reduce((a, b) => a + b, 0) / n;
}
function emaN(arr: number[], n: number): number {
  if (!arr.length) return 0;
  const k = 2 / (n + 1);
  let e = arr[0];
  for (let i = 1; i < arr.length; i++) e = arr[i] * k + e * (1 - k);
  return e;
}
function calcRSI(closes: number[], period = 14): number {
  if (closes.length < period + 1) return 50;
  let g = 0, l = 0;
  for (let i = closes.length - period; i < closes.length; i++) {
    const d = closes[i] - closes[i - 1];
    if (d > 0) g += d; else l -= d;
  }
  const ag = g / period, al = l / period;
  return al === 0 ? 100 : 100 - 100 / (1 + ag / al);
}

// ─── Symbol → Yahoo Finance ticker ───────────────────────────────────────────
function toYahooSymbol(symbol: string): string {
  const map: Record<string, string> = {
    "EUR/USD": "EURUSD=X", "USD/JPY": "USDJPY=X", "GBP/USD": "GBPUSD=X",
    "GBP/JPY": "GBPJPY=X", "USD/CAD": "USDCAD=X", "AUD/USD": "AUDUSD=X",
    "USD/CHF": "USDCHF=X", "NZD/USD": "NZDUSD=X", "EUR/GBP": "EURGBP=X",
    "XAU/USD": "GC=F",     "XAG/USD": "SI=F",     "WTI": "CL=F",
    "BTC/USD": "BTC-USD",  "ETH/USD": "ETH-USD",
  };
  if (map[symbol]) return map[symbol];
  const clean = symbol.replace("/", "");
  // Crypto pattern
  if (symbol.endsWith("/USD") && symbol.length <= 8) return clean.replace("USD", "") + "-USD";
  // Generic forex
  return `${clean}=X`;
}

// ─── Interval → Yahoo Finance interval + range ────────────────────────────────
function toYahooInterval(interval: string): { yInterval: string; range: string } {
  const map: Record<string, { yInterval: string; range: string }> = {
    "1min":  { yInterval: "1m",  range: "1d"  },
    "5min":  { yInterval: "5m",  range: "5d"  },
    "15min": { yInterval: "15m", range: "5d"  },
    "30min": { yInterval: "30m", range: "1mo" },
    "1h":    { yInterval: "60m", range: "1mo" },
    "4h":    { yInterval: "60m", range: "3mo" },
    "1day":  { yInterval: "1d",  range: "1y"  },
  };
  return map[interval] ?? { yInterval: "15m", range: "5d" };
}

// ─── Market Data via Yahoo Finance (FREE — no key, no limits) ─────────────────
async function fetchMarketData(symbol: string, interval: string): Promise<string> {
  try {
    const yahooSym = toYahooSymbol(symbol);
    const { yInterval, range } = toYahooInterval(interval);
    const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(yahooSym)}?interval=${yInterval}&range=${range}`;
    const res = await fetch(url, {
      signal: AbortSignal.timeout(15000),
      headers: { "User-Agent": "Mozilla/5.0" },
    });
    if (!res.ok) return `❌ Yahoo Finance HTTP ${res.status}`;
    const json = await res.json() as any;
    const result = json?.chart?.result?.[0];
    if (!result) return "❌ لا توجد بيانات لهذا الرمز";

    const timestamps: number[]      = result.timestamp ?? [];
    const quote                     = result.indicators.quote[0];
    const rawHighs:  (number|null)[] = quote.high  ?? [];
    const rawLows:   (number|null)[] = quote.low   ?? [];
    const rawCloses: (number|null)[] = quote.close ?? [];

    // Filter nulls (market gaps/weekends)
    const validIdx = rawCloses.map((_,i)=>i).filter(i =>
      rawCloses[i] != null && rawHighs[i] != null && rawLows[i] != null
    );
    if (validIdx.length < 10) return "❌ بيانات غير كافية (السوق مغلق أو رمز غير صحيح)";

    const closes = validIdx.map(i => rawCloses[i] as number);
    const highs  = validIdx.map(i => rawHighs[i]  as number);
    const lows   = validIdx.map(i => rawLows[i]   as number);
    const lastTs = timestamps[validIdx[validIdx.length - 1]];

    const price  = closes.at(-1)!;
    const prev   = closes.at(-2) ?? price;
    const RSI    = calcRSI(closes);
    const SMA20  = smaN(closes, 20);
    const SMA50  = smaN(closes, 50);
    const SMA200 = closes.length >= 200 ? smaN(closes, 200) : null;
    const MACD   = emaN(closes, 12) - emaN(closes, 26);
    const BB_mid = SMA20;
    const BB_std = Math.sqrt(closes.slice(-20).reduce((a,v) => a + Math.pow(v - BB_mid, 2), 0) / 20);
    const d = price > 1000 ? 2 : price > 10 ? 4 : price > 1 ? 5 : 6;

    return JSON.stringify({
      symbol, interval,
      source: "Yahoo Finance (free)",
      datetime_utc: lastTs ? new Date(lastTs * 1000).toISOString() : "N/A",
      price: price.toFixed(d),
      change_pct: ((price - prev) / prev * 100).toFixed(3) + "%",
      RSI: RSI.toFixed(1),
      RSI_signal: RSI < 30 ? "OVERSOLD" : RSI > 70 ? "OVERBOUGHT" : "NEUTRAL",
      MACD: MACD.toFixed(d),
      MACD_signal: MACD > 0 ? "BULLISH" : "BEARISH",
      SMA20: SMA20.toFixed(d), SMA50: SMA50.toFixed(d),
      SMA200: SMA200 ? SMA200.toFixed(d) : "N/A",
      price_vs_SMA20: price > SMA20 ? "ABOVE ↑" : "BELOW ↓",
      price_vs_SMA50: price > SMA50 ? "ABOVE ↑" : "BELOW ↓",
      price_vs_SMA200: SMA200 ? (price > SMA200 ? "ABOVE ↑" : "BELOW ↓") : "N/A",
      BB_upper: (BB_mid + 2 * BB_std).toFixed(d),
      BB_middle: BB_mid.toFixed(d),
      BB_lower: (BB_mid - 2 * BB_std).toFixed(d),
      price_in_BB: price > BB_mid + 2 * BB_std ? "ABOVE_UPPER" : price < BB_mid - 2 * BB_std ? "BELOW_LOWER" : "INSIDE",
      high_20: Math.max(...highs.slice(-20)).toFixed(d),
      low_20: Math.min(...lows.slice(-20)).toFixed(d),
      candles_count: closes.length,
      trend: price > SMA20 && SMA20 > SMA50 ? "UPTREND" : price < SMA20 && SMA20 < SMA50 ? "DOWNTREND" : "SIDEWAYS",
    }, null, 2);
  } catch (err: any) {
    return `❌ خطأ: ${err.message}`;
  }
}

// ─── Tool Definitions ─────────────────────────────────────────────────────────

const HAYO_TOOLS: Anthropic.Tool[] = [
  {
    name: "fetch_market_data",
    description: "جلب بيانات السوق الحقيقية (سعر + مؤشرات تقنية). استخدم دائماً عند تحليل أي زوج أو رمز مالي.",
    input_schema: {
      type: "object",
      properties: {
        symbol: { type: "string", description: "رمز الزوج — EUR/USD أو XAU/USD أو BTC/USD أو AAPL" },
        interval: {
          type: "string",
          enum: ["1min", "5min", "15min", "30min", "1h", "4h", "1day"],
          description: "الإطار الزمني",
        },
      },
      required: ["symbol", "interval"],
    },
  },
  {
    name: "send_file",
    description: "إرسال محتوى كملف. استخدم للكود الطويل (>30 سطر) والمشاريع والتقارير المفصلة.",
    input_schema: {
      type: "object",
      properties: {
        filename: { type: "string", description: "اسم الملف مع امتداده مثل app.py أو project.html" },
        content: { type: "string", description: "المحتوى الكامل للملف" },
        caption: { type: "string", description: "رسالة توضيحية مختصرة" },
      },
      required: ["filename", "content"],
    },
  },
];

// ─── System Prompt ─────────────────────────────────────────────────────────────

function buildSystemPrompt(task?: string): string {
  const taskHint = task ? `\nالمهمة الحالية: ${task}` : "";
  return `أنت HAYO Bot — المساعد الذكي الخارق لمنصة HAYO AI.${taskHint}

قدراتك الكاملة:
📊 تحليل الأسواق المالية — استخدم fetch_market_data للبيانات الحقيقية
📱 بناء تطبيقات كاملة — أرسلها كملفات عبر send_file
💻 توليد الكود — بأي لغة، أرسل الكود الطويل كملف
🌍 الترجمة — لأي لغة في العالم
📝 التلخيص — للمقالات والوثائق
⚗️ هندسة الـ Prompts — تحسين وتطوير
🔬 البحث العميق — في أي موضوع علمي أو تقني
🔄 شرح وتحليل الكود البرمجي

قواعد:
1. أجب بنفس لغة المستخدم دائماً
2. للتحليل المالي → استخدم fetch_market_data أولاً
3. الكود الطويل (>30 سطر) → send_file
4. الردود النصية: مختصرة ومركزة
5. لا تذكر أسماء النماذج الداخلية`;
}

// ─── Agentic Loop ─────────────────────────────────────────────────────────────

async function runAgentLoop(
  token: string,
  chatId: number,
  memKey: string,
  systemPrompt?: string,
): Promise<void> {
  const { createAnthropicClient } = await import("../hayo/llm");
  const anthropic = createAnthropicClient();
  const messages = getMemory(memKey);
  const MAX_ITER = 6;

  for (let i = 0; i < MAX_ITER; i++) {
    void sendTyping(token, chatId);

    let response: Anthropic.Message;
    try {
      response = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: 8192,
        system: systemPrompt || buildSystemPrompt(),
        tools: HAYO_TOOLS,
        messages,
      });
    } catch (err: any) {
      console.error("[HAYO Bot] Claude error:", err.message);
      await sendText(token, chatId, "⚠️ حدث خطأ في المعالجة. حاول مجدداً.", BACK_MAIN);
      return;
    }

    const textBlocks = response.content.filter((b): b is Anthropic.TextBlock => b.type === "text");
    const toolBlocks = response.content.filter((b): b is Anthropic.ToolUseBlock => b.type === "tool_use");

    messages.push({ role: "assistant", content: response.content });

    if (response.stop_reason === "end_turn" || toolBlocks.length === 0) {
      const finalText = textBlocks.map(b => b.text).join("\n").trim();
      if (finalText) await sendText(token, chatId, finalText, BACK_MAIN);
      break;
    }

    const midText = textBlocks.map(b => b.text).join("\n").trim();
    if (midText) await sendText(token, chatId, midText);

    const toolResults: Anthropic.ToolResultBlockParam[] = [];
    for (const tb of toolBlocks) {
      const input = tb.input as Record<string, any>;
      let result = "";

      if (tb.name === "fetch_market_data") {
        void sendTyping(token, chatId);
        result = await fetchMarketData(input.symbol, input.interval);
      } else if (tb.name === "send_file") {
        await sendDocument(token, chatId, input.filename, input.content, input.caption);
        result = `✅ تم إرسال الملف "${input.filename}"`;
      } else {
        result = `أداة "${tb.name}" غير معروفة`;
      }

      toolResults.push({ type: "tool_result", tool_use_id: tb.id, content: result });
    }
    messages.push({ role: "user", content: toolResults });
  }
}

// ─── Show Main Menu ───────────────────────────────────────────────────────────

async function showMainMenu(token: string, chatId: number, edit?: { messageId: number }): Promise<void> {
  const text = "🤖 <b>HAYO Bot</b> — اختر ما تريد تنفيذه:";
  if (edit) {
    await editText(token, chatId, edit.messageId, text, MAIN_MENU);
  } else {
    await sendText(token, chatId, text, MAIN_MENU);
  }
}

// ─── Handle Callback (Button Presses) ────────────────────────────────────────

async function handleCallback(
  token: string,
  chatId: number,
  messageId: number,
  data: string,
  memKey: string,
  botWelcome?: string | null,
): Promise<void> {
  const sess = getSession(memKey);

  // ── Main menu & actions ───────────────────────────────────────────────────
  if (data === "action:main") {
    clearSession(memKey);
    await showMainMenu(token, chatId, { messageId });
    return;
  }
  if (data === "action:clear") {
    conversationMemory.delete(memKey);
    clearSession(memKey);
    await editText(token, chatId, messageId,
      "✅ تم مسح ذاكرة المحادثة.\n\n🤖 <b>HAYO Bot</b> — جاهز من جديد:", MAIN_MENU);
    return;
  }
  if (data === "action:status") {
    const mem = getMemory(memKey);
    await editText(token, chatId, messageId,
      `⚙️ <b>حالة HAYO Bot</b>\n\n📊 بيانات السوق: ✅ Yahoo Finance (مجاني)\n🧠 ذاكرة المحادثة: ${mem.length} رسالة\n🤖 النموذج: Claude Opus`,
      [
        [{ text: "◀️ القائمة الرئيسية", callback_data: "action:main" }],
      ],
    );
    return;
  }

  // ── Market Analysis flow ──────────────────────────────────────────────────
  if (data === "menu:market") {
    clearSession(memKey);
    sess.step = "pair";
    await editText(token, chatId, messageId,
      "📊 <b>تحليل الأسواق</b>\n\nاختر الزوج المالي:", PAIRS_KEYBOARD);
    return;
  }
  if (data.startsWith("pair:")) {
    const pair = data.slice(5);
    if (pair === "custom") {
      sess.step = "pair";
      await editText(token, chatId, messageId,
        "✏️ <b>زوج مخصص</b>\n\nأرسل رمز الزوج أو السهم (مثال: EURUSD أو AAPL أو ETH/USD):",
        [[{ text: "◀️ رجوع", callback_data: "menu:market" }]]);
      return;
    }
    sess.step = "tf";
    sess.pair = pair;
    await editText(token, chatId, messageId,
      `📊 <b>${pair}</b>\n\nاختر الإطار الزمني:`, tfKeyboard(pair));
    return;
  }
  if (data.startsWith("tf:")) {
    const [, pair, interval] = data.split(":");
    sess.step = undefined;
    sess.pair = pair;
    // Store last analysis for re-analyze button
    buttonSessions.set(memKey + ":last", { pair, step: interval as any });
    await editText(token, chatId, messageId,
      `⏳ <b>جاري تحليل ${pair} | ${interval}...</b>`);
    const task = `قم بتحليل ${pair} على الإطار الزمني ${interval}. استخدم fetch_market_data ثم قدم تحليلاً تقنياً مفصلاً يشمل: الاتجاه العام، RSI، MACD، مستويات الدعم والمقاومة، وتوصية واضحة (شراء/بيع/انتظار) مع مستوى الدخول ووقف الخسارة والهدف.`;
    addToMemory(memKey, [{ role: "user", content: task }]);
    await runAgentLoop(token, chatId, memKey, buildSystemPrompt(`تحليل ${pair} | ${interval}`));
    // Show after-analysis buttons
    await sendText(token, chatId, "▼", AFTER_ANALYSIS);
    return;
  }

  // ── Re-analyze ────────────────────────────────────────────────────────────
  if (data === "action:reanalyze") {
    const lastSess = buttonSessions.get(memKey + ":last") as { pair: string; step: string } | undefined;
    if (lastSess?.pair && lastSess?.step) {
      const fakeData = `tf:${lastSess.pair}:${lastSess.step}`;
      await handleCallback(token, chatId, messageId, fakeData, memKey);
    } else {
      await editText(token, chatId, messageId,
        "📊 <b>تحليل الأسواق</b>\n\nاختر الزوج:", PAIRS_KEYBOARD);
    }
    return;
  }

  // ── Feature menus (prompt for user input) ────────────────────────────────
  const FEATURE_PROMPTS: Record<string, { step: BotSession["step"]; text: string; sys: string }> = {
    "menu:app": {
      step: "app",
      text: "📱 <b>بناء تطبيق</b>\n\nصف التطبيق الذي تريده:\n<i>مثال: تطبيق مذكرات بـ Flutter / لعبة Tetris بـ HTML / بوت Telegram بـ Python</i>",
      sys: "أنت خبير تطوير تطبيقات. عند بناء أي تطبيق أرسل الكود الكامل كملف عبر send_file مع شرح مختصر لكيفية تشغيله.",
    },
    "menu:code": {
      step: "code",
      text: "🔧 <b>توليد كود</b>\n\nأخبرني بالكود الذي تحتاجه:\n<i>مثال: API بـ Node.js للمصادقة / سكريبت Python لتحليل CSV / دالة JavaScript لترتيب مصفوفة</i>",
      sys: "أنت مبرمج خبير. اكتب كوداً نظيفاً وقابلاً للتشغيل. للكود الطويل (>30 سطر) استخدم send_file.",
    },
    "menu:translate": {
      step: "translate",
      text: "🌍 <b>الترجمة</b>\n\nأرسل النص المراد ترجمته (ذكّر باللغة المستهدفة إن أردت):\n<i>مثال: \"ترجم للإنجليزية: ...\" أو أرسل النص مباشرة للترجمة العربية</i>",
      sys: "أنت مترجم محترف. ترجم بدقة وطبيعية مع الحفاظ على السياق والنبرة.",
    },
    "menu:summarize": {
      step: "summarize",
      text: "📝 <b>التلخيص</b>\n\nأرسل النص أو المقال المراد تلخيصه:",
      sys: "أنت متخصص في تلخيص المحتوى. لخص بوضوح مع إبراز النقاط الجوهرية والأفكار الرئيسية.",
    },
    "menu:prompt": {
      step: "prompt",
      text: "⚗️ <b>هندسة Prompt</b>\n\nأرسل الـ Prompt الذي تريد تحسينه (أو فكرتك):\n<i>سأطوره ليكون احترافياً وفعالاً</i>",
      sys: "أنت خبير في هندسة وبناء الـ Prompts. حسّن الـ Prompt ليكون أكثر دقة ووضوحاً وفعالية مع نماذج الذكاء الاصطناعي.",
    },
    "menu:research": {
      step: "research",
      text: "🔬 <b>البحث العميق</b>\n\nما الموضوع الذي تريد البحث فيه؟\n<i>مثال: أحدث تطورات الذكاء الاصطناعي، كيفية عمل الـ Blockchain، مقارنة React vs Vue</i>",
      sys: "أنت باحث أكاديمي متعمق. قدم بحثاً شاملاً ومنظماً مع مصادر وأمثلة عملية.",
    },
    "menu:explain": {
      step: "explain",
      text: "🔄 <b>شرح / تحليل كود</b>\n\nأرسل الكود البرمجي الذي تريد شرحه أو تحليله:",
      sys: "أنت مبرمج خبير يشرح الكود بأسلوب واضح. اشرح ما يفعله الكود، نقاط قوته وضعفه، وكيفية تحسينه.",
    },
  };

  if (data in FEATURE_PROMPTS) {
    const feature = FEATURE_PROMPTS[data];
    sess.step = feature.step;
    // Store system prompt for this task
    buttonSessions.set(memKey + ":sys", { step: feature.sys as any });
    await editText(token, chatId, messageId, feature.text,
      [[{ text: "◀️ القائمة الرئيسية", callback_data: "action:main" }]]);
    return;
  }
}

// ─── Handle Text Message ───────────────────────────────────────────────────────

async function handleTextMessage(
  token: string,
  chatId: number,
  userText: string,
  memKey: string,
): Promise<void> {
  const sess = getSession(memKey);
  const sysSess = buttonSessions.get(memKey + ":sys") as { step: string } | undefined;

  // If user is in a step flow (came from a button)
  if (sess.step) {
    const taskSys = sysSess?.step || buildSystemPrompt();
    const step = sess.step;

    // Handle custom pair input
    if (step === "pair") {
      const symbol = userText.toUpperCase().replace(/\s/g, "");
      sess.step = "tf";
      sess.pair = symbol;
      await sendText(token, chatId,
        `📊 <b>${symbol}</b>\n\nاختر الإطار الزمني:`,
        tfKeyboard(symbol));
      return;
    }

    // For all other steps: run agent with the typed input
    clearSession(memKey);
    const taskMap: Record<string, string> = {
      translate: `ترجم النص التالي: ${userText}`,
      summarize: `لخص النص التالي: ${userText}`,
      prompt:    `حسّن وطور الـ Prompt التالي: ${userText}`,
      research:  `قم ببحث عميق ومفصل حول: ${userText}`,
      code:      `اكتب الكود التالي: ${userText}`,
      app:       `ابنِ التطبيق التالي: ${userText}`,
      explain:   `اشرح وحلّل الكود التالي:\n${userText}`,
    };
    const fullTask = taskMap[step] || userText;
    addToMemory(memKey, [{ role: "user", content: fullTask }]);
    await sendTyping(token, chatId);
    await runAgentLoop(token, chatId, memKey, typeof taskSys === "string" ? taskSys : buildSystemPrompt());
    return;
  }

  // Free text — general conversation with full agent
  addToMemory(memKey, [{ role: "user", content: userText }]);
  await sendTyping(token, chatId);
  await runAgentLoop(token, chatId, memKey, buildSystemPrompt());

  // Trim memory
  const mem = getMemory(memKey);
  if (mem.length > MAX_MEMORY) mem.splice(0, mem.length - MAX_MEMORY);
}

// ─── Webhook Handler ──────────────────────────────────────────────────────────

router.post("/telegram/webhook/:userId", async (req, res): Promise<void> => {
  res.json({ ok: true }); // Respond to Telegram immediately

  const userId = parseInt(req.params.userId, 10);
  if (isNaN(userId)) return;

  const update = req.body;

  try {
    const { db } = await import("@workspace/db");
    const { telegramBots } = await import("@workspace/db/schema");
    const { eq } = await import("drizzle-orm");

    const [bot] = await db.select().from(telegramBots).where(eq(telegramBots.userId, userId)).limit(1);
    if (!bot?.isActive || !bot.botToken) return;

    const token = bot.botToken;

    // ── Callback Query (button press) ─────────────────────────────────────────
    if (update.callback_query) {
      const cb = update.callback_query;
      const chatId: number = cb.message?.chat?.id;
      const messageId: number = cb.message?.message_id;
      const data: string = cb.data || "";
      const memKey = `${userId}:${chatId}`;
      await answerCallback(token, cb.id);
      await handleCallback(token, chatId, messageId, data, memKey, bot.welcomeMessage);
      await db.update(telegramBots).set({ updatedAt: new Date() }).where(eq(telegramBots.userId, userId));
      return;
    }

    // ── Regular Message ───────────────────────────────────────────────────────
    const message = update?.message || update?.edited_message;
    if (!message?.chat?.id) return;

    const chatId: number = message.chat.id;
    const userText: string = (message.text || "").trim();
    const memKey = `${userId}:${chatId}`;

    if (!userText) return;

    // /start or /help → show main menu
    if (userText === "/start" || userText === "/help" || userText === "/menu") {
      clearSession(memKey);
      const welcome = bot.welcomeMessage
        ? bot.welcomeMessage + "\n\nاختر ما تريد:"
        : "مرحباً! أنا <b>HAYO Bot</b> 🤖\nجسرك الذكي لمنصة HAYO AI\n\nاختر ما تريد تنفيذه:";
      await sendText(token, chatId, welcome, MAIN_MENU);
      return;
    }

    await handleTextMessage(token, chatId, userText, memKey);
    await db.update(telegramBots).set({ updatedAt: new Date() }).where(eq(telegramBots.userId, userId));

  } catch (err: any) {
    console.error("[HAYO Bot Webhook Error]", err.message);
  }
});

export default router;
