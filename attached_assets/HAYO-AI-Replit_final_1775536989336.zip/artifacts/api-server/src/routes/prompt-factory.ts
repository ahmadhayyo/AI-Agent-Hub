/**
 * Prompt Factory Route — Professional Edition
 * POST /api/prompt-factory/generate — Create professional prompt
 * POST /api/prompt-factory/refine — Refine/improve existing prompt
 * POST /api/prompt-factory/test — Test prompt on AI model directly
 */
import { Router } from "express";
import { authenticateRequest } from "../hayo/auth";
import { callPowerAI, callOfficeAI } from "../hayo/providers";

const router = Router();

const SYSTEM_PROMPT = `أنت أفضل مهندس برومبت (Prompt Engineer) في العالم — خبير في كل تقنيات هندسة البرومبت المتقدمة.

مهمتك: تحويل أي فكرة بسيطة إلى برومبت احترافي عالمي يحقق أفضل النتائج الممكنة.

استخدم هذه التقنيات المتقدمة:
- Role Priming: حدد شخصية خبيرة ومحددة
- Chain of Thought (CoT): فكّر خطوة بخطوة
- Few-Shot Examples: أضف أمثلة توضيحية
- Structured Output: حدد تنسيق المخرجات بدقة
- Constraints & Guardrails: ضع حدود واضحة
- Meta-prompting: أضف تعليمات عن كيفية التعامل مع الغموض
- Temperature Guidance: اقترح درجة الحرارة المثالية
- Persona Depth: أعطِ النموذج خلفية وسياق عميق

قواعد الإخراج:

# 🎯 البرومبت الاحترافي
اكتب البرومبت كاملاً — جاهز للنسخ والاستخدام. يجب أن يكون:
- طويل ومفصل (200+ كلمة)
- يستخدم Role Assignment + CoT + Constraints
- يحتوي [VARIABLES] قابلة للتخصيص
- يحدد تنسيق المخرجات المطلوب
- يتضمن أمثلة (Few-shot) إذا ناسب

# ⚙️ المتغيرات القابلة للتخصيص
اشرح كل [VARIABLE] مع القيم الممكنة وأمثلة

# 🔬 الشرح التقني
اشرح التقنيات المستخدمة بمصطلحاتها الإنجليزية — لماذا هذا الترتيب؟ لماذا هذه الصياغة؟

# 📋 خطوات التنفيذ
خطوات رقمية واضحة (5+) تشمل: تحضير البيانات، تعديل المتغيرات، تشغيل البرومبت، مراجعة النتائج

# 🤖 النماذج المثالية
رتّب أفضل 3 نماذج مع سبب + Temperature + Max Tokens الموصى بها

# 💡 نصائح متقدمة
5+ نصائح عملية لتحسين النتائج — تقنيات متقدمة مثل: iterative refinement, A/B testing, context window management

# 📤 مثال على المخرج المتوقع
مثال واقعي مفصل (100+ كلمة) على ما سيُنتجه البرومبت

اكتب بالعربية. إذا الطلب بالإنجليزية: البرومبت بالإنجليزية والشرح بالعربية.`;

router.post("/prompt-factory/generate", async (req, res) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });

    const { request, category, targetModel } = req.body as {
      request: string; category?: string; targetModel?: string;
    };

    if (!request || request.trim().length < 5)
      return res.status(400).json({ error: "يرجى كتابة طلبك بوضوح (5 أحرف على الأقل)" });

    const userMsg = [
      category ? `الفئة: ${category}` : "",
      targetModel ? `النموذج المستهدف: ${targetModel}` : "",
      `الطلب: ${request.trim()}`,
    ].filter(Boolean).join("\n");

    const { content, modelUsed } = await callPowerAI(SYSTEM_PROMPT, userMsg, 8000);
    return res.json({ result: content, modelUsed });
  } catch (e: any) {
    return res.status(500).json({ error: e.message || "فشل توليد البرومبت" });
  }
});

// POST /api/prompt-factory/refine — Improve/refine an existing prompt
router.post("/prompt-factory/refine", async (req, res) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });

    const { prompt, feedback } = req.body as { prompt: string; feedback: string };
    if (!prompt) return res.status(400).json({ error: "يرجى إرسال البرومبت" });

    const { content, modelUsed } = await callPowerAI(
      `أنت خبير تحسين برومبتات. مهمتك تحسين البرومبت المعطى بناءً على ملاحظات المستخدم.
أعد البرومبت المحسّن فقط — كامل وجاهز للاستخدام. لا تضف شروحات، فقط البرومبت المحسّن.`,
      `البرومبت الأصلي:\n---\n${prompt}\n---\n\nملاحظات التحسين: ${feedback || "حسّنه واجعله أقوى وأكثر دقة"}\n\nأعد البرومبت المحسّن كاملاً.`,
      6000
    );
    return res.json({ result: content, modelUsed });
  } catch (e: any) {
    return res.status(500).json({ error: e.message || "فشل التحسين" });
  }
});

// POST /api/prompt-factory/test — Test a prompt on AI model directly
router.post("/prompt-factory/test", async (req, res) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });

    const { prompt, testInput } = req.body as { prompt: string; testInput?: string };
    if (!prompt) return res.status(400).json({ error: "يرجى إرسال البرومبت" });

    const result = await callOfficeAI(
      prompt,
      testInput || "نفّذ البرومبت مع مثال واقعي.",
      4096,
      "claude-sonnet-4-6" as any
    );
    return res.json({ result, model: "Claude Sonnet 4.6" });
  } catch (e: any) {
    return res.status(500).json({ error: e.message || "فشل الاختبار" });
  }
});

export default router;
