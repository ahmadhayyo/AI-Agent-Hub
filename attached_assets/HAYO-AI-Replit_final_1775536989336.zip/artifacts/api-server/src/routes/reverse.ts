/**
 * Reverse Engineering Routes — HAYO AI
 * Supported formats: APK, EXE, DLL, EX4, EX5, ELF, SO, IPA, JAR, AAR, DEX, WASM
 */

import { Router, type IRouter } from "express";
import multer from "multer";
import {
  decompileAPK, analyzeEXE, analyzeEX4, analyzeEX5, analyzeELF, analyzeIPA,
  analyzeJAR, analyzeDEX, analyzeWASM, analyzeWithAI,
  decompileFileForEdit, readSessionFileContent,
  saveFileEdit, revertFile, getSessionInfo,
  aiModifyCode, aiSearchFiles, rebuildAPK, isApkToolAvailable,
  aiSmartModify, cloneApp, generateIntelligenceReport, regexSearchFiles,
  type CloneOptions,
} from "../hayo/services/reverse-engineer.js";
import { authenticateRequest } from "../hayo/auth.js";
import { checkCredits, deductCredits } from "../hayo/db.js";

const router: IRouter = Router();
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 500 * 1024 * 1024 },
});

// Supported formats
const SUPPORTED_FORMATS = ["apk", "exe", "dll", "ex4", "ex5", "ipa", "jar", "aar", "dex", "so", "wasm"] as const;
type SupportedFormat = typeof SUPPORTED_FORMATS[number];

const FORMAT_LABELS: Record<string, string> = {
  apk: "Android APK", exe: "Windows EXE", dll: "Windows DLL",
  ex4: "MetaTrader 4 EX4", ex5: "MetaTrader 5 EX5",
  ipa: "iOS IPA", jar: "Java JAR", aar: "Android AAR",
  dex: "Dalvik DEX", so: "Linux ELF (.so)", elf: "Linux ELF",
  wasm: "WebAssembly WASM",
};

// In-memory store for decompiled ZIPs (read-only mode)
const temporaryDownloads = new Map<string, { buffer: Buffer; fileName: string; expiresAt: number }>();
setInterval(() => {
  const now = Date.now();
  for (const [id, e] of temporaryDownloads) {
    if (now > e.expiresAt) temporaryDownloads.delete(id);
  }
}, 10 * 60 * 1000);

// ── POST /api/reverse/decompile ──────────────────────────────────────
router.post("/reverse/decompile", upload.single("file"), async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });

    const creditCheck = await checkCredits(user.id, "reverse_decompile");
    if (!creditCheck.allowed) return res.status(402).json({ error: creditCheck.message || "نقاطك اليومية نفدت" });

    if (!req.file) return res.status(400).json({ error: "يرجى رفع ملف" });

    const fileName = req.file.originalname || "unknown";
    const ext = fileName.split(".").pop()?.toLowerCase() as SupportedFormat;

    if (!ext || !SUPPORTED_FORMATS.includes(ext as any)) {
      return res.status(400).json({
        error: `صيغة غير مدعومة: .${ext || "?"}\nالصيغ المدعومة: ${SUPPORTED_FORMATS.map(f => f.toUpperCase()).join(", ")}`,
      });
    }

    let result;
    if (ext === "apk") {
      result = await decompileAPK(req.file.buffer, fileName);
    } else if (ext === "exe" || ext === "dll") {
      result = await analyzeEXE(req.file.buffer, fileName);
    } else if (ext === "ex4") {
      result = await analyzeEX4(req.file.buffer, fileName);
    } else if (ext === "ex5") {
      result = await analyzeEX5(req.file.buffer, fileName);
    } else if (ext === "ipa") {
      result = await analyzeIPA(req.file.buffer, fileName);
    } else if (ext === "jar" || ext === "aar") {
      result = await analyzeJAR(req.file.buffer, fileName, ext);
    } else if (ext === "dex") {
      result = await analyzeDEX(req.file.buffer, fileName);
    } else if (ext === "so") {
      result = await analyzeELF(req.file.buffer, fileName);
    } else if (ext === "wasm") {
      result = await analyzeWASM(req.file.buffer, fileName);
    } else {
      return res.status(400).json({ error: `صيغة غير مدعومة: ${ext}` });
    }

    if (!result.success) return res.status(422).json({ error: result.error });

    await deductCredits(user.id, "reverse_decompile");

    let downloadId: string | undefined;
    if (result.zipBuffer) {
      downloadId = `dl-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
      temporaryDownloads.set(downloadId, {
        buffer: result.zipBuffer,
        fileName: fileName.replace(/\.[^.]+$/, "") + "-decompiled.zip",
        expiresAt: Date.now() + 30 * 60 * 1000,
      });
    }

    const { zipBuffer: _z, ...responseData } = result;
    res.json({ ...responseData, downloadId, formatLabel: FORMAT_LABELS[ext] || ext.toUpperCase() });
  } catch (err: any) {
    console.error("[Reverse/decompile]", err);
    res.status(500).json({ error: err.message || "فشل التفكيك" });
  }
});

// ── GET /api/reverse/download/:id ────────────────────────────────────
router.get("/reverse/download/:id", (req: any, res: any) => {
  const entry = temporaryDownloads.get(req.params.id);
  if (!entry) return res.status(404).json({ error: "الملف غير موجود أو انتهت صلاحيته" });
  if (Date.now() > entry.expiresAt) {
    temporaryDownloads.delete(req.params.id);
    return res.status(410).json({ error: "انتهت صلاحية الملف (30 دقيقة)" });
  }
  res.setHeader("Content-Type", "application/zip");
  res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(entry.fileName)}`);
  res.send(entry.buffer);
});

// ── POST /api/reverse/analyze ─────────────────────────────────────────
router.post("/reverse/analyze", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });

    const creditCheck = await checkCredits(user.id, "reverse_analyze");
    if (!creditCheck.allowed) return res.status(402).json({ error: creditCheck.message || "نقاطك اليومية نفدت" });

    const { code, fileName, analysisType } = req.body;
    if (!code?.trim()) return res.status(400).json({ error: "يرجى إرسال الكود للتحليل" });

    const analysis = await analyzeWithAI(code, fileName || "unknown", analysisType || "full");
    await deductCredits(user.id, "reverse_analyze");
    res.json({ analysis });
  } catch (err: any) {
    console.error("[Reverse/analyze]", err);
    res.status(500).json({ error: err.message || "فشل التحليل" });
  }
});

// ── POST /api/reverse/decompile-for-edit ─────────────────────────────
router.post("/reverse/decompile-for-edit", upload.single("file"), async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });

    const creditCheck = await checkCredits(user.id, "reverse_edit_session");
    if (!creditCheck.allowed) return res.status(402).json({ error: creditCheck.message || "نقاطك اليومية نفدت" });

    if (!req.file) return res.status(400).json({ error: "يرجى رفع ملف" });
    const ext = req.file.originalname?.split(".").pop()?.toLowerCase();
    if (!ext || !SUPPORTED_FORMATS.includes(ext as any)) {
      return res.status(400).json({ error: `الصيغ المدعومة في وضع التحرير: ${SUPPORTED_FORMATS.map(f => f.toUpperCase()).join(", ")}` });
    }

    const result = await decompileFileForEdit(req.file.buffer, req.file.originalname || `file.${ext}`);
    if (!result.success) return res.status(422).json({ error: result.error });

    await deductCredits(user.id, "reverse_edit_session");
    const { files, ...meta } = result;
    res.json({
      ...meta,
      fileCount: files.length,
      apkToolAvailable: isApkToolAvailable(),
      formatLabel: FORMAT_LABELS[ext] || ext.toUpperCase(),
    });
  } catch (err: any) {
    console.error("[Reverse/decompile-for-edit]", err);
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/reverse/session/:id ──────────────────────────────────────
router.get("/reverse/session/:id", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const info = getSessionInfo(req.params.id);
    res.json({ ...info, apkToolAvailable: isApkToolAvailable() });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/file-content ──────────────────────────────────
router.post("/reverse/file-content", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const { sessionId, filePath } = req.body;
    if (!sessionId || !filePath) return res.status(400).json({ error: "sessionId وfilePath مطلوبان" });
    const result = readSessionFileContent(sessionId, filePath);
    if (!result.success) return res.status(404).json({ error: result.error });
    res.json({ content: result.content });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/save-edit ───────────────────────────────────────
router.post("/reverse/save-edit", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const { sessionId, filePath, content } = req.body;
    if (!sessionId || !filePath || content === undefined) return res.status(400).json({ error: "بيانات ناقصة" });
    res.json(saveFileEdit(sessionId, filePath, content));
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/revert-file ─────────────────────────────────────
router.post("/reverse/revert-file", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const { sessionId, filePath } = req.body;
    if (!sessionId || !filePath) return res.status(400).json({ error: "بيانات ناقصة" });
    res.json(revertFile(sessionId, filePath));
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/ai-modify ───────────────────────────────────────
router.post("/reverse/ai-modify", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const creditCheck = await checkCredits(user.id, "reverse_ai_modify");
    if (!creditCheck.allowed) return res.status(402).json({ error: creditCheck.message || "نقاطك اليومية نفدت" });
    const { code, instruction, fileName } = req.body;
    if (!code || !instruction) return res.status(400).json({ error: "يرجى إدخال الكود والتعليمات" });
    const result = await aiModifyCode(code, instruction, fileName || "unknown");
    await deductCredits(user.id, "reverse_ai_modify");
    res.json(result);
  } catch (err: any) {
    console.error("[Reverse/ai-modify]", err);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/ai-search ───────────────────────────────────────
router.post("/reverse/ai-search", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const creditCheck = await checkCredits(user.id, "reverse_ai_search");
    if (!creditCheck.allowed) return res.status(402).json({ error: creditCheck.message || "نقاطك اليومية نفدت" });
    const { sessionId, query } = req.body;
    if (!sessionId || !query) return res.status(400).json({ error: "يرجى إدخال الجلسة وعبارة البحث" });
    const result = await aiSearchFiles(sessionId, query);
    await deductCredits(user.id, "reverse_ai_search");
    res.json(result);
  } catch (err: any) {
    console.error("[Reverse/ai-search]", err);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/rebuild ─────────────────────────────────────────
router.post("/reverse/rebuild", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const creditCheck = await checkCredits(user.id, "reverse_rebuild");
    if (!creditCheck.allowed) return res.status(402).json({ error: creditCheck.message || "نقاطك اليومية نفدت" });
    const { sessionId } = req.body;
    if (!sessionId) return res.status(400).json({ error: "يرجى إرسال معرف الجلسة" });
    const result = await rebuildAPK(sessionId);
    if (!result.success) return res.status(500).json({ error: result.error });
    await deductCredits(user.id, "reverse_rebuild");
    res.setHeader("Content-Type", "application/vnd.android.package-archive");
    res.setHeader("Content-Disposition", result.signed ? `attachment; filename="modified-signed.apk"` : `attachment; filename="modified-unsigned.apk"`);
    res.setHeader("X-APKTool-Used", result.usedApkTool ? "true" : "false");
    res.setHeader("X-APK-Signed", result.signed ? "true" : "false");
    res.send(result.apkBuffer);
  } catch (err: any) {
    console.error("[Reverse/rebuild]", err);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/ai-smart-modify ─────────────────────────────────
// AI finds and modifies files automatically — user just describes what they want
router.post("/reverse/ai-smart-modify", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const creditCheck = await checkCredits(user.id, "reverse_ai_modify");
    if (!creditCheck.allowed) return res.status(402).json({ error: creditCheck.message || "نقاطك اليومية نفدت" });
    const { sessionId, instruction } = req.body;
    if (!sessionId || !instruction) return res.status(400).json({ error: "يرجى إرسال معرف الجلسة والتعليمات" });
    const result = await aiSmartModify(sessionId, instruction);
    await deductCredits(user.id, "reverse_ai_modify");
    res.json(result);
  } catch (err: any) {
    console.error("[Reverse/ai-smart-modify]", err);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/clone ──────────────────────────────────────────
// Full automatic: decompile → modify → sign → rebuild
router.post("/reverse/clone", upload.single("file"), async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const creditCheck = await checkCredits(user.id, "reverse_clone");
    if (!creditCheck.allowed) return res.status(402).json({ error: creditCheck.message || "نقاطك اليومية نفدت" });
    if (!req.file) return res.status(400).json({ error: "يرجى رفع ملف" });

    const options: CloneOptions = {
      removeAds: req.body.removeAds === "true",
      unlockPremium: req.body.unlockPremium === "true",
      removeTracking: req.body.removeTracking === "true",
      removeLicenseCheck: req.body.removeLicenseCheck === "true",
      changeAppName: req.body.changeAppName || undefined,
      changePackageName: req.body.changePackageName || undefined,
      customInstructions: req.body.customInstructions || undefined,
    };

    const result = await cloneApp(req.file.buffer, req.file.originalname || "app.apk", options);
    await deductCredits(user.id, "reverse_clone");

    if (!result.success) {
      return res.status(422).json({ error: result.error, modifications: result.modifications });
    }

    // Return as downloadable file
    const ext = req.file.originalname?.split(".").pop()?.toLowerCase();
    const mimeTypes: Record<string, string> = {
      apk: "application/vnd.android.package-archive",
      ipa: "application/octet-stream",
      jar: "application/java-archive",
      aar: "application/java-archive",
    };
    const outputExts: Record<string, string> = {
      apk: ".apk", ipa: ".ipa", jar: ".jar", aar: ".aar",
    };
    const contentType = mimeTypes[ext || ""] || "application/zip";
    const outputExt = outputExts[ext || ""] || ".zip";
    const outputName = `cloned-${req.file.originalname}${outputExt === ".zip" && !req.file.originalname.endsWith(".zip") ? ".zip" : ""}`;

    res.setHeader("Content-Type", contentType);
    res.setHeader("Content-Disposition", `attachment; filename="${outputName}"`);
    if (ext === "apk") res.setHeader("X-APK-Signed", result.signed ? "true" : "false");
    res.setHeader("X-Modifications", JSON.stringify(result.modifications.slice(0, 15)));
    res.send(result.apkBuffer);
  } catch (err: any) {
    console.error("[Reverse/clone]", err);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/intelligence-report ─────────────────────────────
// Deep security scan: SSL, Root, Crypto, Secrets, URLs
router.post("/reverse/intelligence-report", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const creditCheck = await checkCredits(user.id, "reverse_analyze");
    if (!creditCheck.allowed) return res.status(402).json({ error: creditCheck.message || "نقاطك اليومية نفدت" });
    const { sessionId } = req.body;
    if (!sessionId) return res.status(400).json({ error: "يرجى إرسال معرف الجلسة" });
    const report = await generateIntelligenceReport(sessionId);
    await deductCredits(user.id, "reverse_analyze");
    res.json(report);
  } catch (err: any) {
    console.error("[Reverse/intelligence-report]", err);
    res.status(500).json({ error: err.message });
  }
});

// ── POST /api/reverse/regex-search ────────────────────────────────────
// Regex pattern search across all decompiled files
router.post("/reverse/regex-search", async (req: any, res: any) => {
  try {
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول أولاً" });
    const { sessionId, pattern, category } = req.body;
    if (!sessionId) return res.status(400).json({ error: "يرجى إرسال معرف الجلسة" });
    if (!pattern && !category) return res.status(400).json({ error: "يرجى إرسال نمط البحث أو الفئة" });
    const results = regexSearchFiles(sessionId, pattern || "", category);
    res.json({ results, total: results.length });
  } catch (err: any) {
    console.error("[Reverse/regex-search]", err);
    res.status(500).json({ error: err.message });
  }
});

export default router;
