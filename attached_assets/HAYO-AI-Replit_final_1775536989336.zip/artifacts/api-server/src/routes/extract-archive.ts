/**
 * Archive Extraction Route
 * Supports ZIP and RAR files — returns JSON array of { name, content }
 */
import { Router, type IRouter } from "express";
import multer from "multer";

const router: IRouter = Router();
const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 50 * 1024 * 1024 } });

const TEXT_EXTS = new Set([
  "js","jsx","ts","tsx","py","html","css","json","md","txt",
  "xml","yaml","yml","sh","sql","rb","php","go","rs","java",
  "cpp","c","h","dart","kt","swift","env","toml","gitignore",
  "vue","svelte","astro","rs","cs","fs","ex","exs","lua","r",
  "scala","clj","hs","ml","nim","zig","bat","ps1","ini","cfg",
]);

const SKIP_DIRS = ["node_modules/","__pycache__/",".git/","dist/",".next/","build/",".cache/"];

function shouldSkip(filename: string): boolean {
  return SKIP_DIRS.some(d => filename.includes(d));
}

function getExt(filename: string): string {
  const base = filename.split("/").pop() || filename;
  if (base.startsWith(".") && !base.slice(1).includes(".")) return base.slice(1);
  return base.split(".").pop()?.toLowerCase() || "";
}

router.post("/files/extract-archive", upload.single("file"), async (req: any, res: any) => {
  try {
    const file = req.file;
    if (!file) return res.status(400).json({ error: "No file uploaded" });

    const filename = file.originalname.toLowerCase();
    const isZip = filename.endsWith(".zip");
    const isRar = filename.endsWith(".rar");

    if (!isZip && !isRar) {
      return res.status(400).json({ error: "Only ZIP and RAR files are supported" });
    }

    const results: { name: string; content: string }[] = [];

    if (isZip) {
      const JSZip = (await import("jszip")).default;
      const zip = await JSZip.loadAsync(file.buffer);

      for (const [name, entry] of Object.entries(zip.files)) {
        if ((entry as any).dir) continue;
        if (shouldSkip(name)) continue;
        const ext = getExt(name);
        if (!TEXT_EXTS.has(ext)) continue;
        try {
          const content = await (entry as any).async("text");
          if (content.length < 500_000) results.push({ name, content });
        } catch {}
      }
    } else {
      // RAR extraction using node-unrar-js
      try {
        const { createExtractorFromData } = await import("node-unrar-js");
        const extractor = await createExtractorFromData({
          data: new Uint8Array(file.buffer).buffer,
          password: undefined,
        });
        const list = extractor.extract();
        for (const f of list.files) {
          if (f.fileHeader.flags.directory) continue;
          const name = f.fileHeader.name.replace(/\\/g, "/");
          if (shouldSkip(name)) continue;
          const ext = getExt(name);
          if (!TEXT_EXTS.has(ext)) continue;
          if (f.extraction) {
            try {
              const bytes = f.extraction;
              const content = new TextDecoder("utf-8", { fatal: false }).decode(bytes);
              if (content.length < 500_000) results.push({ name, content });
            } catch {}
          }
        }
      } catch (rarErr: any) {
        return res.status(422).json({ error: `RAR extraction failed: ${rarErr.message}` });
      }
    }

    results.sort((a, b) => a.name.localeCompare(b.name));
    res.json({ files: results, total: results.length });
  } catch (err: any) {
    console.error("[extract-archive]", err);
    res.status(500).json({ error: err.message || "Extraction failed" });
  }
});

export default router;
