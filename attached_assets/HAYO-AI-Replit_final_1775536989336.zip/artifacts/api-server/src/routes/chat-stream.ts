/**
 * SSE Streaming Chat Route
 * POST /api/chat/stream
 * Returns Server-Sent Events with AI response chunks + step events
 */
import { Router } from "express";
import { authenticateRequest } from "../hayo/auth";
import {
  getConversation,
  addMessage,
  getConversationMessages,
  incrementUsage,
  updateConversationTitle,
} from "../hayo/db";
import { streamLLMToResponse, type Message } from "../hayo/llm";
import { db } from "@workspace/db";
import {
  subscriptionCodes,
  subscriptionPlans,
  usageRecords,
} from "@workspace/db/schema";
import { eq, and, gt, isNotNull } from "drizzle-orm";

const router = Router();

// ── Image generation ───────────────────────────────────────────────────────
const IMAGE_KEYWORDS_AR = [
  "ولّد صورة","ولد صورة","أنشئ صورة","انشئ صورة","ارسم","ارسم لي",
  "رسم","توليد صورة","اصنع صورة","صمم صورة","صورة لـ","صورة من",
  "أريد صورة","اريد صورة","ابتكر صورة","أبدع صورة","اصنع لي صورة",
  "أنشئ لي صورة","رسم لي","صورة تُظهر","صورة تبيّن","صورة توضح",
];
const IMAGE_KEYWORDS_EN = [
  "generate image","create image","draw","make an image","create a picture",
  "generate a picture","paint","illustrate","design an image","create art",
  "generate art","make art","create artwork",
];

function detectImageRequest(msg: string): string | null {
  const lower = msg.toLowerCase();
  const matched =
    IMAGE_KEYWORDS_AR.some(k => msg.includes(k)) ||
    IMAGE_KEYWORDS_EN.some(k => lower.includes(k));
  if (!matched) return null;

  // Extract the description part after the keyword
  for (const kw of [...IMAGE_KEYWORDS_AR, ...IMAGE_KEYWORDS_EN]) {
    const idx = msg.indexOf(kw);
    if (idx !== -1) {
      const after = msg.slice(idx + kw.length).trim();
      return after || msg;
    }
  }
  return msg;
}

/**
 * Generate image using Pollinations.ai (free, no API key needed).
 * The URL itself IS the image — the browser fetches and generates it on the fly.
 * Falls back to DALL-E 2 if Pollinations is unavailable.
 */
async function generateImage(prompt: string): Promise<string> {
  // ── Strategy 1: Pollinations.ai (free, no key, URL-based) ────────────
  // Pollinations generates the image when the URL is requested.
  // We just need to return the URL and let the browser load it.
  try {
    const cleanPrompt = prompt.slice(0, 500).trim();
    const seed = Math.floor(Math.random() * 999999);
    const encoded = encodeURIComponent(cleanPrompt);
    const pollinationsUrl =
      `https://image.pollinations.ai/prompt/${encoded}?width=1024&height=1024&nologo=true&enhance=true&model=flux&seed=${seed}`;

    // Quick reachability check (5s only) — if fails, go to DALL-E 2
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    try {
      const check = await fetch("https://image.pollinations.ai/", {
        method: "HEAD",
        signal: ctrl.signal,
      });
      clearTimeout(timer);
      if (check.status < 500) {
        console.log("[image-gen] using Pollinations.ai");
        return pollinationsUrl;
      }
    } catch {
      clearTimeout(timer);
    }
  } catch {}

  // ── Strategy 2: DALL-E 2 ──────────────────────────────────────────────
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) throw new Error("لا يوجد مفتاح API لتوليد الصور وخدمة الصور الافتراضية غير متاحة");

  const res = await fetch("https://api.openai.com/v1/images/generations", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      model: "dall-e-2",
      prompt: prompt.slice(0, 1000),
      n: 1,
      size: "1024x1024",
      response_format: "url",
    }),
  });

  const data = await res.json() as any;
  if (!res.ok || data.error) {
    throw new Error(data.error?.message || `DALL-E 2 error ${res.status}`);
  }
  return data.data?.[0]?.url as string;
}

// ── Build enriched message (includes extracted file content for LLM) ───────
function generateConversationTitle(firstMessage: string): string {
  // Remove extracted file content (after first separator)
  const clean = firstMessage.split(/\n---+\n/)[0].trim();
  // Truncate and clean whitespace
  return clean.replace(/\n+/g, " ").replace(/\s+/g, " ").slice(0, 50).trim() || "محادثة جديدة";
}

function buildEnrichedContent(
  message: string,
  attachments?: Array<{ name: string; type: string; extractedText?: string }>
): string {
  if (!attachments || attachments.length === 0) return message;

  const fileTexts = attachments
    .filter(a => a.extractedText)
    .map(a => `\n---\n📎 **${a.name}**\n${a.extractedText}`)
    .join("\n");

  return fileTexts ? `${message}\n${fileTexts}` : message;
}

// ── Main route ─────────────────────────────────────────────────────────────
router.post("/chat/stream", async (req, res) => {
  // ── Auth ──────────────────────────────────────────────────────────────
  const user = await authenticateRequest(req);
  if (!user) {
    res.status(401).json({ error: "غير مصرح" });
    return;
  }

  const { conversationId, message, model, attachments } = req.body as {
    conversationId: number;
    message: string;
    model?: string;
    attachments?: Array<{ name: string; url: string; type: string; size: number; extractedText?: string }>;
  };

  if (!conversationId || !message) {
    res.status(400).json({ error: "بيانات ناقصة" });
    return;
  }

  // ── Daily limit check (admin bypasses all limits) ─────────────────────
  const now = new Date();
  const todayStr = now.toISOString().slice(0, 10);

  if ((user as any).role !== "admin") {
    const activeSub = await db
      .select({ plan: subscriptionPlans })
      .from(subscriptionCodes)
      .innerJoin(subscriptionPlans, eq(subscriptionCodes.planId, subscriptionPlans.id))
      .where(
        and(
          eq(subscriptionCodes.usedBy, user.id),
          isNotNull(subscriptionCodes.usedAt),
          gt(subscriptionCodes.expiresAt, now)
        )
      )
      .limit(1);

    const dailyLimit = activeSub[0]?.plan?.dailyMessageLimit ?? 10;
    if (dailyLimit !== -1) {
      const usage = await db
        .select()
        .from(usageRecords)
        .where(and(eq(usageRecords.userId, user.id), eq(usageRecords.date, todayStr)))
        .limit(1);
      const todayCount = usage[0]?.messageCount || 0;
      if (todayCount >= dailyLimit) {
        res.status(403).json({
          error: `وصلت إلى الحد اليومي (${dailyLimit} رسالة). اشترك لرفع الحد.`,
        });
        return;
      }
    }
  }

  // ── Validate conversation ─────────────────────────────────────────────
  const conv = await getConversation(conversationId, user.id);
  if (!conv) {
    res.status(404).json({ error: "المحادثة غير موجودة" });
    return;
  }

  // ── Save user message to DB (original clean text for display) ─────────
  await addMessage({
    conversationId,
    role: "user",
    content: message,
    attachments,
  });

  // ── Build LLM message history ──────────────────────────────────────────
  const history = await getConversationMessages(conversationId);
  const llmMessages: Message[] = history
    .filter((m) => m.role !== "system")
    .slice(-20)
    .map((m, idx, arr) => {
      // For the LAST user message, inject extracted file content
      if (idx === arr.length - 1 && m.role === "user") {
        return {
          role: "user" as const,
          content: buildEnrichedContent(m.content, attachments),
        };
      }
      return { role: m.role as "user" | "assistant", content: m.content };
    });

  // ── Setup SSE ─────────────────────────────────────────────────────────
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no");
  res.flushHeaders();

  const sendEvent = (data: object) => {
    res.write(`data: ${JSON.stringify(data)}\n\n`);
    // @ts-ignore
    if (res.flush) res.flush();
  };

  const steps: any[] = [];

  try {
    const requestedModel = model && model !== "default" ? model : undefined;

    // ── File analysis notification ─────────────────────────────────────
    const hasFiles = attachments && attachments.some(a => a.extractedText);
    if (hasFiles) {
      const fileCount = attachments!.filter(a => a.extractedText).length;
      const step = {
        type: "tool_call" as const,
        toolName: "analyze_file",
        content: `تحليل ${fileCount} ملف مرفق...`,
        timestamp: Date.now(),
      };
      steps.push(step);
      sendEvent({ type: "step", step });

      const resultStep = {
        type: "tool_result" as const,
        toolName: "analyze_file",
        content: `تم استخراج محتوى ${fileCount} ملف وإرساله للذكاء الاصطناعي`,
        success: true,
        timestamp: Date.now(),
      };
      steps.push(resultStep);
      sendEvent({ type: "step", step: resultStep });
    }

    // ── Image generation detection & execution ─────────────────────────
    let generatedImageUrl: string | undefined;
    const imagePrompt = detectImageRequest(message);

    if (imagePrompt !== null) {
      const callStep = {
        type: "tool_call" as const,
        toolName: "generate_image",
        content: `جاري توليد صورة: "${imagePrompt.slice(0, 100)}${imagePrompt.length > 100 ? "..." : ""}"`,
        timestamp: Date.now(),
      };
      steps.push(callStep);
      sendEvent({ type: "step", step: callStep });

      try {
        generatedImageUrl = await generateImage(imagePrompt);
        const resultStep = {
          type: "tool_result" as const,
          toolName: "generate_image",
          content: "تم توليد الصورة بنجاح",
          imageUrl: generatedImageUrl,
          success: true,
          timestamp: Date.now(),
        };
        steps.push(resultStep);
        sendEvent({ type: "step", step: resultStep });

        // Inject image URL into LLM context
        llmMessages.push({
          role: "assistant",
          content: `[تم توليد صورة بنجاح: ${generatedImageUrl}]`,
        });
      } catch (imgErr: any) {
        console.error("[chat-stream] image gen failed:", imgErr.message);
        const errStep = {
          type: "tool_result" as const,
          toolName: "generate_image",
          content: `فشل توليد الصورة: ${imgErr.message}`,
          success: false,
          timestamp: Date.now(),
        };
        steps.push(errStep);
        sendEvent({ type: "step", step: errStep });
      }
    }

    // ── Stream LLM response ────────────────────────────────────────────
    let fullText = "";

    // Build system prompt with image context if needed
    const systemPrompt = generatedImageUrl
      ? (conv.systemPrompt
          ? `${conv.systemPrompt}\n\nملاحظة: تم توليد الصورة المطلوبة بنجاح. اشرح ما ولّدته واوصف الصورة للمستخدم.`
          : "أنت مساعد ذكاء اصطناعي متقدم من HAYO AI. تم توليد الصورة المطلوبة بنجاح. اشرح ما ولّدته واوصف الصورة للمستخدم بشكل جميل.")
      : conv.systemPrompt ?? undefined;

    await streamLLMToResponse(
      llmMessages,
      systemPrompt,
      (chunk) => {
        fullText += chunk;
        sendEvent({ type: "chunk", text: chunk });
      },
      requestedModel
    );

    // ── Save AI response to DB ──────────────────────────────────────────
    const aiMsgId = await addMessage({
      conversationId,
      role: "assistant",
      content: fullText,
    });

    await incrementUsage(user.id);

    // ── Auto-title for first exchange ───────────────────────────────────
    // history was fetched before the AI response was saved.
    // If it has only 1 non-system message (the user's), this is the first exchange.
    const nonSystemCount = llmMessages.filter(m => m.role === "user").length;
    let autoTitle: string | undefined;
    if (nonSystemCount === 1 && conv.title === "محادثة جديدة") {
      autoTitle = generateConversationTitle(message);
      await updateConversationTitle(conversationId, autoTitle);
    }

    sendEvent({ type: "done", messageId: aiMsgId, fullText, steps, title: autoTitle });
  } catch (err: any) {
    console.error("[chat-stream] error:", err.message);
    sendEvent({ type: "error", error: err.message || "حدث خطأ في الذكاء الاصطناعي" });
  } finally {
    res.end();
  }
});

export default router;

// ─── Image Generation via AI description ────────────────────────
// Uses Replicate API if available, otherwise generates placeholder
import { callPowerAI } from "../hayo/providers";

router.post("/chat/generate-image", async (req, res) => {
  try {
    const { authenticateRequest } = await import("../hayo/auth");
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول" });

    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: "يرجى كتابة وصف الصورة" });

    const replicateToken = process.env.REPLICATE_API_TOKEN;

    if (replicateToken) {
      // Use Replicate Flux model for image generation
      try {
        const response = await fetch("https://api.replicate.com/v1/predictions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${replicateToken}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: "black-forest-labs/flux-schnell",
            input: { prompt, num_outputs: 1, aspect_ratio: "1:1" },
          }),
        });
        const prediction = await response.json();

        if (prediction.error) throw new Error(prediction.error);

        // Poll for result (Replicate is async)
        let result = prediction;
        for (let i = 0; i < 30; i++) {
          if (result.status === "succeeded") break;
          if (result.status === "failed") throw new Error("فشل توليد الصورة");
          await new Promise(r => setTimeout(r, 2000));
          const poll = await fetch(result.urls.get, { headers: { "Authorization": `Bearer ${replicateToken}` } });
          result = await poll.json();
        }

        const imageUrl = result.output?.[0] || result.output;
        if (!imageUrl) throw new Error("لم يتم توليد الصورة");

        return res.json({ imageUrl, model: "Flux Schnell" });
      } catch (e: any) {
        console.error("[image-gen] Replicate error:", e.message);
        // Fallback to placeholder
      }
    }

    // Fallback: Generate SVG illustration via AI
    const { content } = await callPowerAI(
      "أنت رسام AI. أنشئ كود SVG لرسم توضيحي بسيط وجميل يعبر عن الوصف. أعد كود SVG فقط بدون أي شرح. viewBox='0 0 400 400'. استخدم ألوان جميلة ومتناسقة. أضف أشكال وتفاصيل.",
      `ارسم: ${prompt}`,
      4000
    );

    // Convert SVG to data URL
    const svgMatch = content.match(/<svg[\s\S]*<\/svg>/i);
    if (svgMatch) {
      const svgDataUrl = `data:image/svg+xml;base64,${Buffer.from(svgMatch[0]).toString("base64")}`;
      return res.json({ imageUrl: svgDataUrl, model: "AI SVG" });
    }

    return res.json({ imageUrl: `https://placehold.co/512x512/1a1a2e/6366f1?text=${encodeURIComponent(prompt.substring(0, 20))}`, model: "placeholder" });
  } catch (e: any) {
    return res.status(500).json({ error: e.message || "فشل توليد الصورة" });
  }
});

// ─── AI Video Generation (Owner/Admin ONLY) ─────────────────────
// Supports: Replicate (Minimax video-01, Kling, LumaAI)
router.post("/chat/generate-video", async (req, res) => {
  try {
    const { authenticateRequest } = await import("../hayo/auth");
    const user = await authenticateRequest(req);
    if (!user) return res.status(401).json({ error: "يجب تسجيل الدخول" });

    // Owner-only check
    if (user.role !== "admin") {
      return res.status(403).json({ error: "هذه الميزة حصرية لمالك المنصة فقط" });
    }

    const { prompt, duration, aspectRatio, model: preferredModel } = req.body;
    if (!prompt) return res.status(400).json({ error: "يرجى كتابة وصف الفيديو" });

    const replicateToken = process.env.REPLICATE_API_TOKEN;
    if (!replicateToken) {
      return res.status(400).json({ error: "REPLICATE_API_TOKEN غير مضبوط. أضفه في متغيرات البيئة." });
    }

    // Model selection — multiple video AI models
    const VIDEO_MODELS: Record<string, { version: string; inputKey: string; durationKey?: string }> = {
      "minimax": {
        version: "minimax/video-01",
        inputKey: "prompt",
      },
      "luma": {
        version: "luma/ray",
        inputKey: "prompt",
      },
      "kling": {
        version: "kwaivgi/kling-v1",
        inputKey: "prompt",
      },
      "animate-diff": {
        version: "lucataco/animate-diff:beecf59c4aee8d81bf04f0381033dfa10dc16e845b4ae00d281e2fa377e48a9f",
        inputKey: "prompt_input",
      },
    };

    const selectedModel = preferredModel && VIDEO_MODELS[preferredModel] ? preferredModel : "minimax";
    const modelConfig = VIDEO_MODELS[selectedModel];

    // Build input
    const input: Record<string, any> = {
      [modelConfig.inputKey]: prompt,
    };

    if (aspectRatio) input.aspect_ratio = aspectRatio;

    // Create prediction
    const createRes = await fetch("https://api.replicate.com/v1/predictions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${replicateToken}`,
        "Content-Type": "application/json",
        "Prefer": "wait",
      },
      body: JSON.stringify({
        model: modelConfig.version.includes(":") ? undefined : modelConfig.version,
        version: modelConfig.version.includes(":") ? modelConfig.version.split(":")[1] : undefined,
        input,
      }),
    });

    const prediction = await createRes.json();

    if (prediction.error) {
      return res.status(500).json({ error: `خطأ من ${selectedModel}: ${prediction.error}` });
    }

    // Poll for result (video takes 30-180 seconds)
    let result = prediction;
    const maxPolls = 90; // 90 * 3s = 270s max wait
    for (let i = 0; i < maxPolls; i++) {
      if (result.status === "succeeded") break;
      if (result.status === "failed" || result.status === "canceled") {
        return res.status(500).json({ error: `فشل توليد الفيديو: ${result.error || "unknown"}` });
      }
      await new Promise(r => setTimeout(r, 3000));
      try {
        const pollRes = await fetch(result.urls.get, {
          headers: { "Authorization": `Bearer ${replicateToken}` },
        });
        result = await pollRes.json();
      } catch {}
    }

    // Extract video URL
    let videoUrl = null;
    if (result.output) {
      if (typeof result.output === "string") {
        videoUrl = result.output;
      } else if (Array.isArray(result.output)) {
        videoUrl = result.output[0];
      } else if (result.output.video) {
        videoUrl = result.output.video;
      }
    }

    if (!videoUrl) {
      return res.status(500).json({
        error: "تم الإنشاء لكن لم يتم استخراج رابط الفيديو",
        rawOutput: result.output,
        status: result.status,
      });
    }

    return res.json({
      videoUrl,
      model: selectedModel,
      duration: result.metrics?.predict_time ? `${Math.round(result.metrics.predict_time)}s` : "unknown",
      status: "success",
    });
  } catch (e: any) {
    console.error("[video-gen]", e.message);
    return res.status(500).json({ error: e.message || "فشل توليد الفيديو" });
  }
});

// ─── List available video models (Owner only) ───────────────────
router.get("/chat/video-models", async (req, res) => {
  try {
    const { authenticateRequest } = await import("../hayo/auth");
    const user = await authenticateRequest(req);
    if (!user || user.role !== "admin") return res.status(403).json({ error: "Owner only" });

    res.json({
      models: [
        { id: "minimax", name: "Minimax Video-01", desc: "فيديو واقعي عالي الجودة — 5-6 ثواني", quality: "عالية جداً", speed: "2-4 دقائق" },
        { id: "luma", name: "Luma Ray", desc: "فيديو سينمائي بجودة فائقة", quality: "سينمائية", speed: "3-5 دقائق" },
        { id: "kling", name: "Kling v1", desc: "فيديو واقعي متقدم من KwaiVGI", quality: "عالية", speed: "2-4 دقائق" },
        { id: "animate-diff", name: "AnimateDiff", desc: "تحريك صور — أسلوب أنيمي/إبداعي", quality: "متوسطة", speed: "1-2 دقيقة" },
      ],
      hasToken: !!process.env.REPLICATE_API_TOKEN,
    });
  } catch (e: any) {
    res.status(500).json({ error: e.message });
  }
});
