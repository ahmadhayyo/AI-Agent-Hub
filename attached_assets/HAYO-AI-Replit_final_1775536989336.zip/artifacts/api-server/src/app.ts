import express, { type Express, type RequestHandler } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import router from "./routes";
import { appRouter } from "./hayo/router";
import { authenticateRequest } from "./hayo/auth";
import { logger } from "./lib/logger";

const app: Express = express();

app.set("trust proxy", 1);

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);

app.use(cors({ origin: true, credentials: true }));
app.use(express.json({ limit: "100mb" }));
app.use(express.urlencoded({ limit: "100mb", extended: true }));
app.use(cookieParser() as unknown as RequestHandler);

// ─── Security Middleware ─────────────────────────────────────────
import { securityHeaders, apiRateLimiter } from "./hayo/services/security.js";
app.use(securityHeaders);
app.use("/api/", apiRateLimiter(120));  // 120 requests/min per IP

app.use(
  "/api/trpc",
  createExpressMiddleware({
    router: appRouter,
    createContext: async ({ req, res }) => {
      const user = await authenticateRequest(req);
      return { req, res, user };
    },
  }) as unknown as RequestHandler,
);

app.use("/api", router);

export default app;
