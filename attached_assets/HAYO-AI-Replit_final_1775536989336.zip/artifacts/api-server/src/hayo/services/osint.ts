/**
 * HAYO OSINT — Open Source Intelligence Tools
 * Real API integrations for legitimate intelligence gathering
 * All data from PUBLIC sources only
 */

// ─── IP Geolocation (ip-api.com — free, no key) ─────────────
export async function ipLookup(ip: string): Promise<any> {
  const res = await fetch(`http://ip-api.com/json/${ip}?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query,mobile,proxy,hosting`, { signal: AbortSignal.timeout(10000) });
  const data = await res.json();
  if (data.status === "fail") throw new Error(data.message || "IP غير صالح");
  return data;
}

// ─── WHOIS Lookup (via rdap.org — free) ──────────────────────
export async function whoisLookup(domain: string): Promise<any> {
  const clean = domain.replace(/^https?:\/\//, "").replace(/\/.*$/, "").trim();
  const res = await fetch(`https://rdap.org/domain/${clean}`, { signal: AbortSignal.timeout(15000), headers: { "Accept": "application/json" } });
  if (!res.ok) throw new Error("فشل استعلام WHOIS");
  const data = await res.json();
  return {
    domain: data.ldhName || clean,
    status: data.status || [],
    registrar: data.entities?.find((e: any) => e.roles?.includes("registrar"))?.vcardArray?.[1]?.find((v: any) => v[0] === "fn")?.[3] || "غير معروف",
    created: data.events?.find((e: any) => e.eventAction === "registration")?.eventDate || null,
    expires: data.events?.find((e: any) => e.eventAction === "expiration")?.eventDate || null,
    updated: data.events?.find((e: any) => e.eventAction === "last changed")?.eventDate || null,
    nameservers: data.nameservers?.map((ns: any) => ns.ldhName) || [],
    raw: data,
  };
}

// ─── DNS Lookup (dns.google — free) ──────────────────────────
export async function dnsLookup(domain: string, type: string = "A"): Promise<any> {
  const clean = domain.replace(/^https?:\/\//, "").replace(/\/.*$/, "").trim();
  const res = await fetch(`https://dns.google/resolve?name=${clean}&type=${type}`, { signal: AbortSignal.timeout(10000) });
  const data = await res.json();
  return {
    domain: clean,
    type,
    records: (data.Answer || []).map((r: any) => ({ name: r.name, type: r.type, ttl: r.TTL, data: r.data })),
    status: data.Status === 0 ? "OK" : "NXDOMAIN",
  };
}

// ─── Email Breach Check (haveibeenpwned — public API) ────────
export async function emailBreachCheck(email: string): Promise<any> {
  // Use the free breach directory approach
  try {
    const res = await fetch(`https://haveibeenpwned.com/api/v3/breachedaccount/${encodeURIComponent(email)}?truncateResponse=true`, {
      headers: { "User-Agent": "HAYO-OSINT", "hibp-api-key": process.env.HIBP_API_KEY || "" },
      signal: AbortSignal.timeout(10000),
    });
    if (res.status === 404) return { email, breached: false, breaches: [] };
    if (res.status === 401) return { email, breached: false, breaches: [], note: "API key مطلوب — أضف HIBP_API_KEY" };
    const data = await res.json();
    return { email, breached: true, breachCount: data.length, breaches: data };
  } catch {
    return { email, breached: false, breaches: [], note: "تحقق يدوياً من haveibeenpwned.com" };
  }
}

// ─── Username Search (check public profiles) ─────────────────
export async function usernameSearch(username: string): Promise<any> {
  const sites = [
    { name: "GitHub", url: `https://github.com/${username}`, api: `https://api.github.com/users/${username}` },
    { name: "Twitter/X", url: `https://x.com/${username}`, checkUrl: true },
    { name: "Instagram", url: `https://instagram.com/${username}`, checkUrl: true },
    { name: "Reddit", url: `https://reddit.com/user/${username}`, api: `https://www.reddit.com/user/${username}/about.json` },
    { name: "YouTube", url: `https://youtube.com/@${username}`, checkUrl: true },
    { name: "LinkedIn", url: `https://linkedin.com/in/${username}`, checkUrl: true },
    { name: "TikTok", url: `https://tiktok.com/@${username}`, checkUrl: true },
    { name: "Pinterest", url: `https://pinterest.com/${username}`, checkUrl: true },
    { name: "Telegram", url: `https://t.me/${username}`, checkUrl: true },
    { name: "Medium", url: `https://medium.com/@${username}`, checkUrl: true },
    { name: "GitLab", url: `https://gitlab.com/${username}`, api: `https://gitlab.com/api/v4/users?username=${username}` },
    { name: "Steam", url: `https://steamcommunity.com/id/${username}`, checkUrl: true },
    { name: "Twitch", url: `https://twitch.tv/${username}`, checkUrl: true },
    { name: "Snapchat", url: `https://snapchat.com/add/${username}`, checkUrl: true },
    { name: "Facebook", url: `https://facebook.com/${username}`, checkUrl: true },
    { name: "DeviantArt", url: `https://deviantart.com/${username}`, checkUrl: true },
    { name: "Flickr", url: `https://flickr.com/people/${username}`, checkUrl: true },
    { name: "SoundCloud", url: `https://soundcloud.com/${username}`, checkUrl: true },
    { name: "Vimeo", url: `https://vimeo.com/${username}`, checkUrl: true },
    { name: "HackerOne", url: `https://hackerone.com/${username}`, checkUrl: true },
  ];

  const results = await Promise.allSettled(
    sites.map(async (site) => {
      try {
        if (site.api) {
          const res = await fetch(site.api, { signal: AbortSignal.timeout(5000), headers: { "User-Agent": "HAYO-OSINT" } });
          const found = res.ok;
          let info = null;
          if (found) { try { info = await res.json(); } catch {} }
          return { ...site, found, info: info ? { name: info.name || info.login, bio: info.bio || info.subreddit?.public_description, avatar: info.avatar_url || info.icon_img } : null };
        }
        return { ...site, found: null, info: null }; // checkUrl = can't verify server-side
      } catch { return { ...site, found: false, info: null }; }
    })
  );

  return {
    username,
    sites: results.map((r, i) => {
      if (r.status === "fulfilled") return r.value;
      return { ...sites[i], found: false, info: null };
    }),
    checkedAt: new Date().toISOString(),
  };
}

// ─── Phone Number Lookup (numverify — free tier) ─────────────
export async function phoneLookup(phone: string): Promise<any> {
  const apiKey = process.env.NUMVERIFY_API_KEY;
  if (!apiKey) {
    return {
      phone, valid: null,
      note: "أضف NUMVERIFY_API_KEY للتحقق من أرقام الهواتف (مجاني: numverify.com)",
      manualCheck: [`https://www.truecaller.com/search/${encodeURIComponent(phone)}`],
    };
  }
  const res = await fetch(`http://apilayer.net/api/validate?access_key=${apiKey}&number=${encodeURIComponent(phone)}`, { signal: AbortSignal.timeout(10000) });
  const data = await res.json();
  return { phone, ...data };
}

// ─── Website Technology Stack ────────────────────────────────
export async function techLookup(url: string): Promise<any> {
  const clean = url.replace(/^https?:\/\//, "").replace(/\/.*$/, "").trim();
  try {
    const res = await fetch(`https://${clean}`, { signal: AbortSignal.timeout(10000), redirect: "follow" });
    const headers: Record<string, string> = {};
    res.headers.forEach((v, k) => { headers[k] = v; });
    const body = await res.text();

    const tech: string[] = [];
    if (headers["server"]) tech.push(`Server: ${headers["server"]}`);
    if (headers["x-powered-by"]) tech.push(`Powered by: ${headers["x-powered-by"]}`);
    if (body.includes("wp-content")) tech.push("WordPress");
    if (body.includes("shopify")) tech.push("Shopify");
    if (body.includes("next/") || body.includes("_next")) tech.push("Next.js");
    if (body.includes("react")) tech.push("React");
    if (body.includes("vue")) tech.push("Vue.js");
    if (body.includes("angular")) tech.push("Angular");
    if (body.includes("laravel")) tech.push("Laravel");
    if (body.includes("django")) tech.push("Django");
    if (body.includes("cloudflare")) tech.push("Cloudflare");
    if (body.includes("jquery")) tech.push("jQuery");
    if (body.includes("bootstrap")) tech.push("Bootstrap");
    if (body.includes("tailwind")) tech.push("Tailwind CSS");
    if (body.includes("google-analytics") || body.includes("gtag")) tech.push("Google Analytics");
    if (body.includes("recaptcha")) tech.push("reCAPTCHA");

    return {
      domain: clean, statusCode: res.status, headers,
      technologies: tech,
      ssl: res.url.startsWith("https"),
      title: body.match(/<title[^>]*>(.*?)<\/title>/i)?.[1] || "",
      metaDesc: body.match(/<meta[^>]*name="description"[^>]*content="([^"]*)"[^>]*>/i)?.[1] || "",
    };
  } catch (e: any) {
    throw new Error(`فشل الاتصال بـ ${clean}: ${e.message}`);
  }
}

// ─── SSL Certificate Info ────────────────────────────────────
export async function sslLookup(domain: string): Promise<any> {
  const clean = domain.replace(/^https?:\/\//, "").replace(/\/.*$/, "").trim();
  const res = await fetch(`https://crt.sh/?q=${clean}&output=json`, { signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error("فشل استعلام SSL");
  const data = await res.json();
  const certs = (data as any[]).slice(0, 10).map(c => ({
    issuer: c.issuer_name,
    commonName: c.common_name,
    notBefore: c.not_before,
    notAfter: c.not_after,
    serialNumber: c.serial_number,
  }));
  return { domain: clean, certificates: certs, total: data.length };
}

// ─── Subdomain Finder (via crt.sh) ──────────────────────────
export async function subdomainSearch(domain: string): Promise<any> {
  const clean = domain.replace(/^https?:\/\//, "").replace(/\/.*$/, "").trim();
  const res = await fetch(`https://crt.sh/?q=%.${clean}&output=json`, { signal: AbortSignal.timeout(15000) });
  if (!res.ok) throw new Error("فشل البحث");
  const data = await res.json();
  const subdomains = [...new Set((data as any[]).map(c => c.common_name).filter(Boolean))].sort();
  return { domain: clean, subdomains, count: subdomains.length };
}
