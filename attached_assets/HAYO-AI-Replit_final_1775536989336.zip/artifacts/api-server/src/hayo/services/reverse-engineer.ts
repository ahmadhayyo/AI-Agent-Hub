/**
 * Reverse Engineer Service — HAYO AI
 * APK decompilation (ZIP extraction + Manifest parsing + JADX if available)
 * EXE analysis (PE headers + string extraction + .NET detection)
 * AI-powered code analysis
 */

import JSZip from "jszip";
import * as path from "path";
import * as fs from "fs";
import * as os from "os";
import { execSync } from "child_process";
import { callOfficeAI, callPowerAI } from "../providers.js";

// ════════════════════════════════════════
// Types
// ════════════════════════════════════════

export interface DecompiledFile {
  path: string;
  name: string;
  extension: string;
  size: number;
  content?: string;
  isBinary: boolean;
}

export interface VulnerabilityFinding {
  severity: "critical" | "high" | "medium" | "low" | "info";
  category: string;
  title: string;
  description: string;
  evidence: string[];
}

export interface DecompileResult {
  success: boolean;
  fileType: "apk" | "exe" | "unknown";
  totalFiles: number;
  totalSize: number;
  structure: FileTreeNode[];
  files: DecompiledFile[];
  manifest?: any;
  metadata?: any;
  zipBuffer?: Buffer;
  downloadId?: string;
  error?: string;
  analysisAvailable: boolean;
  vulnerabilities?: VulnerabilityFinding[];
}

export interface FileTreeNode {
  name: string;
  path: string;
  type: "file" | "folder";
  size?: number;
  children?: FileTreeNode[];
}

// ════════════════════════════════════════
// APK Decompilation
// ════════════════════════════════════════

export async function decompileAPK(apkBuffer: Buffer, fileName: string): Promise<DecompileResult> {
  const tmpDir = path.join(os.tmpdir(), `hayo-re-${Date.now()}`);
  const apkPath = path.join(tmpDir, "input.apk");
  const javaOutputDir = path.join(tmpDir, "java-source");

  try {
    fs.mkdirSync(tmpDir, { recursive: true });
    fs.writeFileSync(apkPath, apkBuffer);

    const textExtensions = new Set([
      ".xml", ".txt", ".json", ".properties", ".cfg", ".ini",
      ".html", ".css", ".js", ".kt", ".java", ".smali",
      ".gradle", ".pro", ".md", ".yml", ".yaml", ".mf", ".sf",
    ]);

    const files: DecompiledFile[] = [];

    // Step 1: Unzip APK (APK = ZIP)
    const zip = await JSZip.loadAsync(apkBuffer);

    for (const [entryName, entry] of Object.entries(zip.files)) {
      if (entry.dir) continue;

      const ext = path.extname(entryName).toLowerCase();
      const isText = textExtensions.has(ext);
      let content: string | undefined;

      if (isText) {
        try {
          const data = await entry.async("uint8array");
          if (data.length < 500_000) {
            content = new TextDecoder("utf-8", { fatal: false }).decode(data);
          }
        } catch {
          content = undefined;
        }
      }

      const data = await entry.async("uint8array");
      files.push({
        path: entryName,
        name: path.basename(entryName),
        extension: ext,
        size: data.length,
        content,
        isBinary: !isText,
      });
    }

    // Step 2: Parse AndroidManifest.xml
    let manifest: any = null;
    const manifestEntry = zip.files["AndroidManifest.xml"];
    if (manifestEntry) {
      const manifestBuf = await manifestEntry.async("nodebuffer");
      manifest = parseAndroidManifestBasic(manifestBuf);
    }

    // Step 3: Try JADX decompilation (Java/Kotlin source)
    let jadxSuccess = false;
    try {
      const jadxPaths = [
        "/home/runner/jadx/bin/jadx",
        "/usr/bin/jadx",
        "jadx",
      ];
      let jadxBin = "";
      for (const p of jadxPaths) {
        try {
          execSync(`${p} --version`, { timeout: 5000, stdio: "pipe" });
          jadxBin = p;
          break;
        } catch { /* try next */ }
      }

      if (jadxBin) {
        fs.mkdirSync(javaOutputDir, { recursive: true });
        execSync(
          `"${jadxBin}" --no-res --output-dir "${javaOutputDir}" "${apkPath}"`,
          { timeout: 120_000, stdio: "pipe" }
        );

        for (const jf of readDirRecursive(javaOutputDir)) {
          const relPath = path.relative(javaOutputDir, jf);
          const ext = path.extname(jf).toLowerCase();
          let content: string | undefined;
          try {
            const stat = fs.statSync(jf);
            if (stat.size < 500_000) content = fs.readFileSync(jf, "utf-8");
          } catch { /* skip */ }

          files.push({
            path: `java-source/${relPath}`,
            name: path.basename(jf),
            extension: ext,
            size: fs.existsSync(jf) ? fs.statSync(jf).size : 0,
            content,
            isBinary: false,
          });
        }
        jadxSuccess = true;
      }
    } catch (err: any) {
      console.warn("[RE] JADX failed:", err.message);
    }

    // Step 4: Build file tree
    const structure = buildFileTree(files);

    // Step 5: Build downloadable ZIP
    const outputZip = new JSZip();
    for (const f of files) {
      if (f.content) {
        outputZip.file(f.path, f.content);
      }
    }
    const report = generateAPKReport(fileName, files, manifest, jadxSuccess);
    outputZip.file("_HAYO_AI_REPORT.txt", report);
    const zipBuffer = await outputZip.generateAsync({ type: "nodebuffer" });

    cleanupDir(tmpDir);

    return {
      success: true,
      fileType: "apk",
      totalFiles: files.length,
      totalSize: apkBuffer.length,
      structure,
      files: files.map(f => ({
        ...f,
        content: f.content ? f.content.substring(0, 50_000) : undefined,
      })),
      manifest,
      metadata: {
        jadxDecompiled: jadxSuccess,
        originalSize: formatBytes(apkBuffer.length),
        decompressedFiles: files.length,
        hasJavaSource: jadxSuccess,
        hasSmali: files.some(f => f.extension === ".smali"),
        hasResources: files.some(f => f.path.startsWith("res/")),
        hasNativeLibs: files.some(f => f.path.startsWith("lib/")),
        hasAssets: files.some(f => f.path.startsWith("assets/")),
      },
      zipBuffer,
      analysisAvailable: true,
    };
  } catch (err: any) {
    cleanupDir(tmpDir);
    return {
      success: false,
      fileType: "apk",
      totalFiles: 0,
      totalSize: 0,
      structure: [],
      files: [],
      error: `فشل تفكيك APK: ${err.message}`,
      analysisAvailable: false,
    };
  }
}

// ════════════════════════════════════════
// AI Power Decompile — hex dump + strongest model
// ════════════════════════════════════════

/**
 * Creates a readable hex dump (address | hex bytes | ASCII) from a Buffer.
 * Limits to maxBytes to stay within AI token limits.
 */
function generateHexDump(buf: Buffer, maxBytes = 131072): string {
  const limit = Math.min(buf.length, maxBytes);
  const lines: string[] = [];
  for (let offset = 0; offset < limit; offset += 16) {
    const slice = buf.slice(offset, Math.min(offset + 16, limit));
    const hex = Array.from(slice)
      .map(b => b.toString(16).padStart(2, "0"))
      .join(" ")
      .padEnd(47, " ");
    const ascii = Array.from(slice)
      .map(b => (b >= 0x20 && b <= 0x7e ? String.fromCharCode(b) : "."))
      .join("");
    lines.push(`${offset.toString(16).padStart(8, "0")}  ${hex}  |${ascii}|`);
  }
  if (buf.length > maxBytes) {
    lines.push(`\n... [تم اقتصار الـ hex dump على أول ${formatBytes(maxBytes)} من إجمالي ${formatBytes(buf.length)}]`);
  }
  return lines.join("\n");
}

/**
 * Sends the file's hex dump + extracted metadata to the most powerful AI model
 * available and asks it to perform deep binary analysis and code reconstruction.
 */
async function aiPowerDecompile(
  fileBuffer: Buffer,
  fileName: string,
  ext: string,
  existingStrings: string[]
): Promise<{ content: string; modelUsed: string }> {
  const hexDump = generateHexDump(fileBuffer, 150_000);
  const stringsPreview = existingStrings.slice(0, 300).join("\n");
  const fileSize = formatBytes(fileBuffer.length);

  let systemPrompt = "";
  let userMessage = "";

  if (ext === ".ex4") {
    systemPrompt = `أنت خبير متخصص في هندسة عكسية لملفات MQL4/EX4 الخاصة بمنصة MetaTrader 4.
لديك معرفة عميقة ببنية ملفات EX4 الثنائية:
- Header: 4 bytes magic، build number (uint16LE @ offset 4)، compile timestamp (uint32LE @ offset 12)
- String Table: نصوص UTF-8 وUTF-16LE تشمل أسماء دوال، رسائل، معاملات
- Property Block: تعريفات PROPERTY_INTEGER/DOUBLE/STRING (extern/input variables)  
- Function Table: opcodes استدعاء الدوال المدمجة في MQL4
- Code Section: MQL4 bytecode قابل للتحليل بالأنماط

مهمتك: تحليل hex dump والنصوص المستخرجة وإعادة بناء:
1. معاملات الإدخال (input/extern) مع أنواعها وقيمها الافتراضية
2. الدوال الرئيسية والمساعدة المكتشفة
3. منطق التداول (شروط الدخول/الخروج، إدارة المخاطر)
4. المؤشرات الفنية المستخدمة
5. كود MQ4 إعادة بناء كامل مع تعليقات تشرح كل جزء

اكتب الإجابة بالعربية مع الكود بالإنجليزية. كن محدداً ومفصّلاً قدر الإمكان.`;

    userMessage = `## معلومات الملف
الاسم: ${fileName}
الحجم: ${fileSize}
الامتداد: EX4 (MetaTrader 4 Compiled Expert Advisor/Indicator)

## النصوص المستخرجة من الملف (${existingStrings.length} نص)
\`\`\`
${stringsPreview}
\`\`\`

## Hex Dump (أول 150KB)
\`\`\`
${hexDump}
\`\`\`

الرجاء تحليل هذا الملف بعمق وإعادة بناء:
1. جدول المعاملات (inputs) مع أنواعها وقيمها
2. خريطة الدوال المكتشفة
3. منطق التداول وشروط الدخول/الخروج
4. كود MQ4 مُعاد بناؤه بأقصى دقة ممكنة`;

  } else if (ext === ".exe" || ext === ".dll") {
    systemPrompt = `أنت خبير متخصص في هندسة عكسية لملفات PE (Portable Executable) على Windows.
لديك معرفة عميقة ببنية PE format:
- DOS Header: "MZ" magic @ offset 0، PE offset @ offset 0x3C
- PE Header: "PE\\0\\0" signature، Machine type، NumberOfSections، TimeDateStamp
- Optional Header: ImageBase، AddressOfEntryPoint، SizeOfCode
- Section Table: .text (code)، .data، .rdata (strings)، .bss، .rsrc (resources)
- Import Table (IAT): DLLs والدوال المستوردة — يكشف وظائف البرنامج
- Export Table: الدوال المُصدَّرة (للـ DLL)
- .NET CLR Header (إذا كان .NET): يُمكّن تفكيكاً كاملاً باستخدام IL

مهمتك: تحليل hex dump وإعادة بناء:
1. معلومات PE header الكاملة
2. جدول الاستيراد (Import Table) — DLLs والـ APIs المستخدمة
3. جدول الصادرات (Export Table) للـ DLL
4. تحليل أقسام الكود (.text section)
5. استنتاج وظيفة البرنامج من الـ APIs والنصوص
6. كود C/C++ شبه مُعاد بناؤه مع تعليقات

اكتب الإجابة بالعربية مع الكود بالإنجليزية. كن محدداً ومفصّلاً.`;

    userMessage = `## معلومات الملف
الاسم: ${fileName}
الحجم: ${fileSize}
النوع: ${ext === ".dll" ? "DLL (Dynamic Link Library)" : "EXE (Windows Executable)"}

## النصوص المستخرجة من الملف (${existingStrings.length} نص)
\`\`\`
${stringsPreview}
\`\`\`

## Hex Dump (أول 150KB)
\`\`\`
${hexDump}
\`\`\`

الرجاء تحليل هذا الملف بعمق وإعادة بناء:
1. PE Headers الكاملة (Machine، Sections، EntryPoint، ImageBase)
2. Import Table (DLLs والـ Win32 APIs المستخدمة)
3. Export Table (إن وُجد)
4. استنتاج وظيفة البرنامج من البيانات
5. كود C++ شبه مُعاد بناؤه مع تعليقات توضيحية`;
  }

  return callPowerAI(systemPrompt, userMessage, 16000);
}

export async function analyzeEXE(exeBuffer: Buffer, fileName: string): Promise<DecompileResult> {
  try {
    const files: DecompiledFile[] = [];
    const peInfo = parsePEBasic(exeBuffer);
    const isDotNet = detectDotNet(exeBuffer);
    const strings = extractStrings(exeBuffer);

    files.push({
      path: "analysis/pe-headers.json",
      name: "pe-headers.json",
      extension: ".json",
      size: 0,
      content: JSON.stringify(peInfo, null, 2),
      isBinary: false,
    });

    const stringsContent = strings.join("\n");
    files.push({
      path: "analysis/extracted-strings.txt",
      name: "extracted-strings.txt",
      extension: ".txt",
      size: stringsContent.length,
      content: stringsContent,
      isBinary: false,
    });

    // PE Import/Export table parsing
    const { imports: peImports, exports: peExports } = parsePEImports(exeBuffer);
    if (peImports.length > 0) {
      const importContent = [
        `# جدول الاستيراد (Import Table) — ${peImports.length} DLL`,
        "",
        ...peImports.map(dll => `## ${dll.name}\n${dll.functions.map(f => `  - ${f}`).join("\n") || "  (لا دوال مسماة)"}`),
      ].join("\n");
      files.push({ path: "analysis/import-table.txt", name: "import-table.txt", extension: ".txt", size: importContent.length, content: importContent, isBinary: false });
    }
    if (peExports.length > 0) {
      const exportContent = `# جدول التصدير (Export Table) — ${peExports.length} دالة\n\n` + peExports.join("\n");
      files.push({ path: "analysis/export-table.txt", name: "export-table.txt", extension: ".txt", size: exportContent.length, content: exportContent, isBinary: false });
    }

    // Strings with system tool (better results)
    try {
      const tmpExePath = path.join(os.tmpdir(), `hayo-pe-${Date.now()}.bin`);
      fs.writeFileSync(tmpExePath, exeBuffer);
      const sysStrings = execSync(`strings -n 6 "${tmpExePath}"`, { timeout: 30000, maxBuffer: 10 * 1024 * 1024 }).toString();
      fs.unlinkSync(tmpExePath);
      if (sysStrings.length > stringsContent.length) {
        files.push({ path: "analysis/strings-full.txt", name: "strings-full.txt", extension: ".txt", size: sysStrings.length, content: sysStrings.substring(0, 200000), isBinary: false });
      }
    } catch { /* skip */ }

    if (isDotNet) {
      files.push({
        path: "analysis/dotnet-info.txt",
        name: "dotnet-info.txt",
        extension: ".txt",
        size: 0,
        content: [
          "هذا تطبيق .NET — يمكن تفكيكه بالكامل باستخدام أدوات متخصصة.",
          "",
          "أدوات مقترحة للتفكيك الكامل:",
          "• dnSpy (مجاني): https://github.com/dnSpy/dnSpy",
          "• ILSpy (مجاني): https://github.com/icsharpcode/ILSpy",
          "• dotPeek (مجاني من JetBrains): https://www.jetbrains.com/decompiler/",
          "",
          "يمكنك استخدام تحليل الذكاء الاصطناعي على ملف النصوص المستخرجة للحصول على معلومات مفيدة.",
        ].join("\n"),
        isBinary: false,
      });
    }

    const report = [
      `═══ تقرير تحليل EXE — HAYO AI ═══`,
      `الملف: ${fileName}`,
      `الحجم: ${formatBytes(exeBuffer.length)}`,
      `المعمارية: ${peInfo.architecture || "غير محدد"}`,
      `نوع التطبيق: ${isDotNet ? ".NET (قابل للتفكيك الكامل)" : "Native (C/C++)"}`,
      `تاريخ الترجمة: ${peInfo.compileDate || "غير معروف"}`,
      `عدد النصوص المستخرجة: ${strings.length}`,
      ``,
      `═══ معلومات PE Header ═══`,
      JSON.stringify(peInfo, null, 2),
    ].join("\n");

    files.push({
      path: "analysis/report.txt",
      name: "report.txt",
      extension: ".txt",
      size: report.length,
      content: report,
      isBinary: false,
    });

    // ── AI Power Decompile (أقوى نموذج) ──────────────────────────────
    let aiModelUsed = "";
    try {
      const { content: aiContent, modelUsed } = await aiPowerDecompile(
        exeBuffer, fileName, path.extname(fileName).toLowerCase() || ".exe", strings
      );
      aiModelUsed = modelUsed;
      if (aiContent) {
        const header = [
          `╔══════════════════════════════════════════════════╗`,
          `║  تحليل AI العميق — ${modelUsed}`,
          `║  الملف: ${fileName}`,
          `╚══════════════════════════════════════════════════╝`,
          "",
        ].join("\n");
        files.push({
          path: "ai-decompile/ai-deep-analysis.md",
          name: "ai-deep-analysis.md",
          extension: ".md",
          size: aiContent.length,
          content: header + aiContent,
          isBinary: false,
        });
      }
    } catch (aiErr: any) {
      console.warn("[analyzeEXE] AI Power Decompile failed:", aiErr.message);
      files.push({
        path: "ai-decompile/ai-error.txt",
        name: "ai-error.txt",
        extension: ".txt",
        size: 0,
        content: `تعذّر إجراء التحليل AI العميق: ${aiErr.message}`,
        isBinary: false,
      });
    }

    const outputZip = new JSZip();
    for (const f of files) {
      if (f.content) outputZip.file(f.path, f.content);
    }
    const zipBuffer = await outputZip.generateAsync({ type: "nodebuffer" });

    return {
      success: true,
      fileType: "exe",
      totalFiles: files.length,
      totalSize: exeBuffer.length,
      structure: buildFileTree(files),
      files,
      metadata: {
        format: isDotNet ? ".NET Assembly" : `PE (${peInfo.isDLL ? "DLL" : "EXE"})`,
        originalSize: formatBytes(exeBuffer.length),
        fileName,
        isDotNet,
        architecture: peInfo.architecture || "unknown",
        stringsCount: strings.length,
        compileDate: peInfo.compileDate,
        importsCount: peImports.length,
        exportsCount: peExports.length,
        peInfo,
        aiModelUsed,
      },
      zipBuffer,
      analysisAvailable: true,
      vulnerabilities: scanVulnerabilities(files, "exe", strings.slice(0, 500)),
    };
  } catch (err: any) {
    return {
      success: false,
      fileType: "exe",
      totalFiles: 0,
      totalSize: 0,
      structure: [],
      files: [],
      error: `فشل تحليل EXE: ${err.message}`,
      analysisAvailable: false,
    };
  }
}

// ════════════════════════════════════════
// EX4 Analysis (MetaTrader 4 Expert Advisor)
// ════════════════════════════════════════

interface EX4Header {
  magic: string;
  version: number;
  build: number;
  dateCompiled: string;
  isExpert: boolean;
  isIndicator: boolean;
  isScript: boolean;
}

function parseEX4Header(buf: Buffer): EX4Header {
  // EX4 format: first 4 bytes = magic, then version/build info
  const magic = buf.slice(0, 4).toString("hex").toUpperCase();
  let version = 0, build = 0;
  // Build number often at offset 4-6 (little-endian uint16)
  if (buf.length > 6) {
    build = buf.readUInt16LE(4);
    version = buf.readUInt16LE(6);
  }
  // Type detection: check magic signature patterns
  // Standard EX4: starts with 0x44 or common MetaTrader headers
  const isExpert = magic.startsWith("44") || magic.startsWith("4D51"); // "MQ" in hex
  const isIndicator = magic.startsWith("4943") || build < 600; // heuristic
  const isScript = !isExpert && !isIndicator;

  // Try to read compile date from offset 12 (unix timestamp, optional)
  let dateCompiled = "غير معروف";
  try {
    if (buf.length > 16) {
      const ts = buf.readUInt32LE(12);
      if (ts > 1000000000 && ts < 2000000000) {
        dateCompiled = new Date(ts * 1000).toISOString().split("T")[0];
      }
    }
  } catch { /* ignore */ }

  return { magic, version, build, dateCompiled, isExpert, isIndicator, isScript };
}

function extractEX4Strings(buf: Buffer): string[] {
  const strings: string[] = [];
  const seen = new Set<string>();
  let i = 0;
  while (i < buf.length) {
    // Collect printable ASCII chars (min length 4)
    let start = i;
    while (i < buf.length && buf[i] >= 0x20 && buf[i] <= 0x7e) i++;
    const len = i - start;
    if (len >= 4) {
      const s = buf.slice(start, start + len).toString("ascii").trim();
      if (s && !seen.has(s)) {
        seen.add(s);
        strings.push(s);
      }
    }
    // Also check UTF-16LE (common in MQL4 strings)
    if (i < buf.length - 1 && buf[i] === 0 && i - start === 0) {
      // Scan UTF-16LE
      let u16start = i;
      let chars = "";
      while (i < buf.length - 1 && buf[i + 1] === 0 && buf[i] >= 0x20 && buf[i] <= 0x7e) {
        chars += String.fromCharCode(buf[i]);
        i += 2;
      }
      if (chars.length >= 4 && !seen.has(chars)) {
        seen.add(chars);
        strings.push(chars);
      } else {
        i = u16start + 1;
      }
    } else {
      i++;
    }
  }
  return strings;
}

function classifyEX4Strings(strings: string[]): {
  properties: Record<string, string>;
  functions: string[];
  indicators: string[];
  messages: string[];
  other: string[];
} {
  const properties: Record<string, string> = {};
  const functions: string[] = [];
  const indicators: string[] = [];
  const messages: string[] = [];
  const other: string[] = [];

  // MQL4 built-in property patterns
  const propPatterns = [
    "#property", "copyright", "link", "version", "description",
    "#define", "extern", "input", "sinput",
  ];
  // MQL4 function patterns
  const funcPatterns = [
    "OnInit", "OnDeinit", "OnTick", "OnCalculate", "OnTimer", "OnTrade",
    "OrderSend", "OrderClose", "OrderModify", "OrderSelect", "OrdersTotal",
    "iMA", "iRSI", "iMACD", "iBands", "iStochastic", "iCCI", "iADX",
    "Alert", "Print", "Comment", "MessageBox", "PlaySound",
    "AccountBalance", "AccountEquity", "AccountFreeMargin",
    "Bid", "Ask", "Digits", "Point", "Symbol", "Period",
  ];
  // Technical indicator names
  const indPatterns = [
    "MA", "RSI", "MACD", "Stochastic", "Bollinger", "ATR", "ADX",
    "EMA", "SMA", "WMA", "CCI", "DeMarker", "Envelopes", "Force",
    "Momentum", "MFI", "OsMA", "SAR", "RVI", "Williams",
  ];

  for (const s of strings) {
    const lower = s.toLowerCase();
    if (propPatterns.some(p => lower.includes(p.toLowerCase()))) {
      // Try to extract key=value
      const eq = s.indexOf(" ");
      if (eq > 0) {
        properties[s.substring(0, eq).trim()] = s.substring(eq).trim();
      } else {
        properties[s] = "";
      }
    } else if (funcPatterns.some(p => s.includes(p))) {
      functions.push(s);
    } else if (indPatterns.some(p => s.includes(p))) {
      indicators.push(s);
    } else if (s.includes(" ") && s.length > 8 && s.length < 200) {
      messages.push(s);
    } else {
      other.push(s);
    }
  }

  return { properties, functions, indicators, messages, other };
}

export async function analyzeEX4(ex4Buffer: Buffer, fileName: string): Promise<DecompileResult> {
  try {
    const files: DecompiledFile[] = [];
    const header = parseEX4Header(ex4Buffer);
    const strings = extractEX4Strings(ex4Buffer);
    const classified = classifyEX4Strings(strings);

    // Detect program type more accurately from strings
    const hasOnTick = strings.some(s => s.includes("OnTick") || s.includes("start"));
    const hasOnCalculate = strings.some(s => s.includes("OnCalculate") || s.includes("init"));
    let programType = "Expert Advisor (مستشار آلي)";
    if (strings.some(s => s.includes("OnCalculate"))) {
      programType = "Custom Indicator (مؤشر مخصص)";
    } else if (!hasOnTick && strings.some(s => s.includes("OnStart"))) {
      programType = "Script (سكريبت)";
    }

    // Build header info file
    const headerContent = [
      "══════════════════════════════════",
      "  معلومات ملف EX4 — HAYO AI",
      "══════════════════════════════════",
      `الملف: ${fileName}`,
      `الحجم: ${formatBytes(ex4Buffer.length)}`,
      `Magic Bytes: ${header.magic}`,
      `Build Number: ${header.build || "غير محدد"}`,
      `نوع البرنامج: ${programType}`,
      `تاريخ الترجمة: ${header.dateCompiled}`,
      `المنصة: MetaTrader 4 (MQL4)`,
      "",
      "── ملاحظة مهمة ──",
      "ملف EX4 هو ملف مترجم (Compiled Binary) من MetaTrader 4.",
      "لا يمكن استعادة الكود المصدري الكامل — لكن يمكن استخراج:",
      "• أسماء الدوال والمتغيرات",
      "• الرسائل والنصوص المضمّنة",
      "• إعدادات الخصائص (Properties)",
      "• أسماء المؤشرات المستخدمة",
      "",
      "لاستعادة الكود: ابحث عن نسخة .mq4 الأصلية",
      "أو جرّب: Decompiler EX4 to MQ4 (أدوات متخصصة خارجية)",
    ].join("\n");

    files.push({
      path: "info/header-info.txt",
      name: "header-info.txt",
      extension: ".txt",
      size: headerContent.length,
      content: headerContent,
      isBinary: false,
    });

    // Properties file
    const propsContent = Object.keys(classified.properties).length > 0
      ? Object.entries(classified.properties).map(([k, v]) => `${k}: ${v}`).join("\n")
      : "(لم يتم العثور على خصائص مضمّنة)";

    files.push({
      path: "analysis/properties.txt",
      name: "properties.txt",
      extension: ".txt",
      size: propsContent.length,
      content: [
        "══ خصائص البرنامج (Properties) ══",
        propsContent,
      ].join("\n"),
      isBinary: false,
    });

    // Functions found
    if (classified.functions.length > 0) {
      const funcsContent = classified.functions.join("\n");
      files.push({
        path: "analysis/functions-detected.txt",
        name: "functions-detected.txt",
        extension: ".txt",
        size: funcsContent.length,
        content: [
          "══ دوال MQL4 المكتشفة ══",
          `(تم العثور على ${classified.functions.length} دالة)`,
          "",
          funcsContent,
        ].join("\n"),
        isBinary: false,
      });
    }

    // Indicators used
    if (classified.indicators.length > 0) {
      const indContent = classified.indicators.join("\n");
      files.push({
        path: "analysis/indicators-used.txt",
        name: "indicators-used.txt",
        extension: ".txt",
        size: indContent.length,
        content: [
          "══ المؤشرات التقنية المستخدمة ══",
          `(تم اكتشاف ${classified.indicators.length} مؤشر)`,
          "",
          indContent,
        ].join("\n"),
        isBinary: false,
      });
    }

    // User messages
    if (classified.messages.length > 0) {
      const msgs = classified.messages.slice(0, 200).join("\n");
      files.push({
        path: "analysis/messages-strings.txt",
        name: "messages-strings.txt",
        extension: ".txt",
        size: msgs.length,
        content: [
          "══ الرسائل والنصوص المضمّنة ══",
          `(أول 200 نص)`,
          "",
          msgs,
        ].join("\n"),
        isBinary: false,
      });
    }

    // All extracted strings
    const allStrings = strings.slice(0, 2000).join("\n");
    files.push({
      path: "analysis/all-extracted-strings.txt",
      name: "all-extracted-strings.txt",
      extension: ".txt",
      size: allStrings.length,
      content: [
        `══ جميع النصوص المستخرجة (${strings.length} نص) ══`,
        "",
        allStrings,
      ].join("\n"),
      isBinary: false,
    });

    // MQL4 reconstruction hint
    const reconstructHint = [
      "══ محاولة إعادة بناء الهيكل (Skeleton) ══",
      "",
      `// ملف: ${fileName.replace(".ex4", ".mq4")} — هيكل مُعاد بناؤه بواسطة HAYO AI`,
      `// تحذير: هذا ليس الكود الأصلي — تم استنتاجه من البيانات المستخرجة`,
      "",
      `// نوع البرنامج: ${programType}`,
      "",
      ...Object.entries(classified.properties).map(([k, v]) => `#property ${k} "${v}"`),
      "",
      "//+------------------------------------------------------------------+",
      "//| دوال مكتشفة:                                                      |",
      "//+------------------------------------------------------------------+",
      ...classified.functions.slice(0, 30).map(f => `// ${f}`),
      "",
      "//+------------------------------------------------------------------+",
      "//| مؤشرات مستخدمة:                                                   |",
      "//+------------------------------------------------------------------+",
      ...classified.indicators.slice(0, 20).map(ind => `// ${ind}`),
    ].join("\n");

    files.push({
      path: "reconstruction/skeleton.mq4",
      name: "skeleton.mq4",
      extension: ".mq4",
      size: reconstructHint.length,
      content: reconstructHint,
      isBinary: false,
    });

    // ── AI Power Decompile (أقوى نموذج لإعادة البناء الكامل) ────────────
    let aiModelUsed = "";
    try {
      const { content: aiContent, modelUsed } = await aiPowerDecompile(
        ex4Buffer, fileName, ".ex4", strings
      );
      aiModelUsed = modelUsed;
      if (aiContent) {
        const header = [
          `╔══════════════════════════════════════════════════╗`,
          `║  إعادة بناء AI العميق — ${modelUsed}`,
          `║  الملف: ${fileName}`,
          `╚══════════════════════════════════════════════════╝`,
          "",
        ].join("\n");
        // Extract code block if present (the AI may return MQ4 code in a ```mq4 block)
        const mq4Match = aiContent.match(/```(?:mq4|mql4|cpp|c\+\+)?\n([\s\S]+?)```/i);
        const mq4Code = mq4Match ? mq4Match[1] : aiContent;

        files.push({
          path: "ai-decompile/ai-reconstructed.mq4",
          name: "ai-reconstructed.mq4",
          extension: ".mq4",
          size: mq4Code.length,
          content: `// ══ إعادة بناء AI (${modelUsed}) ══\n// الملف الأصلي: ${fileName}\n\n` + mq4Code,
          isBinary: false,
        });
        files.push({
          path: "ai-decompile/ai-full-analysis.md",
          name: "ai-full-analysis.md",
          extension: ".md",
          size: aiContent.length,
          content: header + aiContent,
          isBinary: false,
        });
      }
    } catch (aiErr: any) {
      console.warn("[analyzeEX4] AI Power Decompile failed:", aiErr.message);
      files.push({
        path: "ai-decompile/ai-error.txt",
        name: "ai-error.txt",
        extension: ".txt",
        size: 0,
        content: `تعذّر إجراء التحليل AI العميق: ${aiErr.message}`,
        isBinary: false,
      });
    }

    // Build ZIP
    const outputZip = new JSZip();
    for (const f of files) {
      if (f.content) outputZip.file(f.path, f.content);
    }
    const zipBuffer = await outputZip.generateAsync({ type: "nodebuffer" });

    return {
      success: true,
      fileType: "exe",  // reuse exe display type for frontend
      totalFiles: files.length,
      totalSize: ex4Buffer.length,
      structure: buildFileTree(files),
      files,
      metadata: {
        originalSize: formatBytes(ex4Buffer.length),
        fileName,
        programType,
        build: header.build,
        dateCompiled: header.dateCompiled,
        stringsCount: strings.length,
        functionsCount: classified.functions.length,
        indicatorsCount: classified.indicators.length,
        ex4Magic: header.magic,
        aiModelUsed,
      },
      zipBuffer,
      analysisAvailable: true,
    };
  } catch (err: any) {
    return {
      success: false,
      fileType: "exe",
      totalFiles: 0,
      totalSize: 0,
      structure: [],
      files: [],
      error: `فشل تحليل EX4: ${err.message}`,
      analysisAvailable: false,
    };
  }
}

// ════════════════════════════════════════
// AI Analysis
// ════════════════════════════════════════

export async function analyzeWithAI(
  code: string,
  fileName: string,
  analysisType: "explain" | "security" | "logic" | "full"
): Promise<string> {
  const prompts: Record<string, string> = {
    explain: `أنت خبير هندسة عكسية. حلل هذا الكود المفكك من ملف "${fileName}" واشرح بالتفصيل:
1. ماذا يفعل هذا الكود؟
2. ما هي الوظائف الرئيسية؟
3. ما هي المكتبات المستخدمة؟
4. كيف يعمل التطبيق بشكل عام؟
اشرح بلغة بسيطة ومفهومة.`,

    security: `أنت خبير أمن سيبراني. حلل هذا الكود المفكك من ملف "${fileName}" وابحث عن:
1. 🔴 ثغرات أمنية حرجة
2. 🟡 مفاتيح API أو كلمات سر مكشوفة (hardcoded secrets)
3. 🟡 اتصالات شبكة غير مشفرة
4. 🟡 صلاحيات خطيرة
5. 🟢 توصيات لتحسين الأمان
صنّف كل نتيجة حسب خطورتها.`,

    logic: `أنت خبير هندسة برمجيات. حلل هذا الكود المفكك من ملف "${fileName}":
1. ارسم خريطة المنطق البرمجي (flow)
2. حدد نقاط الدخول (entry points)
3. حدد استدعاءات API الخارجية
4. حدد آليات تخزين البيانات
5. حدد آليات المصادقة (authentication)
قدم التحليل بشكل منظم.`,

    full: `أنت خبير هندسة عكسية متقدم. قدم تحليلاً شاملاً لهذا الكود المفكك من ملف "${fileName}":

📋 **نظرة عامة:** ماذا يفعل التطبيق؟
🏗️ **البنية:** كيف منظم الكود؟ ما هي الأنماط المستخدمة؟
🔌 **الاتصالات:** أي APIs أو خوادم يتصل بها؟
💾 **البيانات:** كيف يخزن البيانات؟
🔐 **الأمان:** ثغرات؟ مفاتيح مكشوفة؟ صلاحيات خطيرة؟
📦 **المكتبات:** ما المكتبات الخارجية المستخدمة؟
⚠️ **ملاحظات:** أي شيء مثير للاهتمام أو مشبوه؟

قدم التحليل بالعربية بشكل مفصل ومنظم.`,
  };

  const systemPrompt = "أنت خبير هندسة عكسية وأمن سيبراني. تحلل الأكواد المفككة بدقة عالية وتقدم نتائج مفصلة ومنظمة. أجب بالعربية.";

  const result = await callOfficeAI(
    systemPrompt,
    `${prompts[analysisType] || prompts.full}\n\nالكود:\n\`\`\`\n${code.substring(0, 30_000)}\n\`\`\``,
    8192,
    "claude-sonnet-4-6"
  );

  return result;
}

// ════════════════════════════════════════
// Helper Functions
// ════════════════════════════════════════

function parseAndroidManifestBasic(buf: Buffer): any {
  try {
    const str = buf.toString("utf-8");
    const packageMatch = str.match(/package="([^"]+)"/);
    const versionMatch = str.match(/versionName="([^"]+)"/);
    const permRegex = /android\.permission\.([A-Z_]+)/g;
    const permissions: string[] = [];
    let m;
    while ((m = permRegex.exec(str)) !== null) {
      if (!permissions.includes(m[1])) permissions.push(m[1]);
    }
    return {
      packageName: packageMatch?.[1] || "غير محدد",
      versionName: versionMatch?.[1] || "غير محدد",
      permissions,
    };
  } catch {
    try {
      const strings = extractUTF16Strings(buf);
      const packageName = strings.find(s => s.includes(".") && !s.includes(" ") && s.length > 5 && s.length < 80);
      const permissions = strings.filter(s => s.startsWith("android.permission."));
      return {
        packageName: packageName || "غير محدد (Binary XML)",
        permissions,
        note: "تم استخراج المعلومات من Binary XML",
      };
    } catch {
      return { note: "فشل تحليل Manifest" };
    }
  }
}

function extractUTF16Strings(buf: Buffer): string[] {
  const strings: string[] = [];
  let current = "";
  for (let i = 0; i < buf.length - 1; i += 2) {
    const char = buf.readUInt16LE(i);
    if (char >= 32 && char < 127) {
      current += String.fromCharCode(char);
    } else {
      if (current.length >= 4) strings.push(current);
      current = "";
    }
  }
  if (current.length >= 4) strings.push(current);
  return strings;
}

function parsePEBasic(buf: Buffer): any {
  try {
    if (buf[0] !== 0x4D || buf[1] !== 0x5A) {
      return { error: "ليس ملف EXE صالح (لا يحتوي MZ header)" };
    }
    const peOffset = buf.readUInt32LE(0x3C);
    if (buf.readUInt32LE(peOffset) !== 0x00004550) {
      return { error: "PE signature غير صالح" };
    }
    const machine = buf.readUInt16LE(peOffset + 4);
    const machineTypes: Record<number, string> = {
      0x014C: "x86 (32-bit)", 0x8664: "x64 (64-bit)",
      0xAA64: "ARM64", 0x01C0: "ARM",
    };
    const numSections = buf.readUInt16LE(peOffset + 6);
    const timestamp = buf.readUInt32LE(peOffset + 8);
    const compileDate = new Date(timestamp * 1000).toISOString().split("T")[0];
    const characteristics = buf.readUInt16LE(peOffset + 22);
    const isDLL = !!(characteristics & 0x2000);
    return {
      architecture: machineTypes[machine] || `Unknown (0x${machine.toString(16)})`,
      sections: numSections,
      compileDate,
      isDLL,
      type: isDLL ? "DLL (مكتبة)" : "EXE (تطبيق)",
    };
  } catch (err: any) {
    return { error: `فشل تحليل PE: ${err.message}` };
  }
}

function detectDotNet(buf: Buffer): boolean {
  const str = buf.toString("ascii", 0, Math.min(buf.length, 1_000_000));
  return str.includes("mscoree.dll") || str.includes("_CorExeMain") || str.includes("System.Runtime");
}

function extractStrings(buf: Buffer, minLength = 6): string[] {
  const strings: string[] = [];
  let current = "";
  for (let i = 0; i < buf.length; i++) {
    const byte = buf[i];
    if (byte >= 32 && byte < 127) {
      current += String.fromCharCode(byte);
    } else {
      if (current.length >= minLength && !strings.includes(current) && !/^[.\-_=]+$/.test(current)) {
        strings.push(current);
      }
      current = "";
    }
  }
  if (current.length >= minLength && !strings.includes(current)) strings.push(current);
  return strings
    .sort((a, b) => {
      const score = (s: string) => (s.includes("http") ? 100 : 0) + (s.includes("api") ? 50 : 0) + (s.includes("key") ? 50 : 0);
      return score(b) - score(a);
    })
    .slice(0, 5000);
}

function readDirRecursive(dir: string): string[] {
  const results: string[] = [];
  try {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) results.push(...readDirRecursive(full));
      else results.push(full);
    }
  } catch { /* skip */ }
  return results;
}

function buildFileTree(files: DecompiledFile[]): FileTreeNode[] {
  const root: Record<string, any> = {};
  for (const file of files) {
    const parts = file.path.split("/");
    let current = root;
    for (let i = 0; i < parts.length; i++) {
      const part = parts[i];
      if (i === parts.length - 1) {
        if (!current._files) current._files = [];
        current._files.push({ name: part, path: file.path, type: "file" as const, size: file.size });
      } else {
        if (!current[part]) current[part] = {};
        current = current[part];
      }
    }
  }

  function convert(obj: Record<string, any>, _prefix = ""): FileTreeNode[] {
    const nodes: FileTreeNode[] = [];
    for (const [key, value] of Object.entries(obj)) {
      if (key === "_files") continue;
      nodes.push({ name: key, path: key, type: "folder", children: convert(value, key) });
    }
    if (obj._files) nodes.push(...obj._files);
    return nodes;
  }
  return convert(root);
}

function generateAPKReport(fileName: string, files: DecompiledFile[], manifest: any, jadxSuccess: boolean): string {
  return [
    `══════════════════════════════════════`,
    `  تقرير الهندسة العكسية — HAYO AI`,
    `══════════════════════════════════════`,
    ``,
    `الملف: ${fileName}`,
    `التاريخ: ${new Date().toLocaleString("ar-SA")}`,
    `عدد الملفات المستخرجة: ${files.length}`,
    `تفكيك Java/Kotlin: ${jadxSuccess ? "✅ ناجح" : "❌ غير متاح (JADX غير مثبت)"}`,
    ``,
    manifest ? `══ معلومات التطبيق ══` : "",
    manifest?.packageName ? `اسم الحزمة: ${manifest.packageName}` : "",
    manifest?.versionName ? `الإصدار: ${manifest.versionName}` : "",
    manifest?.permissions?.length ? `\nالصلاحيات (${manifest.permissions.length}):` : "",
    ...(manifest?.permissions || []).map((p: string) => `  • ${p}`),
    ``,
    `══ أنواع الملفات ══`,
    `ملفات كود: ${files.filter(f => [".java", ".kt", ".smali", ".js"].includes(f.extension)).length}`,
    `ملفات موارد: ${files.filter(f => f.path.startsWith("res/")).length}`,
    `ملفات أصول: ${files.filter(f => f.path.startsWith("assets/")).length}`,
    `مكتبات أصلية: ${files.filter(f => f.extension === ".so").length}`,
    ``,
    `══ تم بواسطة HAYO AI ══`,
  ].filter(l => l !== undefined).join("\n");
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

function cleanupDir(dir: string) {
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* ignore */ }
}

// ════════════════════════════════════════
// Vulnerability Scanner
// ════════════════════════════════════════

export function scanVulnerabilities(
  files: DecompiledFile[],
  fileType: string,
  extraStrings: string[] = []
): VulnerabilityFinding[] {
  const findings: VulnerabilityFinding[] = [];
  const allContent = files.map(f => f.content || "").join("\n");
  const allStrings = [...extraStrings, ...allContent.split("\n")].filter(Boolean);

  // 1. Hardcoded credentials
  const credEvidence: string[] = [];
  const credPatterns = [
    /(?:password|passwd|pwd)\s*[=:]\s*["']([^"']{8,})["']/gi,
    /(?:api[_\-]?key|apikey|api_secret)\s*[=:]\s*["']([^"']{10,})["']/gi,
    /(?:secret|token|access_key)\s*[=:]\s*["']([A-Za-z0-9+/]{20,})["']/gi,
  ];
  for (const p of credPatterns) {
    const m = allContent.match(p) || [];
    credEvidence.push(...m.slice(0, 3).map(s => s.replace(/"[^"]{8,}"/, '"[REDACTED]"')));
  }
  if (credEvidence.length > 0) {
    findings.push({ severity: "critical", category: "Information Disclosure", title: "بيانات اعتماد مضمّنة في الكود", description: "تم اكتشاف كلمات مرور أو مفاتيح API مضمّنة في الكود.", evidence: credEvidence.slice(0, 5) });
  }

  // 2. HTTP URLs
  const httpUrls = allStrings.filter(s => /^http:\/\/[a-z]/.test(s) && s.length > 12).slice(0, 8);
  if (httpUrls.length > 0) {
    findings.push({ severity: "medium", category: "Insecure Communication", title: "اتصالات HTTP غير مشفرة", description: "تم اكتشاف روابط HTTP — يجب استخدام HTTPS لتشفير الاتصالات.", evidence: httpUrls.slice(0, 5) });
  }

  // 3. Debug build
  const debugHints = allStrings.filter(s => /android:debuggable="true"|BuildConfig\.DEBUG\s*=\s*true|debuggable.*=.*true/i.test(s)).slice(0, 3);
  if (debugHints.length > 0 || allContent.includes('android:debuggable="true"')) {
    findings.push({ severity: "high", category: "Debug Configuration", title: "وضع Debug مفعّل في التطبيق", description: "يسهل وضع Debug اختراق التطبيق وتحليله.", evidence: debugHints });
  }

  // 4. Weak crypto
  const weakCrypto = allStrings.filter(s => /\b(MD5|SHA1|DES\b|RC4|ECB)\b/i.test(s)).slice(0, 5);
  if (weakCrypto.length > 0) {
    findings.push({ severity: "high", category: "Weak Cryptography", title: "خوارزميات تشفير ضعيفة", description: "اكتشاف MD5/SHA1/DES/RC4 — هذه الخوارزميات مكسورة أو ضعيفة أمنياً.", evidence: weakCrypto });
  }

  // 5. SQL Injection
  const sqlRisk = allStrings.filter(s => /rawQuery|execSQL\(.*\+|WHERE.*\+.*=/.test(s)).slice(0, 4);
  if (sqlRisk.length > 0) {
    findings.push({ severity: "high", category: "SQL Injection Risk", title: "خطر SQL Injection", description: "استخدام بناء SQL ديناميكي غير آمن.", evidence: sqlRisk.slice(0, 3) });
  }

  // 6. SSL Pinning check
  const hasPinning = allStrings.some(s => /CertificatePinner|TrustKit|ssl_pinning|checkServerTrusted|CertificateChain/i.test(s));
  findings.push({ severity: "info", category: "SSL/TLS Security", title: hasPinning ? "✅ SSL Pinning مفعّل" : "⚠️ SSL Pinning غير موجود", description: hasPinning ? "التطبيق يستخدم Certificate Pinning لمنع MITM attacks." : "لا يوجد Certificate Pinning — التطبيق قد يكون عرضة لهجمات MITM.", evidence: [] });

  // 7. Root/Jailbreak detection
  const hasRootDetect = allStrings.some(s => /isRooted|su\b|Superuser|RootBeer|checkRootBeer|isJailbroken|jailbreak/i.test(s));
  findings.push({ severity: "info", category: "Device Integrity", title: hasRootDetect ? "✅ كشف Root/Jailbreak موجود" : "⚠️ لا يوجد كشف للـ Root/Jailbreak", description: hasRootDetect ? "التطبيق يحاول اكتشاف الأجهزة المعدَّلة." : "التطبيق لا يتحقق من سلامة الجهاز.", evidence: [] });

  // 8. Anti-debugging
  const hasAntiDebug = allStrings.some(s => /isDebuggerConnected|TracerPid|ptrace|SIGKILL|DEBUG_FLAG/i.test(s));
  if (!hasAntiDebug && (fileType === "apk" || fileType === "exe")) {
    findings.push({ severity: "low", category: "Anti-Debugging", title: "لا يوجد حماية من Debugger", description: "لم يتم اكتشاف آليات منع الـ debugging.", evidence: [] });
  }

  // 9. Exposed components (APK)
  if (fileType === "apk") {
    const exported = (allContent.match(/android:exported="true"/g) || []).length;
    if (exported > 3) {
      findings.push({ severity: "medium", category: "Exposed Components", title: `${exported} مكوّن مُصدَّر`, description: "عدد كبير من المكونات مُصدَّرة ومتاحة لتطبيقات أخرى.", evidence: [`android:exported="true" تكررت ${exported} مرة`] });
    }
  }

  // 10. Obfuscation detection
  const hasObfuscation = allStrings.some(s => /^[a-z]{1,2}$/.test(s)) || allContent.includes("ProGuard") || allContent.includes("R8");
  findings.push({ severity: "info", category: "Code Protection", title: hasObfuscation ? "✅ التطبيق مُشفَّر (Obfuscated)" : "ℹ️ لا يوجد تشفير واضح", description: hasObfuscation ? "يستخدم التطبيق ProGuard/R8 أو تشفير مشابه." : "الكود غير مُشفَّر مما يسهل الهندسة العكسية.", evidence: [] });

  return findings;
}

// ════════════════════════════════════════
// PE Enhanced — Import & Export Table Parser
// ════════════════════════════════════════

interface PEImportedDLL { name: string; functions: string[]; }

function parsePEImports(buf: Buffer): { imports: PEImportedDLL[]; exports: string[] } {
  const imports: PEImportedDLL[] = [];
  const exports: string[] = [];
  try {
    if (buf.length < 0x40 || buf[0] !== 0x4d || buf[1] !== 0x5a) return { imports, exports };
    const peOffset = buf.readUInt32LE(0x3c);
    if (buf.length < peOffset + 24 || buf.readUInt32LE(peOffset) !== 0x00004550) return { imports, exports };
    const machine = buf.readUInt16LE(peOffset + 4);
    const is64 = machine === 0x8664;
    const numSections = buf.readUInt16LE(peOffset + 6);
    const optHdrOffset = peOffset + 24;
    const optHdrSize = buf.readUInt16LE(peOffset + 20);
    const sectionTableOffset = optHdrOffset + optHdrSize;

    interface PESection { va: number; rawOffset: number; size: number; }
    const sections: PESection[] = [];
    for (let i = 0; i < Math.min(numSections, 96); i++) {
      const so = sectionTableOffset + i * 40;
      if (so + 40 > buf.length) break;
      sections.push({ va: buf.readUInt32LE(so + 12), size: Math.max(buf.readUInt32LE(so + 16), buf.readUInt32LE(so + 20)), rawOffset: buf.readUInt32LE(so + 20) });
    }

    const rva2off = (rva: number): number => {
      for (const s of sections) {
        if (rva >= s.va && rva < s.va + s.size + 0x1000) {
          const off = rva - s.va + s.rawOffset;
          return off > 0 && off < buf.length ? off : 0;
        }
      }
      return 0;
    };
    const readStr = (off: number, max = 256): string => {
      if (off <= 0 || off >= buf.length) return "";
      let end = off;
      while (end < buf.length && end < off + max && buf[end] !== 0) end++;
      return buf.slice(off, end).toString("ascii").replace(/[^\x20-\x7e]/g, "");
    };

    // Import table (data directory entry 1)
    const impBaseOff = is64 ? optHdrOffset + 0x78 + 8 : optHdrOffset + 0x68 + 8;
    if (impBaseOff + 4 <= buf.length) {
      const impDirVA = buf.readUInt32LE(impBaseOff);
      if (impDirVA) {
        let idt = rva2off(impDirVA);
        let cnt = 0;
        while (idt > 0 && idt + 20 <= buf.length && cnt < 256) {
          const iltVA = buf.readUInt32LE(idt);
          const nameVA = buf.readUInt32LE(idt + 12);
          if (!iltVA && !nameVA) break;
          const dllName = readStr(rva2off(nameVA)).toLowerCase();
          if (dllName && /^[\w.\-]+$/.test(dllName)) {
            const funcs: string[] = [];
            let thunkOff = rva2off(iltVA || buf.readUInt32LE(idt + 16));
            let fc = 0;
            while (thunkOff > 0 && fc < 80) {
              const thunk = is64 && thunkOff + 8 <= buf.length ? buf.readBigUInt64LE(thunkOff) : BigInt(thunkOff + 4 <= buf.length ? buf.readUInt32LE(thunkOff) : 0);
              if (thunk === 0n) break;
              const highBit = is64 ? 0x8000000000000000n : 0x80000000n;
              if ((thunk & highBit) === 0n) {
                const fn = readStr(rva2off(Number(thunk)) + 2, 128);
                if (fn && /^[A-Za-z_][A-Za-z0-9_@?.$]*$/.test(fn)) funcs.push(fn);
              } else {
                funcs.push(`Ord#${Number(thunk & 0xffffn)}`);
              }
              thunkOff += is64 ? 8 : 4;
              fc++;
            }
            imports.push({ name: dllName, functions: funcs.slice(0, 50) });
          }
          idt += 20; cnt++;
        }
      }
    }

    // Export table (data directory entry 0)
    const expBaseOff = is64 ? optHdrOffset + 0x78 : optHdrOffset + 0x68;
    if (expBaseOff + 4 <= buf.length) {
      const expDirVA = buf.readUInt32LE(expBaseOff);
      if (expDirVA) {
        const expDir = rva2off(expDirVA);
        if (expDir > 0 && expDir + 40 <= buf.length) {
          const numNames = buf.readUInt32LE(expDir + 24);
          const namesPtrVA = buf.readUInt32LE(expDir + 32);
          const namesPtr = rva2off(namesPtrVA);
          for (let i = 0; i < Math.min(numNames, 500); i++) {
            const off = namesPtr + i * 4;
            if (off + 4 > buf.length) break;
            const fn = readStr(rva2off(buf.readUInt32LE(off)));
            if (fn && /^[A-Za-z_]/.test(fn)) exports.push(fn);
          }
        }
      }
    }
  } catch { /* ignore */ }
  return { imports, exports };
}

// ════════════════════════════════════════
// ELF Analysis (Linux .so / Android NDK / Native Executables)
// ════════════════════════════════════════

function parseELFBasic(buf: Buffer): Record<string, string> {
  try {
    if (buf.length < 64 || !(buf[0] === 0x7f && buf[1] === 0x45 && buf[2] === 0x4c && buf[3] === 0x46))
      return { error: "ليس ملف ELF صالح" };
    const cls = buf[4] === 1 ? "32-bit" : buf[4] === 2 ? "64-bit" : "Unknown";
    const endian = buf[5] === 1 ? "Little Endian" : "Big Endian";
    const typeMap: Record<number, string> = { 1: "Relocatable", 2: "Executable", 3: "Shared Object (.so)", 4: "Core Dump" };
    const machMap: Record<number, string> = { 3: "x86 (i386)", 8: "MIPS", 20: "PowerPC", 40: "ARM (32-bit)", 62: "x86-64 (AMD64)", 183: "ARM64 (AArch64)", 243: "RISC-V" };
    const t = buf.readUInt16LE(16), m = buf.readUInt16LE(18);
    return { class: cls, endianness: endian, type: typeMap[t] || `0x${t.toString(16)}`, machine: machMap[m] || `0x${m.toString(16)}` };
  } catch { return { error: "فشل تحليل ELF" }; }
}

export async function analyzeELF(elfBuffer: Buffer, fileName: string): Promise<DecompileResult> {
  const tmpDir = path.join(os.tmpdir(), `hayo-elf-${Date.now()}`);
  const elfPath = path.join(tmpDir, fileName);
  try {
    fs.mkdirSync(tmpDir, { recursive: true });
    fs.writeFileSync(elfPath, elfBuffer);
    const files: DecompiledFile[] = [];
    const elfInfo = parseELFBasic(elfBuffer);

    files.push({ path: "analysis/elf-info.json", name: "elf-info.json", extension: ".json", size: 0, content: JSON.stringify(elfInfo, null, 2), isBinary: false });

    // readelf full headers
    let readelfOut = "";
    try { readelfOut = execSync(`readelf -h -S -d "${elfPath}" 2>&1`, { timeout: 30000, maxBuffer: 5 * 1024 * 1024 }).toString(); } catch (e: any) { readelfOut = `readelf error: ${e.message}`; }
    if (readelfOut) files.push({ path: "analysis/readelf-headers.txt", name: "readelf-headers.txt", extension: ".txt", size: readelfOut.length, content: readelfOut.substring(0, 100000), isBinary: false });

    // Dynamic symbols
    let nmOut = "";
    try { nmOut = execSync(`nm -D "${elfPath}" 2>&1`, { timeout: 15000, maxBuffer: 5 * 1024 * 1024 }).toString(); } catch { /* skip */ }
    if (nmOut) files.push({ path: "analysis/dynamic-symbols.txt", name: "dynamic-symbols.txt", extension: ".txt", size: nmOut.length, content: nmOut.substring(0, 100000), isBinary: false });

    // All symbols (readelf -Ws)
    let allSymbols = "";
    try { allSymbols = execSync(`readelf -Ws "${elfPath}" 2>&1`, { timeout: 15000, maxBuffer: 5 * 1024 * 1024 }).toString(); } catch { /* skip */ }
    if (allSymbols) files.push({ path: "analysis/all-symbols.txt", name: "all-symbols.txt", extension: ".txt", size: allSymbols.length, content: allSymbols.substring(0, 100000), isBinary: false });

    // Strings with system tool
    let stringsOut = "";
    try { stringsOut = execSync(`strings -n 6 "${elfPath}"`, { timeout: 30000, maxBuffer: 10 * 1024 * 1024 }).toString(); } catch { stringsOut = extractStrings(elfBuffer).join("\n"); }
    if (stringsOut) files.push({ path: "analysis/strings.txt", name: "strings.txt", extension: ".txt", size: stringsOut.length, content: stringsOut.substring(0, 200000), isBinary: false });

    // Disassembly preview
    try {
      const disasm = execSync(`objdump -d -M intel "${elfPath}" 2>&1 | head -500`, { timeout: 30000, maxBuffer: 2 * 1024 * 1024, shell: true }).toString();
      if (disasm) files.push({ path: "analysis/disassembly-preview.asm", name: "disassembly-preview.asm", extension: ".asm", size: disasm.length, content: disasm, isBinary: false });
    } catch { /* skip */ }

    // JNI function detection
    const jniLines = (nmOut + "\n" + allSymbols).split("\n").filter(l => l.includes("Java_") && l.trim()).map(l => l.trim());
    if (jniLines.length > 0) {
      const jniContent = "# دوال JNI المكتشفة (Java Native Interface)\n\n" + jniLines.slice(0, 200).join("\n");
      files.push({ path: "analysis/jni-functions.txt", name: "jni-functions.txt", extension: ".txt", size: jniContent.length, content: jniContent, isBinary: false });
    }

    // Security scan
    const allStringsArr = stringsOut.split("\n").filter(s => s.trim().length >= 6).slice(0, 500);
    const vulnerabilities = scanVulnerabilities(files, "elf", allStringsArr);

    // AI Power Analysis
    let aiModelUsed = "";
    try {
      const sysPrompt = `أنت خبير متخصص في هندسة عكسية لملفات ELF (Linux Shared Objects وAndroid NDK Libraries وLinux Executables).
خبرتك الشاملة: ARM64/x86/MIPS assembly، JNI Android NDK، anti-debugging، certificate pinning، obfuscation، LLVM/GCC patterns.
مهمتك التحليل العميق:
1. معلومات ELF Header (class، machine، type، entry point)
2. الأقسام المهمة (.text، .data، .rodata، .dynamic، .plt، .got)
3. الدوال المُصدَّرة (خاصة JNI: Java_PackageName_ClassName_MethodName)
4. المكتبات المعتمدة (DT_NEEDED dependencies)
5. النصوص والثوابت وما تدل عليه
6. تقنيات الحماية المكتشفة
7. كود C/C++ شبه مُعاد بناؤه للدوال الرئيسية
8. توصيات للهندسة العكسية
اكتب بالعربية مع الكود بالإنجليزية.`;

      const usrMsg = `## الملف: ${fileName} (${formatBytes(elfBuffer.length)})
## ELF Info:
\`\`\`json
${JSON.stringify(elfInfo, null, 2)}
\`\`\`
## readelf Output:
\`\`\`
${readelfOut.substring(0, 4000)}
\`\`\`
## Dynamic Symbols (nm -D):
\`\`\`
${nmOut.substring(0, 2000)}
\`\`\`
## JNI Functions (${jniLines.length}):
\`\`\`
${jniLines.slice(0, 50).join("\n") || "لم يُكتشف أي دالة JNI"}
\`\`\`
## Strings (${allStringsArr.length}):
\`\`\`
${allStringsArr.join("\n")}
\`\`\`
## Hex Dump (أول 80KB):
\`\`\`
${generateHexDump(elfBuffer, 80_000)}
\`\`\``;

      const { content: aiContent, modelUsed } = await callPowerAI(sysPrompt, usrMsg, 16000);
      aiModelUsed = modelUsed;
      if (aiContent) {
        files.push({ path: "ai-decompile/ai-elf-analysis.md", name: "ai-elf-analysis.md", extension: ".md", size: aiContent.length, content: `# تحليل AI العميق (${modelUsed})\n# الملف: ${fileName}\n\n` + aiContent, isBinary: false });
      }
    } catch (e: any) { console.warn("[analyzeELF] AI failed:", e.message); }

    cleanupDir(tmpDir);
    const outputZip = new JSZip();
    for (const f of files) { if (f.content) outputZip.file(f.path, f.content); }
    const zipBuffer = await outputZip.generateAsync({ type: "nodebuffer" });

    return {
      success: true, fileType: "exe", totalFiles: files.length, totalSize: elfBuffer.length,
      structure: buildFileTree(files),
      files: files.map(f => ({ ...f, content: f.content?.substring(0, 50000) })),
      metadata: { format: "ELF (Linux/Android Native Library)", originalSize: formatBytes(elfBuffer.length), fileName, elfClass: elfInfo.class, machine: elfInfo.machine, elfType: elfInfo.type, jniFunctions: jniLines.length, aiModelUsed },
      zipBuffer, analysisAvailable: true, vulnerabilities,
    };
  } catch (err: any) {
    cleanupDir(tmpDir);
    return { success: false, fileType: "exe", totalFiles: 0, totalSize: 0, structure: [], files: [], error: `فشل تحليل ELF: ${err.message}`, analysisAvailable: false };
  }
}

// ════════════════════════════════════════
// IPA Analysis (iOS Apps)
// ════════════════════════════════════════

function parseInfoPlist(content: string): Record<string, string> {
  const info: Record<string, string> = {};
  try {
    const pairs = content.match(/<key>([\s\S]*?)<\/key>\s*<(?:string|integer|real)>([\s\S]*?)<\/(?:string|integer|real)>/g) || [];
    for (const p of pairs.slice(0, 80)) {
      const k = p.match(/<key>([\s\S]*?)<\/key>/)?.[1]?.trim();
      const v = p.match(/<(?:string|integer|real)>([\s\S]*?)<\/(?:string|integer|real)>/)?.[1]?.trim();
      if (k && v) info[k] = v;
    }
    const trues = content.match(/<key>([\s\S]*?)<\/key>\s*<true\/>/g) || [];
    for (const t of trues.slice(0, 30)) {
      const k = t.match(/<key>([\s\S]*?)<\/key>/)?.[1]?.trim();
      if (k) info[k] = "true";
    }
  } catch { /* skip */ }
  return info;
}

export async function analyzeIPA(ipaBuffer: Buffer, fileName: string): Promise<DecompileResult> {
  try {
    const files: DecompiledFile[] = [];
    const zip = await JSZip.loadAsync(ipaBuffer);
    let plistContent = "", mainBinaryName = "";
    let plistInfo: Record<string, string> = {};
    const frameworks: string[] = [], permissions: string[] = [];
    const allEntries = Object.keys(zip.files);

    for (const [entryName, entry] of Object.entries(zip.files)) {
      if (entry.dir) continue;
      // Info.plist
      if (entryName.match(/Payload\/[^/]+\.app\/Info\.plist$/i)) {
        plistContent = await entry.async("text");
        plistInfo = parseInfoPlist(plistContent);
        mainBinaryName = plistInfo["CFBundleExecutable"] || "";
        files.push({ path: "ios/Info.plist", name: "Info.plist", extension: ".plist", size: plistContent.length, content: plistContent.substring(0, 50000), isBinary: false });
      }
      // Entitlements
      if (entryName.endsWith(".entitlements")) {
        const data = await entry.async("text");
        files.push({ path: "ios/entitlements.plist", name: "entitlements.plist", extension: ".plist", size: data.length, content: data, isBinary: false });
      }
      // Embedded config files (Cordova/Ionic/React Native)
      if (entryName.match(/\.(js|json|config|xml|html)$/) && !entry.dir) {
        const data = await entry.async("uint8array");
        if (data.length < 200000) {
          const text = new TextDecoder("utf-8", { fatal: false }).decode(data);
          const relPath = entryName.replace(/^Payload\/[^/]+\.app\//, "app-content/");
          files.push({ path: relPath, name: path.basename(entryName), extension: path.extname(entryName), size: data.length, content: text.substring(0, 50000), isBinary: false });
        }
      }
      // Frameworks
      if (entryName.includes("/Frameworks/") && entryName.endsWith(".dylib")) {
        const fw = entryName.split("/Frameworks/")[1]?.split("/")[0];
        if (fw && !frameworks.includes(fw)) frameworks.push(fw);
      }
    }

    // Permissions
    for (const k of Object.keys(plistInfo)) {
      if (k.startsWith("NS") && k.endsWith("UsageDescription")) permissions.push(k);
    }

    files.push({ path: "ios/file-listing.txt", name: "file-listing.txt", extension: ".txt", size: 0, content: allEntries.join("\n"), isBinary: false });

    const summary = [
      `# تحليل iOS App (IPA) — ${fileName}`, ``,
      `## هوية التطبيق`,
      `الاسم: ${plistInfo["CFBundleName"] || plistInfo["CFBundleDisplayName"] || "غير معروف"}`,
      `Bundle ID: ${plistInfo["CFBundleIdentifier"] || "غير معروف"}`,
      `الإصدار: ${plistInfo["CFBundleShortVersionString"] || "غير معروف"} (Build: ${plistInfo["CFBundleVersion"] || "?"})`,
      `الملف التنفيذي: ${mainBinaryName || "غير معروف"}`,
      `iOS Minimum: ${plistInfo["MinimumOSVersion"] || "غير معروف"}`,
      ``, `## الصلاحيات (${permissions.length}):`,
      ...permissions.map(p => `- ${p}: ${plistInfo[p]}`),
      ``, `## الأطر (Frameworks) — ${frameworks.length}:`,
      ...frameworks.slice(0, 30).map(f => `- ${f}`),
      ``, `## إحصائيات`,
      `إجمالي الملفات: ${allEntries.length}`,
      `ملفات JS: ${allEntries.filter(e => e.endsWith(".js")).length}`,
    ].join("\n");
    files.push({ path: "ios/app-summary.md", name: "app-summary.md", extension: ".md", size: summary.length, content: summary, isBinary: false });

    const vulnerabilities = scanVulnerabilities(files, "ios", permissions);
    let aiModelUsed = "";

    try {
      const sysPrompt = `أنت خبير في هندسة عكسية لتطبيقات iOS.
خبرتك: Mach-O binary، iOS security، App Store distribution، entitlements، permissions، Objective-C/Swift.
مهمتك التحليل الشامل:
1. هوية التطبيق وبنيته التقنية
2. الصلاحيات والـ entitlements وتأثيرها على الخصوصية
3. الأطر المستخدمة ووظيفتها
4. تحليل أمني (SSL pinning، jailbreak detection، data storage)
5. طبيعة التطبيق (native/hybrid/React Native/Cordova)
6. توصيات للهندسة العكسية (Frida، Ghidra، class-dump، Hopper Disassembler)
اكتب بالعربية.`;

      const usrMsg = `## ${fileName} (${formatBytes(ipaBuffer.length)})
## Parsed Info.plist:
\`\`\`json
${JSON.stringify(plistInfo, null, 2).substring(0, 3000)}
\`\`\`
## الصلاحيات: ${permissions.join(", ")}
## الأطر: ${frameworks.slice(0, 20).join(", ")}
## ملفات المحتوى (JS/JSON): ${allEntries.filter(e => e.endsWith(".js") || e.endsWith(".json")).slice(0, 30).join(", ")}
## قائمة الملفات (أول 150):
${allEntries.slice(0, 150).join("\n")}`;

      const { content: aiContent, modelUsed } = await callPowerAI(sysPrompt, usrMsg, 12000);
      aiModelUsed = modelUsed;
      if (aiContent) files.push({ path: "ai-decompile/ai-ios-analysis.md", name: "ai-ios-analysis.md", extension: ".md", size: aiContent.length, content: `# تحليل iOS AI (${modelUsed})\n\n` + aiContent, isBinary: false });
    } catch (e: any) { console.warn("[analyzeIPA] AI:", e.message); }

    const outputZip = new JSZip();
    for (const f of files) { if (f.content) outputZip.file(f.path, f.content); }
    const zipBuffer = await outputZip.generateAsync({ type: "nodebuffer" });

    return {
      success: true, fileType: "apk", totalFiles: files.length, totalSize: ipaBuffer.length,
      structure: buildFileTree(files),
      files: files.map(f => ({ ...f, content: f.content?.substring(0, 50000) })),
      manifest: { packageName: plistInfo["CFBundleIdentifier"], versionName: plistInfo["CFBundleShortVersionString"], permissions },
      metadata: { format: "IPA (iOS App)", originalSize: formatBytes(ipaBuffer.length), appName: plistInfo["CFBundleName"] || plistInfo["CFBundleDisplayName"], bundleId: plistInfo["CFBundleIdentifier"], version: plistInfo["CFBundleShortVersionString"], mainBinary: mainBinaryName, frameworks: frameworks.length, permissions: permissions.length, totalFiles: allEntries.length, aiModelUsed },
      zipBuffer, analysisAvailable: true, vulnerabilities,
    };
  } catch (err: any) {
    return { success: false, fileType: "apk", totalFiles: 0, totalSize: 0, structure: [], files: [], error: `فشل تحليل IPA: ${err.message}`, analysisAvailable: false };
  }
}

// ════════════════════════════════════════
// JAR / AAR Analysis (Java Archives)
// ════════════════════════════════════════

export async function analyzeJAR(jarBuffer: Buffer, fileName: string, fileExt = "jar"): Promise<DecompileResult> {
  const tmpDir = path.join(os.tmpdir(), `hayo-jar-${Date.now()}`);
  const jarPath = path.join(tmpDir, fileName);
  const javaOutputDir = path.join(tmpDir, "java-source");
  try {
    fs.mkdirSync(tmpDir, { recursive: true });
    fs.writeFileSync(jarPath, jarBuffer);
    const files: DecompiledFile[] = [];
    let jadxSuccess = false;

    // Try JADX
    const jadxPaths = ["/home/runner/jadx/bin/jadx", "/usr/bin/jadx", "jadx"];
    let jadxBin = "";
    for (const p of jadxPaths) { try { execSync(`${p} --version`, { timeout: 5000, stdio: "pipe" }); jadxBin = p; break; } catch { } }

    if (jadxBin) {
      fs.mkdirSync(javaOutputDir, { recursive: true });
      try {
        execSync(`"${jadxBin}" --no-res --output-dir "${javaOutputDir}" "${jarPath}"`, { timeout: 120000, stdio: "pipe" });
        jadxSuccess = true;
        for (const jf of readDirRecursive(javaOutputDir)) {
          const relPath = path.relative(javaOutputDir, jf);
          const ext = path.extname(jf).toLowerCase();
          let content: string | undefined;
          try { const s = fs.statSync(jf); if (s.size < 500000) content = fs.readFileSync(jf, "utf-8"); } catch { }
          files.push({ path: `java-source/${relPath}`, name: path.basename(jf), extension: ext, size: fs.existsSync(jf) ? (fs.statSync(jf).size) : 0, content, isBinary: false });
        }
      } catch (e: any) { console.warn("[analyzeJAR] JADX:", e.message); }
    }

    // ZIP extraction for manifest and resources
    try {
      const zip = await JSZip.loadAsync(jarBuffer);
      const textExts = new Set([".java", ".kt", ".xml", ".json", ".properties", ".txt", ".gradle", ".mf", ".sf", ".yml", ".yaml"]);
      for (const [entryName, entry] of Object.entries(zip.files)) {
        if (entry.dir) continue;
        const ext = path.extname(entryName).toLowerCase();
        if (jadxSuccess && ext === ".class") continue; // already have java source
        const isText = textExts.has(ext);
        let content: string | undefined;
        if (isText) { try { const d = await entry.async("uint8array"); if (d.length < 200000) content = new TextDecoder("utf-8", { fatal: false }).decode(d); } catch { } }
        else if (ext === ".class") { content = `[Java bytecode — ${entryName}]`; }
        const data = await entry.async("uint8array");
        if (!files.some(f => f.path === entryName)) files.push({ path: entryName, name: path.basename(entryName), extension: ext, size: data.length, content, isBinary: !isText && ext !== ".class" });
      }
    } catch { /* skip */ }

    const sampleJava = files.filter(f => f.extension === ".java" && f.content).slice(0, 5).map(f => `// ${f.path}\n${f.content?.substring(0, 2000)}`).join("\n\n---\n\n");
    const vulnerabilities = scanVulnerabilities(files, fileExt === "aar" ? "apk" : "jar");
    let aiModelUsed = "";

    try {
      const { content: aiContent, modelUsed } = await callPowerAI(
        `أنت خبير في هندسة عكسية لملفات Java (JAR/AAR/DEX). تحليل شامل: هيكل المشروع، الكلاسات المهمة، APIs، حماية ProGuard/R8، نقاط الضعف، توصيات. اكتب بالعربية مع الكود بالإنجليزية.`,
        `## ${fileName} (${formatBytes(jarBuffer.length)}) — ${fileExt.toUpperCase()}\nJADX: ${jadxSuccess ? "✅ نجح" : "❌ غير متاح"}\nJava files: ${files.filter(f => f.extension === ".java").length}\nClass files: ${files.filter(f => f.extension === ".class").length}\n\n## كود Java:\n\`\`\`java\n${sampleJava.substring(0, 8000) || "لا يوجد كود مفكَّك"}\n\`\`\`\n\n## الملفات: ${files.slice(0, 100).map(f => f.path).join(", ")}`,
        12000
      );
      aiModelUsed = modelUsed;
      if (aiContent) files.push({ path: "ai-decompile/ai-jar-analysis.md", name: "ai-jar-analysis.md", extension: ".md", size: aiContent.length, content: `# تحليل AI — ${modelUsed}\n\n` + aiContent, isBinary: false });
    } catch (e: any) { console.warn("[analyzeJAR] AI:", e.message); }

    cleanupDir(tmpDir);
    const outputZip = new JSZip();
    for (const f of files) { if (f.content && !f.isBinary) outputZip.file(f.path, f.content); }
    const zipBuffer = await outputZip.generateAsync({ type: "nodebuffer" });

    return {
      success: true, fileType: "apk", totalFiles: files.length, totalSize: jarBuffer.length,
      structure: buildFileTree(files),
      files: files.map(f => ({ ...f, content: f.content?.substring(0, 50000) })),
      metadata: { format: `${fileExt.toUpperCase()} (Java Archive)`, originalSize: formatBytes(jarBuffer.length), jadxDecompiled: jadxSuccess, javaFiles: files.filter(f => f.extension === ".java").length, classFiles: files.filter(f => f.extension === ".class").length, aiModelUsed },
      zipBuffer, analysisAvailable: true, vulnerabilities,
    };
  } catch (err: any) {
    cleanupDir(tmpDir);
    return { success: false, fileType: "apk", totalFiles: 0, totalSize: 0, structure: [], files: [], error: `فشل تحليل ${fileExt.toUpperCase()}: ${err.message}`, analysisAvailable: false };
  }
}

// ════════════════════════════════════════
// EX5 Analysis (MetaTrader 5 MQL5)
// ════════════════════════════════════════

export async function analyzeEX5(ex5Buffer: Buffer, fileName: string): Promise<DecompileResult> {
  try {
    const files: DecompiledFile[] = [];
    const strings = extractEX4Strings(ex5Buffer);
    const classified = classifyEX4Strings(strings);

    const mql5Events = strings.filter(s =>
      ["OnStart", "OnInit", "OnDeinit", "OnTick", "OnTimer", "OnBookEvent", "OnTradeTransaction",
        "OnCalculate", "OnChartEvent", "CTrade", "COrderInfo", "CPositionInfo", "CAccountInfo"].some(k => s.includes(k))
    );
    const mql5Props = strings.filter(s =>
      ["#property", "copyright", "link", "version", "description", "indicator_buffers", "indicator_plots"].some(k => s.toLowerCase().includes(k.toLowerCase()))
    );
    const mql5Inds = strings.filter(s =>
      ["iMA", "iRSI", "iMACD", "iBands", "iCCI", "iStochastic", "iATR", "iADX", "iSAR", "iTEMA", "iDEMA"].some(k => s.includes(k))
    );

    const magic = ex5Buffer.slice(0, 4).toString("hex").toUpperCase();
    let build = 0; try { build = ex5Buffer.readUInt16LE(4); } catch { }

    const summary = [
      `# تحليل EX5 (MetaTrader 5 / MQL5) — ${fileName}`, ``,
      `## معلومات الملف`, `Magic: ${magic}`, `Build: ${build}`, `الحجم: ${formatBytes(ex5Buffer.length)}`,
      ``, `## الخصائص (${mql5Props.length}):`, ...mql5Props.slice(0, 20).map(p => `- ${p}`),
      ``, `## Event Handlers MQL5 (${mql5Events.length}):`, ...mql5Events.slice(0, 20).map(e => `- ${e}`),
      ``, `## المؤشرات الفنية (${mql5Inds.length}):`, ...mql5Inds.slice(0, 15).map(i => `- ${i}`),
      ``, `## جميع النصوص (${strings.length}):`, ...strings.slice(0, 80).map(s => `- ${s}`),
    ].join("\n");

    files.push({ path: "mql5/summary.md", name: "summary.md", extension: ".md", size: summary.length, content: summary, isBinary: false });
    files.push({ path: "mql5/strings.txt", name: "strings.txt", extension: ".txt", size: 0, content: strings.join("\n"), isBinary: false });

    let aiModelUsed = "";
    try {
      const sysPrompt = `أنت خبير متخصص في هندسة عكسية لملفات MQL5/EX5 (MetaTrader 5).
معرفتك: بنية EX5 الثنائية، MQL5 bytecode، event-driven architecture، CTrade/COrderInfo/CPositionInfo classes.
مهمتك إعادة بناء:
1. #property declarations
2. input/sinput parameters مع أنواعها وقيمها الافتراضية
3. Event handlers (OnInit، OnDeinit، OnTick، OnTimer إلخ)
4. منطق التداول وإدارة المراكز
5. المؤشرات الفنية وإعداداتها
6. كود MQL5 مُعاد بناؤه بالكامل مع تعليقات
اكتب الكود بالإنجليزية مع شرح بالعربية.`;

      const { content: aiContent, modelUsed } = await callPowerAI(
        sysPrompt,
        `## ${fileName} (${formatBytes(ex5Buffer.length)}) — MQL5 Expert/Indicator\n## Strings (${strings.length}):\n\`\`\`\n${strings.slice(0, 400).join("\n")}\n\`\`\`\n## Hex Dump:\n\`\`\`\n${generateHexDump(ex5Buffer, 150_000)}\n\`\`\``,
        16000
      );
      aiModelUsed = modelUsed;
      if (aiContent) {
        files.push({ path: "ai-decompile/ai-reconstructed.mq5", name: "ai-reconstructed.mq5", extension: ".mq5", size: aiContent.length, content: aiContent, isBinary: false });
      }
    } catch (e: any) { console.warn("[analyzeEX5] AI:", e.message); }

    const outputZip = new JSZip();
    for (const f of files) { if (f.content) outputZip.file(f.path, f.content); }
    const zipBuffer = await outputZip.generateAsync({ type: "nodebuffer" });

    return {
      success: true, fileType: "exe", totalFiles: files.length, totalSize: ex5Buffer.length,
      structure: buildFileTree(files), files,
      metadata: { format: "EX5 (MetaTrader 5 MQL5)", originalSize: formatBytes(ex5Buffer.length), magicBytes: magic, buildNumber: build, stringsCount: strings.length, mql5Events: mql5Events.length, aiModelUsed },
      zipBuffer, analysisAvailable: true,
    };
  } catch (err: any) {
    return { success: false, fileType: "exe", totalFiles: 0, totalSize: 0, structure: [], files: [], error: `فشل تحليل EX5: ${err.message}`, analysisAvailable: false };
  }
}

// ════════════════════════════════════════
// WASM Analysis (WebAssembly)
// ════════════════════════════════════════

interface WasmSection { id: number; name: string; size: number; }
function parseWasmSections(buf: Buffer): WasmSection[] {
  const sections: WasmSection[] = [];
  const names: Record<number, string> = { 0: "Custom", 1: "Type", 2: "Import", 3: "Function", 4: "Table", 5: "Memory", 6: "Global", 7: "Export", 8: "Start", 9: "Element", 10: "Code", 11: "Data", 12: "DataCount" };
  if (buf.length < 8 || buf[0] !== 0x00 || buf[1] !== 0x61 || buf[2] !== 0x73 || buf[3] !== 0x6d) return sections;
  let offset = 8;
  while (offset < buf.length - 1) {
    try {
      const id = buf[offset++];
      let size = 0, shift = 0;
      while (offset < buf.length) { const b = buf[offset++]; size |= (b & 0x7f) << shift; if (!(b & 0x80)) break; shift += 7; }
      sections.push({ id, name: names[id] || `Unknown(${id})`, size });
      offset += size;
    } catch { break; }
  }
  return sections;
}

export async function analyzeWASM(wasmBuffer: Buffer, fileName: string): Promise<DecompileResult> {
  try {
    const files: DecompiledFile[] = [];
    const sections = parseWasmSections(wasmBuffer);
    const ver = wasmBuffer.length >= 8 ? wasmBuffer.readUInt32LE(4) : 0;
    const strings = extractStrings(wasmBuffer, 4);

    const summary = [
      `# تحليل WebAssembly (WASM) — ${fileName}`,
      `Magic: 0x0061736D (\\0asm)`, `Version: ${ver} (${ver === 1 ? "MVP 1.0" : "?"})`,
      `الحجم: ${formatBytes(wasmBuffer.length)}`,
      ``, `## الأقسام (${sections.length}):`,
      ...sections.map(s => `- [${s.id}] ${s.name}: ${s.size} bytes`),
      ``, `## النصوص (${strings.length}):`, ...strings.slice(0, 60).map(s => `- ${s}`),
    ].join("\n");

    files.push({ path: "wasm/summary.md", name: "summary.md", extension: ".md", size: summary.length, content: summary, isBinary: false });
    files.push({ path: "wasm/sections.json", name: "sections.json", extension: ".json", size: 0, content: JSON.stringify(sections, null, 2), isBinary: false });
    files.push({ path: "wasm/strings.txt", name: "strings.txt", extension: ".txt", size: 0, content: strings.join("\n"), isBinary: false });

    let aiModelUsed = "";
    try {
      const { content: aiContent, modelUsed } = await callPowerAI(
        `أنت خبير في WebAssembly (WASM) وهندسته العكسية. تحليل: الأقسام، imports/exports، اللغة المصدر (C/C++/Rust/Go)، الدوال الرئيسية، تحليل أمني. اكتب WAT code للدوال المهمة. اكتب بالعربية.`,
        `## ${fileName} (${formatBytes(wasmBuffer.length)})\nVersion: ${ver}\nSections: ${sections.map(s => s.name).join(", ")}\nStrings: ${strings.slice(0, 100).join(", ")}\n\nHex:\n\`\`\`\n${generateHexDump(wasmBuffer, 80_000)}\n\`\`\``,
        12000
      );
      aiModelUsed = modelUsed;
      if (aiContent) files.push({ path: "ai-decompile/ai-wasm-analysis.md", name: "ai-wasm-analysis.md", extension: ".md", size: aiContent.length, content: `# تحليل WASM AI (${modelUsed})\n\n` + aiContent, isBinary: false });
    } catch (e: any) { console.warn("[analyzeWASM] AI:", e.message); }

    const outputZip = new JSZip();
    for (const f of files) { if (f.content) outputZip.file(f.path, f.content); }
    const zipBuffer = await outputZip.generateAsync({ type: "nodebuffer" });

    return {
      success: true, fileType: "exe", totalFiles: files.length, totalSize: wasmBuffer.length,
      structure: buildFileTree(files), files,
      metadata: { format: "WASM (WebAssembly)", originalSize: formatBytes(wasmBuffer.length), version: ver, sections: sections.length, aiModelUsed },
      zipBuffer, analysisAvailable: true,
    };
  } catch (err: any) {
    return { success: false, fileType: "exe", totalFiles: 0, totalSize: 0, structure: [], files: [], error: `فشل تحليل WASM: ${err.message}`, analysisAvailable: false };
  }
}

// ════════════════════════════════════════
// DEX Analysis (Dalvik Executable)
// ════════════════════════════════════════

export async function analyzeDEX(dexBuffer: Buffer, fileName: string): Promise<DecompileResult> {
  const tmpDir = path.join(os.tmpdir(), `hayo-dex-${Date.now()}`);
  const dexPath = path.join(tmpDir, fileName);
  const javaOutputDir = path.join(tmpDir, "java-source");
  try {
    fs.mkdirSync(tmpDir, { recursive: true });
    fs.writeFileSync(dexPath, dexBuffer);
    const files: DecompiledFile[] = [];
    let jadxSuccess = false;

    const magic = dexBuffer.slice(0, 7).toString("ascii").replace(/\x0a|\x00/g, "");
    const ver = dexBuffer.length > 7 ? dexBuffer.slice(4, 7).toString("ascii") : "?";
    const classCount = dexBuffer.length > 100 ? dexBuffer.readUInt32LE(96) : 0;

    const jadxPaths = ["/home/runner/jadx/bin/jadx", "/usr/bin/jadx", "jadx"];
    let jadxBin = "";
    for (const p of jadxPaths) { try { execSync(`${p} --version`, { timeout: 5000, stdio: "pipe" }); jadxBin = p; break; } catch { } }

    if (jadxBin) {
      fs.mkdirSync(javaOutputDir, { recursive: true });
      try {
        execSync(`"${jadxBin}" --no-res --output-dir "${javaOutputDir}" "${dexPath}"`, { timeout: 120000, stdio: "pipe" });
        jadxSuccess = true;
        for (const jf of readDirRecursive(javaOutputDir)) {
          const relPath = path.relative(javaOutputDir, jf);
          const ext = path.extname(jf).toLowerCase();
          let content: string | undefined;
          try { const s = fs.statSync(jf); if (s.size < 500000) content = fs.readFileSync(jf, "utf-8"); } catch { }
          files.push({ path: `java-source/${relPath}`, name: path.basename(jf), extension: ext, size: fs.existsSync(jf) ? fs.statSync(jf).size : 0, content, isBinary: false });
        }
      } catch (e: any) { console.warn("[analyzeDEX] JADX:", e.message); }
    }

    const strs = extractStrings(dexBuffer);
    files.push({ path: "dex/strings.txt", name: "strings.txt", extension: ".txt", size: 0, content: strs.join("\n"), isBinary: false });
    files.push({ path: "dex/info.txt", name: "info.txt", extension: ".txt", size: 0, content: `DEX Magic: ${magic}\nVersion: ${ver}\nClass Count: ${classCount}\nSize: ${formatBytes(dexBuffer.length)}\nJADX: ${jadxSuccess ? "✅ نجح" : "❌ غير متاح"}`, isBinary: false });

    const vulnerabilities = scanVulnerabilities(files, "apk", strs.slice(0, 500));
    const sampleJava = files.filter(f => f.extension === ".java" && f.content).slice(0, 4).map(f => `// ${f.path}\n${f.content?.substring(0, 2000)}`).join("\n\n");
    let aiModelUsed = "";

    try {
      const { content: aiContent, modelUsed } = await callPowerAI(
        `أنت خبير في تحليل DEX (Dalvik/ART). تحليل: class structure، obfuscation (ProGuard/R8)، وظيفة الكود، نقاط الضعف. اكتب بالعربية.`,
        `## ${fileName} (DEX v${ver})\nClasses: ${classCount}, JADX: ${jadxSuccess ? "✅" : "❌"}\n\`\`\`java\n${sampleJava.substring(0, 8000)}\n\`\`\`\nStrings: ${strs.slice(0, 200).join(", ")}`,
        12000
      );
      aiModelUsed = modelUsed;
      if (aiContent) files.push({ path: "ai-decompile/ai-dex-analysis.md", name: "ai-dex-analysis.md", extension: ".md", size: aiContent.length, content: aiContent, isBinary: false });
    } catch { /* skip */ }

    cleanupDir(tmpDir);
    const outputZip = new JSZip();
    for (const f of files) { if (f.content) outputZip.file(f.path, f.content); }
    const zipBuffer = await outputZip.generateAsync({ type: "nodebuffer" });

    return {
      success: true, fileType: "apk", totalFiles: files.length, totalSize: dexBuffer.length,
      structure: buildFileTree(files),
      files: files.map(f => ({ ...f, content: f.content?.substring(0, 50000) })),
      metadata: { format: `DEX (Dalvik v${ver})`, originalSize: formatBytes(dexBuffer.length), version: ver, classCount, jadxSuccess, aiModelUsed },
      zipBuffer, analysisAvailable: true, vulnerabilities,
    };
  } catch (err: any) {
    cleanupDir(tmpDir);
    return { success: false, fileType: "apk", totalFiles: 0, totalSize: 0, structure: [], files: [], error: `فشل تحليل DEX: ${err.message}`, analysisAvailable: false };
  }
}

// ════════════════════════════════════════
// Edit Sessions — In-memory store
// ════════════════════════════════════════

interface EditSession {
  dir: string;
  decompDir: string;
  apkPath: string;
  fileType: "apk" | "exe" | "dll" | "ex4" | "ex5" | "ipa" | "jar" | "aar" | "dex" | "so" | "elf" | "wasm";
  originalContents: Map<string, string>;
  modifiedPaths: Set<string>;
  expiresAt: number;
}

const editSessions = new Map<string, EditSession>();

setInterval(() => {
  const now = Date.now();
  for (const [id, session] of editSessions) {
    if (now > session.expiresAt) {
      cleanupDir(session.dir);
      editSessions.delete(id);
    }
  }
}, 10 * 60 * 1000);

// ════════════════════════════════════════
// Find APKTool
// ════════════════════════════════════════

// Returns apktool command string: either binary ("apktool") or jar path
export function findApkTool(): string | null {
  // 1. Check if apktool binary is available (nix install)
  try {
    execSync("apktool --version", { timeout: 5000, stdio: "pipe" });
    return "BINARY"; // Special marker: use "apktool" command
  } catch { /* not in PATH */ }

  // 2. Check common jar locations
  const jarPaths = [
    "/home/runner/apktool.jar",
    "/usr/local/bin/apktool.jar",
    path.join(process.cwd(), "apktool.jar"),
    "/tmp/apktool.jar",
  ];
  for (const p of jarPaths) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

// Build the apktool command based on what's available
function buildApkToolCmd(apktoolPath: string, args: string): string {
  if (apktoolPath === "BINARY") {
    return `apktool ${args}`;
  }
  return `java -jar "${apktoolPath}" ${args}`;
}

export function isJavaAvailable(): boolean {
  try {
    execSync("java -version", { timeout: 5000, stdio: "pipe" });
    return true;
  } catch {
    return false;
  }
}

export function isApkToolAvailable(): boolean {
  return !!findApkTool();
}

// ════════════════════════════════════════
// Decompile APK for Editing (APKTool mode)
// ════════════════════════════════════════

export async function decompileAPKForEdit(apkBuffer: Buffer): Promise<{
  success: boolean;
  sessionId: string;
  files: DecompiledFile[];
  structure: FileTreeNode[];
  usedApkTool: boolean;
  error?: string;
}> {
  const sessionId = `edit-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const sessionDir = path.join(os.tmpdir(), `hayo-edit-${sessionId}`);
  const apkPath = path.join(sessionDir, "original.apk");
  const decompDir = path.join(sessionDir, "decompiled");

  try {
    fs.mkdirSync(sessionDir, { recursive: true });
    fs.writeFileSync(apkPath, apkBuffer);

    const textExts = [
      ".smali", ".xml", ".txt", ".json", ".properties",
      ".yml", ".yaml", ".cfg", ".ini", ".pro", ".gradle", ".mf", ".sf",
    ];

    const files: DecompiledFile[] = [];
    let usedApkTool = false;

    // Try APKTool first
    const apktoolPath = findApkTool();
    if (apktoolPath) {
      try {
        execSync(
          buildApkToolCmd(apktoolPath, `d -f -o "${decompDir}" "${apkPath}"`),
          { timeout: 180000, stdio: "pipe" }
        );
        usedApkTool = true;
      } catch (apktoolErr: any) {
        console.warn("[RE] APKTool failed, falling back to ZIP:", apktoolErr.message);
      }
    }

    if (usedApkTool) {
      // Read from APKTool output
      const allFilePaths = readDirRecursive(decompDir);
      for (const filePath of allFilePaths) {
        const relPath = path.relative(decompDir, filePath);
        const ext = path.extname(filePath).toLowerCase();
        const isText = textExts.includes(ext);
        let content: string | undefined;
        if (isText) {
          try {
            const stat = fs.statSync(filePath);
            if (stat.size < 500000) content = fs.readFileSync(filePath, "utf-8");
          } catch { /* skip */ }
        }
        files.push({
          path: relPath,
          name: path.basename(filePath),
          extension: ext,
          size: (() => { try { return fs.statSync(filePath).size; } catch { return 0; } })(),
          content,
          isBinary: !isText,
        });
      }
    } else {
      // Fallback: ZIP extraction (same as decompileAPK)
      fs.mkdirSync(decompDir, { recursive: true });
      const zip = await JSZip.loadAsync(apkBuffer);
      for (const [entryName, entry] of Object.entries(zip.files)) {
        if (entry.dir) continue;
        const ext = path.extname(entryName).toLowerCase();
        const isText = textExts.includes(ext);
        const data = await entry.async("nodebuffer");
        // Write to disk so we can rebuild as ZIP later
        const fullPath = path.join(decompDir, entryName);
        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, data);
        let content: string | undefined;
        if (isText && data.length < 500000) {
          content = new TextDecoder("utf-8", { fatal: false }).decode(data);
        }
        files.push({
          path: entryName,
          name: path.basename(entryName),
          extension: ext,
          size: data.length,
          content,
          isBinary: !isText,
        });
      }
    }

    // Store original contents for diff/revert
    const originalContents = new Map<string, string>();
    for (const f of files) {
      if (f.content !== undefined) originalContents.set(f.path, f.content);
    }

    editSessions.set(sessionId, {
      dir: sessionDir,
      decompDir,
      apkPath,
      fileType: "apk",
      originalContents,
      modifiedPaths: new Set(),
      expiresAt: Date.now() + 30 * 60 * 1000,
    });

    return {
      success: true,
      sessionId,
      files,
      structure: buildFileTree(files),
      usedApkTool,
    };
  } catch (err: any) {
    cleanupDir(sessionDir);
    return {
      success: false,
      sessionId: "",
      files: [],
      structure: [],
      usedApkTool: false,
      error: `فشل التفكيك: ${err.message}`,
    };
  }
}

// ════════════════════════════════════════
// Save File Edit
// ════════════════════════════════════════

export function saveFileEdit(
  sessionId: string,
  filePath: string,
  newContent: string
): { success: boolean; error?: string } {
  const session = editSessions.get(sessionId);
  if (!session) return { success: false, error: "الجلسة منتهية أو غير موجودة" };
  if (Date.now() > session.expiresAt) {
    editSessions.delete(sessionId);
    cleanupDir(session.dir);
    return { success: false, error: "انتهت صلاحية الجلسة (30 دقيقة)" };
  }

  const fullPath = path.join(session.decompDir, filePath);
  if (!fullPath.startsWith(session.decompDir + path.sep) && fullPath !== session.decompDir) {
    return { success: false, error: "مسار غير صالح" };
  }

  try {
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    fs.writeFileSync(fullPath, newContent, "utf-8");
    session.modifiedPaths.add(filePath);
    session.expiresAt = Date.now() + 30 * 60 * 1000; // Refresh TTL
    return { success: true };
  } catch (err: any) {
    return { success: false, error: `فشل الحفظ: ${err.message}` };
  }
}

export function getSessionInfo(sessionId: string): {
  exists: boolean;
  modifiedCount: number;
  modifiedPaths: string[];
  minutesLeft: number;
  usedApkTool?: boolean;
} {
  const session = editSessions.get(sessionId);
  if (!session) return { exists: false, modifiedCount: 0, modifiedPaths: [], minutesLeft: 0 };
  const minutesLeft = Math.max(0, Math.floor((session.expiresAt - Date.now()) / 60000));
  return {
    exists: true,
    modifiedCount: session.modifiedPaths.size,
    modifiedPaths: Array.from(session.modifiedPaths),
    minutesLeft,
  };
}

// Read a single file's content from the session directory (used for non-APK types)
export function readSessionFileContent(sessionId: string, filePath: string): { success: boolean; content?: string; error?: string } {
  const session = editSessions.get(sessionId);
  if (!session) return { success: false, error: "الجلسة غير موجودة أو انتهت" };
  // Refresh TTL
  session.expiresAt = Math.max(session.expiresAt, Date.now() + 30 * 60 * 1000);
  // Try session original contents map first
  if (session.originalContents.has(filePath)) {
    // Check if file was modified (read from disk)
    const diskPath = path.join(session.decompDir, filePath);
    if (session.modifiedPaths.has(filePath) && fs.existsSync(diskPath)) {
      try { return { success: true, content: fs.readFileSync(diskPath, "utf-8") }; } catch { /* fallback */ }
    }
    return { success: true, content: session.originalContents.get(filePath) };
  }
  // Try reading from disk
  const diskPath = path.join(session.decompDir, filePath);
  if (fs.existsSync(diskPath)) {
    try {
      const stat = fs.statSync(diskPath);
      if (stat.size > 500000) return { success: false, error: "الملف كبير جداً للعرض" };
      return { success: true, content: fs.readFileSync(diskPath, "utf-8") };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }
  return { success: false, error: "الملف غير موجود في الجلسة" };
}

// Helper: store analysis result in an edit session
async function buildAnalysisEditSession(
  result: DecompileResult,
  fileBuffer: Buffer,
  fileName: string,
  ext: EditSession["fileType"]
): Promise<{ success: boolean; sessionId: string; files: DecompiledFile[]; structure: FileTreeNode[]; usedApkTool: boolean; fileType: string; error?: string }> {
  const sessionId = `edit-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const sessionDir = path.join(os.tmpdir(), `hayo-edit-${sessionId}`);
  const decompDir = path.join(sessionDir, "decompiled");
  try {
    fs.mkdirSync(decompDir, { recursive: true });
    fs.writeFileSync(path.join(sessionDir, `original.${ext}`), fileBuffer);

    const originalContents = new Map<string, string>();
    const sessionFiles: DecompiledFile[] = [];
    for (const f of result.files) {
      if (f.content !== undefined) {
        const fullPath = path.join(decompDir, f.path);
        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, f.content, "utf-8");
        originalContents.set(f.path, f.content);
        sessionFiles.push({ ...f, content: undefined });
      }
    }
    editSessions.set(sessionId, { dir: sessionDir, decompDir, apkPath: path.join(sessionDir, `original.${ext}`), fileType: ext, originalContents, modifiedPaths: new Set(), expiresAt: Date.now() + 30 * 60 * 1000 });
    return { success: true, sessionId, files: sessionFiles, structure: result.structure, usedApkTool: false, fileType: ext };
  } catch (err: any) {
    cleanupDir(sessionDir);
    return { success: false, sessionId: "", files: [], structure: [], usedApkTool: false, fileType: ext, error: err.message };
  }
}

// Unified decompile-for-edit: handles ALL supported formats
export async function decompileFileForEdit(fileBuffer: Buffer, fileName: string): Promise<{
  success: boolean;
  sessionId: string;
  files: DecompiledFile[];
  structure: FileTreeNode[];
  usedApkTool: boolean;
  fileType: string;
  error?: string;
}> {
  const ext = (fileName.split(".").pop()?.toLowerCase() || "bin") as EditSession["fileType"];

  if (ext === "apk") {
    const result = await decompileAPKForEdit(fileBuffer);
    return { ...result, fileType: "apk" };
  }

  // IPA/JAR/AAR/DEX: use ZIP-based edit (text files editable)
  if (ext === "ipa") {
    const result = await analyzeIPA(fileBuffer, fileName);
    // Fall through to generic session handler
    if (!result.success) return { success: false, sessionId: "", files: [], structure: [], usedApkTool: false, fileType: ext, error: result.error };
    return buildAnalysisEditSession(result, fileBuffer, fileName, ext);
  }
  if (ext === "jar" || ext === "aar") {
    const result = await analyzeJAR(fileBuffer, fileName, ext);
    if (!result.success) return { success: false, sessionId: "", files: [], structure: [], usedApkTool: false, fileType: ext, error: result.error };
    return buildAnalysisEditSession(result, fileBuffer, fileName, ext);
  }
  if (ext === "dex") {
    const result = await analyzeDEX(fileBuffer, fileName);
    if (!result.success) return { success: false, sessionId: "", files: [], structure: [], usedApkTool: false, fileType: ext, error: result.error };
    return buildAnalysisEditSession(result, fileBuffer, fileName, ext);
  }
  if (ext === "so" || ext === "elf") {
    const result = await analyzeELF(fileBuffer, fileName);
    if (!result.success) return { success: false, sessionId: "", files: [], structure: [], usedApkTool: false, fileType: ext, error: result.error };
    return buildAnalysisEditSession(result, fileBuffer, fileName, ext);
  }
  if (ext === "ex5") {
    const result = await analyzeEX5(fileBuffer, fileName);
    if (!result.success) return { success: false, sessionId: "", files: [], structure: [], usedApkTool: false, fileType: ext, error: result.error };
    return buildAnalysisEditSession(result, fileBuffer, fileName, ext);
  }
  if (ext === "wasm") {
    const result = await analyzeWASM(fileBuffer, fileName);
    if (!result.success) return { success: false, sessionId: "", files: [], structure: [], usedApkTool: false, fileType: ext, error: result.error };
    return buildAnalysisEditSession(result, fileBuffer, fileName, ext);
  }

  // For EX4, EXE, DLL: analyze and store in session
  const sessionId = `edit-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  const sessionDir = path.join(os.tmpdir(), `hayo-edit-${sessionId}`);
  const decompDir = path.join(sessionDir, "decompiled");

  try {
    fs.mkdirSync(decompDir, { recursive: true });

    // Get analysis result
    let analysisResult: DecompileResult;
    if (ext === "ex4") {
      analysisResult = await analyzeEX4(fileBuffer, fileName);
    } else {
      analysisResult = await analyzeEXE(fileBuffer, fileName);
    }

    if (!analysisResult.success) {
      throw new Error(analysisResult.error || "فشل التحليل");
    }

    // Write all text files to decompDir
    const files: DecompiledFile[] = [];
    for (const f of analysisResult.files) {
      if (f.content !== undefined) {
        const fullPath = path.join(decompDir, f.path);
        fs.mkdirSync(path.dirname(fullPath), { recursive: true });
        fs.writeFileSync(fullPath, f.content, "utf-8");
        files.push({ ...f, content: undefined }); // don't send content in response
      }
    }

    // Store originals for revert
    const originalContents = new Map<string, string>();
    for (const f of analysisResult.files) {
      if (f.content !== undefined) originalContents.set(f.path, f.content);
    }

    editSessions.set(sessionId, {
      dir: sessionDir,
      decompDir,
      apkPath: path.join(sessionDir, "original." + ext),
      fileType: ext,
      originalContents,
      modifiedPaths: new Set(),
      expiresAt: Date.now() + 30 * 60 * 1000,
    });

    // Write original file too
    fs.writeFileSync(path.join(sessionDir, "original." + ext), fileBuffer);

    return {
      success: true,
      sessionId,
      files,
      structure: buildFileTree(analysisResult.files),
      usedApkTool: false,
      fileType: ext,
    };
  } catch (err: any) {
    cleanupDir(sessionDir);
    return {
      success: false,
      sessionId: "",
      files: [],
      structure: [],
      usedApkTool: false,
      fileType: ext,
      error: `فشل التحليل للتحرير: ${err.message}`,
    };
  }
}

export function revertFile(sessionId: string, filePath: string): { success: boolean; originalContent?: string; error?: string } {
  const session = editSessions.get(sessionId);
  if (!session) return { success: false, error: "الجلسة غير موجودة" };
  const original = session.originalContents.get(filePath);
  if (original === undefined) return { success: false, error: "لا يوجد نسخة أصلية" };
  const fullPath = path.join(session.decompDir, filePath);
  try {
    fs.writeFileSync(fullPath, original, "utf-8");
    session.modifiedPaths.delete(filePath);
    return { success: true, originalContent: original };
  } catch (err: any) {
    return { success: false, error: err.message };
  }
}

// ════════════════════════════════════════
// AI Modify Code
// ════════════════════════════════════════

export async function aiModifyCode(
  code: string,
  instruction: string,
  fileName: string
): Promise<{ modifiedCode: string; explanation: string }> {
  const result = await callOfficeAI(
    `أنت خبير هندسة عكسية لتطبيقات Android. مهمتك تعديل كود smali أو XML حسب تعليمات المستخدم.

قواعد صارمة:
- أعد الكود المعدّل بالكامل (ليس فقط الجزء المعدّل)
- لا تكسر بنية الكود — حافظ على كل التعريفات والـ registers
- إذا طُلب إزالة حماية الدفع: غيّر الشرط ليرجع true دائماً
- إذا طُلب تعديل نص: عدّل في ملف strings.xml المناسب
- إذا طُلب إزالة إعلانات: احذف أو علّق الكود المعني

أعد الإجابة بتنسيق JSON فقط:
{
  "modifiedCode": "الكود المعدّل بالكامل هنا",
  "explanation": "شرح ما تم تعديله ولماذا"
}`,
    `الملف: ${fileName}\n\nالتعليمات: ${instruction}\n\nالكود الحالي:\n\`\`\`\n${code.substring(0, 20000)}\n\`\`\``,
    8192,
    "claude-sonnet-4-6"
  );

  try {
    const cleaned = result.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (jsonMatch) return JSON.parse(jsonMatch[0]);
  } catch { /* fallback */ }

  return { modifiedCode: code, explanation: "فشل التعديل التلقائي.\n" + result };
}

// ════════════════════════════════════════
// AI Search Files
// ════════════════════════════════════════

function extractSearchKeywords(query: string): string[] {
  const mapping: Record<string, string[]> = {
    "دفع": ["purchase", "billing", "pay", "premium", "subscribe", "isPaid", "isPremium", "isSubscribed", "isBought"],
    "مدفوع": ["premium", "paid", "pro", "subscribe", "purchase", "billing"],
    "مجاني": ["free", "trial", "premium", "paid"],
    "إعلان": ["ads", "adview", "admob", "banner", "interstitial", "adunit", "advertisement"],
    "إعلانات": ["ads", "adview", "admob", "banner", "interstitial", "adunit"],
    "تسجيل": ["login", "signin", "auth", "register", "account"],
    "صلاحية": ["permission", "license", "check", "verify", "validate"],
    "حماية": ["security", "protect", "guard", "check", "license", "verify"],
    "رخصة": ["license", "key", "serial", "activation", "validate"],
    "اشتراك": ["subscribe", "subscription", "premium", "billing", "purchase"],
    "مصادقة": ["auth", "authenticate", "token", "login", "verify"],
    "شبكة": ["network", "http", "url", "api", "request", "socket"],
  };

  const keywords: string[] = [];
  const lowerQuery = query.toLowerCase();

  for (const [arabic, english] of Object.entries(mapping)) {
    if (lowerQuery.includes(arabic)) keywords.push(...english);
  }

  const englishWords = query.match(/[a-zA-Z]{3,}/g);
  if (englishWords) keywords.push(...englishWords);

  if (keywords.length === 0) {
    keywords.push("premium", "purchase", "billing", "paid", "subscribe", "license");
  }

  return [...new Set(keywords)];
}

export async function aiSearchFiles(
  sessionId: string,
  query: string
): Promise<{ results: Array<{ path: string; snippet: string; relevance: string }> }> {
  const session = editSessions.get(sessionId);
  if (!session) throw new Error("الجلسة غير موجودة");

  const keywords = extractSearchKeywords(query);
  const matchingFiles: Array<{ path: string; content: string; matchCount: number }> = [];

  const allFiles = readDirRecursive(session.decompDir);
  for (const filePath of allFiles) {
    const ext = path.extname(filePath).toLowerCase();
    if (![".smali", ".xml", ".json", ".txt", ".properties"].includes(ext)) continue;

    try {
      const stat = fs.statSync(filePath);
      if (stat.size > 200000) continue;

      const content = fs.readFileSync(filePath, "utf-8");
      let matchCount = 0;
      for (const kw of keywords) {
        const regex = new RegExp(kw, "gi");
        const matches = content.match(regex);
        if (matches) matchCount += matches.length;
      }

      if (matchCount > 0) {
        matchingFiles.push({
          path: path.relative(session.decompDir, filePath),
          content: content.substring(0, 3000),
          matchCount,
        });
      }
    } catch { /* skip */ }
  }

  matchingFiles.sort((a, b) => b.matchCount - a.matchCount);
  const top10 = matchingFiles.slice(0, 10);

  if (top10.length === 0) {
    return { results: [{ path: "—", snippet: "لم يتم العثور على نتائج", relevance: "لا شيء" }] };
  }

  const aiResult = await callOfficeAI(
    "أنت خبير هندسة عكسية. حلل نتائج البحث وحدد الملفات الأكثر صلة بطلب المستخدم.",
    `طلب المستخدم: "${query}"\n\nالملفات المطابقة:\n${top10.map(f => `\n--- ${f.path} (${f.matchCount} تطابق) ---\n${f.content.substring(0, 400)}`).join("\n")}\n\nأعد JSON فقط:\n[{"path":"مسار الملف","snippet":"السطور المهمة","relevance":"لماذا هذا الملف مهم"}]`,
    4096,
    "claude-haiku-4-5"
  );

  try {
    const cleaned = aiResult.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const parsed = JSON.parse(cleaned);
    return { results: Array.isArray(parsed) ? parsed : [parsed] };
  } catch {
    return {
      results: top10.slice(0, 5).map(f => ({
        path: f.path,
        snippet: `${f.matchCount} تطابقات`,
        relevance: "تطابق كلمات مفتاحية",
      })),
    };
  }
}

// ════════════════════════════════════════
// Rebuild APK
// ════════════════════════════════════════

export async function rebuildAPK(sessionId: string): Promise<{
  success: boolean;
  apkBuffer?: Buffer;
  usedApkTool: boolean;
  signed: boolean;
  error?: string;
}> {
  const session = editSessions.get(sessionId);
  if (!session) return { success: false, usedApkTool: false, signed: false, error: "الجلسة غير موجودة أو منتهية" };

  const outputApk = path.join(session.dir, "rebuilt.apk");
  const signedApk = path.join(session.dir, "signed.apk");
  const alignedApk = path.join(session.dir, "aligned.apk");
  const keystorePath = "/home/runner/hayo-debug.jks";

  // Try APKTool rebuild if available
  const apktoolPath = findApkTool();
  if (apktoolPath) {
    try {
      execSync(
        buildApkToolCmd(apktoolPath, `b "${session.decompDir}" -o "${outputApk}"`),
        { timeout: 180000, stdio: "pipe" }
      );

      if (!fs.existsSync(outputApk)) {
        throw new Error("فشل إنشاء APK");
      }

      // Zipalign (optional)
      try {
        execSync(`zipalign -f 4 "${outputApk}" "${alignedApk}"`, { timeout: 30000, stdio: "pipe" });
      } catch {
        fs.copyFileSync(outputApk, alignedApk);
      }

      // Ensure keystore
      if (!fs.existsSync(keystorePath)) {
        try {
          execSync(
            `keytool -genkeypair -v -keystore "${keystorePath}" -keyalg RSA -keysize 2048 -validity 10000 -alias hayo -storepass hayoai123 -keypass hayoai123 -dname "CN=HAYO AI, OU=Dev, O=HAYO, L=Unknown, ST=Unknown, C=US"`,
            { timeout: 30000, stdio: "pipe" }
          );
        } catch { /* skip */ }
      }

      let signed = false;
      // Try apksigner
      try {
        execSync(
          `apksigner sign --ks "${keystorePath}" --ks-pass pass:hayoai123 --key-pass pass:hayoai123 --out "${signedApk}" "${alignedApk}"`,
          { timeout: 30000, stdio: "pipe" }
        );
        signed = true;
      } catch {
        // Fallback: jarsigner
        try {
          execSync(
            `jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 -keystore "${keystorePath}" -storepass hayoai123 -keypass hayoai123 "${alignedApk}" hayo`,
            { timeout: 30000, stdio: "pipe" }
          );
          fs.copyFileSync(alignedApk, signedApk);
          signed = true;
        } catch {
          fs.copyFileSync(outputApk, signedApk);
        }
      }

      const apkBuffer = fs.readFileSync(signedApk);
      return { success: true, apkBuffer, usedApkTool: true, signed };
    } catch (err: any) {
      // Fall through to ZIP rebuild
      console.warn("[RE] APKTool rebuild failed:", err.message);
    }
  }

  // Fallback: ZIP rebuild (repack modified files)
  try {
    const zip = new JSZip();
    const allFiles = readDirRecursive(session.decompDir);
    for (const filePath of allFiles) {
      const relPath = path.relative(session.decompDir, filePath);
      const data = fs.readFileSync(filePath);
      zip.file(relPath, data);
    }
    const apkBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
    return { success: true, apkBuffer, usedApkTool: false, signed: false };
  } catch (err: any) {
    return { success: false, usedApkTool: false, signed: false, error: `فشل إعادة البناء: ${err.message}` };
  }
}

// ════════════════════════════════════════════════════════════════
// Smart AI Modify — AI finds the right files automatically
// User just says what they want, AI locates and modifies
// ════════════════════════════════════════════════════════════════

export async function aiSmartModify(
  sessionId: string,
  instruction: string
): Promise<{
  modifications: Array<{ filePath: string; explanation: string; originalSnippet: string; modifiedSnippet: string }>;
  summary: string;
  filesModified: number;
}> {
  const session = editSessions.get(sessionId);
  if (!session) throw new Error("الجلسة غير موجودة أو منتهية");

  // Step 1: Gather all text files with their content (limited)
  const allFiles = readDirRecursive(session.decompDir);
  const textFiles: Array<{ relPath: string; content: string }> = [];
  let totalChars = 0;
  const MAX_CONTEXT = 120000; // ~30K tokens

  for (const filePath of allFiles) {
    const ext = path.extname(filePath).toLowerCase();
    if (![".smali", ".xml", ".json", ".txt", ".properties", ".java", ".kt", ".js", ".html", ".yml", ".yaml", ".cfg", ".ini", ".pro"].includes(ext)) continue;
    try {
      const stat = fs.statSync(filePath);
      if (stat.size > 300000 || stat.size === 0) continue;
      const content = fs.readFileSync(filePath, "utf-8");
      const relPath = path.relative(session.decompDir, filePath);
      if (totalChars + content.length > MAX_CONTEXT) {
        textFiles.push({ relPath, content: content.substring(0, 2000) + "\n... [truncated]" });
        totalChars += 2000;
      } else {
        textFiles.push({ relPath, content });
        totalChars += content.length;
      }
    } catch { /* skip */ }
  }

  // Step 2: Ask AI to find and modify
  const filesIndex = textFiles.map((f, i) => `[${i}] ${f.relPath} (${f.content.length} chars)`).join("\n");

  const planResult = await callPowerAI(
    `أنت خبير هندسة عكسية محترف لتطبيقات Android/Windows/iOS. مهمتك:
1. فهم طلب المستخدم
2. البحث في ملفات التطبيق المفكك وتحديد الملفات التي تحتاج تعديل
3. تنفيذ التعديلات المطلوبة

قواعد صارمة:
- ابحث في كل الملفات واختر الملفات الصحيحة تلقائياً
- عدّل فقط الملفات التي تحتاج تعديل فعلاً
- حافظ على بنية الكود (خصوصاً smali)
- لملفات smali: حافظ على كل registers و labels
- لإزالة الإعلانات: ابحث عن admob/ads/banner/interstitial وعطّلها
- لفتح الميزات المدفوعة: غيّر الشروط لترجع true
- لتغيير اسم التطبيق: عدّل strings.xml
- لإزالة التراخيص: ابحث عن license/check/verify

أعد JSON فقط بهذا التنسيق:
{
  "modifications": [
    {
      "fileIndex": 0,
      "filePath": "path/to/file.smali",
      "searchText": "النص الأصلي الذي يجب البحث عنه واستبداله",
      "replaceText": "النص البديل",
      "explanation": "شرح التعديل"
    }
  ],
  "summary": "ملخص كل التعديلات"
}`,
    `التعليمات: ${instruction}\n\nالملفات المتاحة:\n${filesIndex}\n\n${"=".repeat(60)}\n\nمحتوى الملفات:\n${textFiles.map((f, i) => `\n${"═".repeat(40)}\n[${i}] ${f.relPath}\n${"═".repeat(40)}\n${f.content}`).join("\n")}`,
    32000
  );

  // Step 3: Parse AI response and apply modifications
  const modifications: Array<{ filePath: string; explanation: string; originalSnippet: string; modifiedSnippet: string }> = [];

  try {
    const cleaned = planResult.content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("No JSON found");

    const plan = JSON.parse(jsonMatch[0]);

    for (const mod of plan.modifications || []) {
      const fileInfo = textFiles[mod.fileIndex] || textFiles.find(f => f.relPath === mod.filePath);
      if (!fileInfo) continue;

      const fullPath = path.join(session.decompDir, fileInfo.relPath);
      if (!fs.existsSync(fullPath)) continue;

      try {
        let content = fs.readFileSync(fullPath, "utf-8");
        const original = content;

        if (mod.searchText && mod.replaceText !== undefined) {
          if (content.includes(mod.searchText)) {
            content = content.replace(mod.searchText, mod.replaceText);
            fs.writeFileSync(fullPath, content, "utf-8");

            // Track modification in session
            if (!session.modifiedPaths) session.modifiedPaths = new Set();
            session.modifiedPaths.add(fileInfo.relPath);

            modifications.push({
              filePath: fileInfo.relPath,
              explanation: mod.explanation || "تعديل تلقائي",
              originalSnippet: mod.searchText.substring(0, 200),
              modifiedSnippet: mod.replaceText.substring(0, 200),
            });
          }
        }
      } catch { /* skip file */ }
    }

    return {
      modifications,
      summary: plan.summary || `تم تعديل ${modifications.length} ملفات`,
      filesModified: modifications.length,
    };
  } catch (err: any) {
    // If AI response parsing failed, return raw
    return {
      modifications: [],
      summary: `فشل تحليل استجابة AI: ${err.message}\n\nالاستجابة الخام:\n${planResult.content.substring(0, 500)}`,
      filesModified: 0,
    };
  }
}

// ════════════════════════════════════════════════════════════════
// Direct Pattern-Based Restriction Breakers
// Multi-format: APK(smali/xml), JAR/AAR(java/kt), EXE/DLL(strings/asm),
// IPA(swift/objc/plist), WASM(wat), EX4/EX5(mql), SO/ELF(c/cpp)
// ════════════════════════════════════════════════════════════════

const EDITABLE_EXTS = [
  ".smali", ".xml", ".json", ".txt", ".properties", ".java", ".kt",
  ".js", ".ts", ".html", ".css", ".swift", ".m", ".h", ".c", ".cpp",
  ".py", ".rb", ".yml", ".yaml", ".cfg", ".ini", ".pro", ".gradle",
  ".mf", ".sf", ".plist", ".strings", ".mq4", ".mq5", ".wat",
  ".cs", ".vb", ".il", ".asm",
];

function walkEditableFiles(decompDir: string, maxSize = 500000): Array<{ path: string; relPath: string; ext: string }> {
  const results: Array<{ path: string; relPath: string; ext: string }> = [];
  const allFiles = readDirRecursive(decompDir);
  for (const filePath of allFiles) {
    const ext = path.extname(filePath).toLowerCase();
    if (!EDITABLE_EXTS.includes(ext)) continue;
    try {
      const stat = fs.statSync(filePath);
      if (stat.size > maxSize || stat.size === 0) continue;
      results.push({ path: filePath, relPath: path.relative(decompDir, filePath), ext });
    } catch { /* skip */ }
  }
  return results;
}

function directRemoveAds(decompDir: string): string[] {
  const mods: string[] = [];
  const files = walkEditableFiles(decompDir);

  for (const { path: filePath, relPath, ext } of files) {
    try {
      let content = fs.readFileSync(filePath, "utf-8");
      let changed = false;
      const original = content;

      if (ext === ".smali") {
        // Android smali: disable ad SDK calls
        content = content.replace(
          /invoke-[a-z]+\s+\{[^}]*\},\s*L(com\/google\/android\/gms\/ads|com\/google\/ads|com\/facebook\/ads|com\/unity3d\/ads|com\/applovin|com\/ironsource|com\/mopub|com\/inmobi|com\/startapp)[^\n]*/gi,
          (m) => `# [HAYO-AD-REMOVED] ${m}`
        );
        content = content.replace(/(invoke-[^\n]*(?:loadAd|showAd|showInterstitial|loadInterstitial|loadBanner|showBanner|loadRewardedAd|showRewardedAd)[^\n]*)/gi,
          (m) => `# [HAYO-AD-DISABLED] ${m}`
        );
      } else if ([".java", ".kt", ".cs"].includes(ext)) {
        // Java/Kotlin/C#: comment out ad imports and calls
        content = content.replace(/^(import\s+.*(?:admob|ads|adview|interstitial|banner|AdMob|AppLovin|IronSource|UnityAds|MoPub).*)$/gim,
          (m) => `// [HAYO-AD-REMOVED] ${m}`
        );
        content = content.replace(/(.*(?:loadAd|showAd|loadInterstitial|showInterstitial|adView|adRequest|AdRequest|MobileAds|InterstitialAd|BannerView|RewardedAd)\s*[\(\.].*)/gi,
          (m) => `// [HAYO-AD-DISABLED] ${m}`
        );
      } else if ([".swift", ".m"].includes(ext)) {
        // iOS Swift/ObjC: disable ad SDK calls
        content = content.replace(/^(import\s+.*(?:GoogleMobileAds|AdSupport|AppTrackingTransparency|FBAudience).*)$/gim,
          (m) => `// [HAYO-AD-REMOVED] ${m}`
        );
        content = content.replace(/(.*(?:GAD|ADBanner|GADInterstitial|GADRewardedAd|FBAdView|FBInterstitial)\s*[\(\.].*)/gi,
          (m) => `// [HAYO-AD-DISABLED] ${m}`
        );
      } else if ([".js", ".ts"].includes(ext)) {
        // Web/React Native/Electron
        content = content.replace(/(.*(?:admob|adsense|adsbygoogle|googletag|adUnit|showAd|loadAd|interstitialAd|bannerAd)\s*[\(\.\=].*)/gi,
          (m) => `// [HAYO-AD-DISABLED] ${m}`
        );
      } else if (ext === ".xml" || ext === ".plist") {
        // Remove ad-related XML elements
        content = content.replace(/<[^>]*(?:com\.google\.ads|admob|ad_unit|adView|AdView|banner_ad|interstitial_ad)[^>]*\/>/gi, "<!-- [HAYO-AD-REMOVED] -->");
        content = content.replace(/<[^>]*(?:com\.google\.ads|admob|ad_unit)[^>]*>[\s\S]*?<\/[^>]*>/gi, "<!-- [HAYO-AD-REMOVED] -->");
      }

      if (content !== original) {
        changed = true;
        fs.writeFileSync(filePath, content, "utf-8");
        mods.push(`🚫 إعلانات: ${relPath}`);
      }
    } catch { /* skip */ }
  }

  // Remove ad permissions from manifests
  for (const manifestName of ["AndroidManifest.xml", "Info.plist"]) {
    const manifestPath = path.join(decompDir, manifestName);
    if (fs.existsSync(manifestPath)) {
      try {
        let manifest = fs.readFileSync(manifestPath, "utf-8");
        const adPerms = ["com.google.android.gms.permission.AD_ID", "com.google.android.gms.ads", "NSUserTrackingUsageDescription", "GADApplicationIdentifier"];
        for (const perm of adPerms) {
          if (manifest.includes(perm)) {
            manifest = manifest.replace(new RegExp(`<[^>]*${perm.replace(/\./g, "\\.")}[^>]*>[^<]*</[^>]*>|<[^>]*${perm.replace(/\./g, "\\.")}[^>]*/>`, "g"), "");
            mods.push(`🚫 صلاحية: ${perm}`);
          }
        }
        fs.writeFileSync(manifestPath, manifest, "utf-8");
      } catch { /* skip */ }
    }
  }

  return mods;
}

function directUnlockPremium(decompDir: string): string[] {
  const mods: string[] = [];
  const files = walkEditableFiles(decompDir);

  const premiumMethodNames = ["isPremium", "isPaid", "isSubscribed", "isPro", "isVip", "hasPurchased", "isUnlocked", "isBought", "checkLicense", "isTrialExpired", "isFreeTier", "needsUpgrade", "shouldShowPaywall", "canAccessFeature", "hasActiveSubscription"];

  for (const { path: filePath, relPath, ext } of files) {
    try {
      let content = fs.readFileSync(filePath, "utf-8");
      let changed = false;
      const original = content;

      if (ext === ".smali") {
        // Smali: patch boolean-returning premium methods
        const methodRegex = new RegExp(
          `\\.method[^\\n]*(${premiumMethodNames.join("|")})[^\\n]*\\n([\\s\\S]*?)\\.end method`, "g"
        );
        content = content.replace(methodRegex, (match, methodName) => {
          const header = match.split("\n")[0];
          const returnsBoolean = header.includes(")Z") || header.includes(")I");
          if (returnsBoolean) {
            const isNegative = /Expired|FreeTier|needsUpgrade|shouldShowPaywall/i.test(methodName);
            const val = isNegative ? "0x0" : "0x1";
            return `${header}\n    .locals 1\n    # [HAYO-UNLOCKED] ${methodName} → ${isNegative ? "false" : "true"}\n    const/4 v0, ${val}\n    return v0\n.end method`;
          }
          return match;
        });
        // Bypass billing queries
        content = content.replace(/(invoke-[^\n]*(?:queryPurchases|getPurchaseState|getResponseCode|launchBillingFlow|acknowledgePurchase)[^\n]*)/gi,
          (m) => `# [HAYO-BILLING-BYPASS] ${m}`
        );
      } else if ([".java", ".kt"].includes(ext)) {
        // Java/Kotlin: patch return statements in premium methods
        for (const method of premiumMethodNames) {
          const regex = new RegExp(`((?:public|private|protected|internal)?\\s*(?:static\\s+)?(?:fun|boolean|Bool)\\s+${method}\\s*\\([^)]*\\)\\s*(?::\\s*Boolean)?\\s*\\{)([\\s\\S]*?)(\\})`, "g");
          content = content.replace(regex, (match, header, body, close) => {
            changed = true;
            const isNegative = /Expired|FreeTier|needsUpgrade|shouldShowPaywall/i.test(method);
            return `${header}\n    // [HAYO-UNLOCKED] ${method}\n    return ${isNegative ? "false" : "true"};\n${close}`;
          });
        }
      } else if ([".swift", ".m"].includes(ext)) {
        // Swift/ObjC: patch premium checks
        for (const method of premiumMethodNames) {
          const regex = new RegExp(`(func\\s+${method}\\s*\\([^)]*\\)\\s*->\\s*Bool\\s*\\{)([\\s\\S]*?)(\\})`, "g");
          content = content.replace(regex, (match, header, body, close) => {
            changed = true;
            const isNegative = /Expired|FreeTier|needsUpgrade|shouldShowPaywall/i.test(method);
            return `${header}\n    // [HAYO-UNLOCKED] ${method}\n    return ${isNegative ? "false" : "true"}\n${close}`;
          });
        }
      } else if ([".js", ".ts"].includes(ext)) {
        // JavaScript/TypeScript
        for (const method of premiumMethodNames) {
          const regex = new RegExp(`((?:async\\s+)?(?:function\\s+)?${method}\\s*\\([^)]*\\)\\s*(?::\\s*boolean)?\\s*\\{)([\\s\\S]*?)(\\})`, "gi");
          content = content.replace(regex, (match, header, body, close) => {
            changed = true;
            const isNegative = /Expired|FreeTier|needsUpgrade|shouldShowPaywall/i.test(method);
            return `${header}\n    // [HAYO-UNLOCKED] ${method}\n    return ${isNegative ? "false" : "true"};\n${close}`;
          });
        }
      } else if (ext === ".cs") {
        // C# (.NET)
        for (const method of premiumMethodNames) {
          const regex = new RegExp(`((?:public|private|protected|internal)?\\s*(?:static\\s+)?bool\\s+${method}\\s*\\([^)]*\\)\\s*\\{)([\\s\\S]*?)(\\})`, "g");
          content = content.replace(regex, (match, header, body, close) => {
            changed = true;
            const isNegative = /Expired|FreeTier|needsUpgrade|shouldShowPaywall/i.test(method);
            return `${header}\n    // [HAYO-UNLOCKED] ${method}\n    return ${isNegative ? "false" : "true"};\n${close}`;
          });
        }
      }

      if (content !== original) {
        changed = true;
        fs.writeFileSync(filePath, content, "utf-8");
        mods.push(`🔓 مدفوع: ${relPath}`);
      }
    } catch { /* skip */ }
  }

  return mods;
}

function directRemoveTracking(decompDir: string): string[] {
  const mods: string[] = [];
  const files = walkEditableFiles(decompDir);
  const trackingPatterns = [
    /(?:Firebase|Analytics|Crashlytics|logEvent|setAnalytics|trackEvent|sendEvent|Amplitude|Mixpanel|Segment|Flurry|AppsFly|Adjust|Branch|CleverTap|OneSignal)/gi,
  ];

  for (const { path: filePath, relPath, ext } of files) {
    try {
      let content = fs.readFileSync(filePath, "utf-8");
      const original = content;

      if (ext === ".smali") {
        content = content.replace(/(invoke-[^\n]*(?:Firebase|Analytics|Crashlytics|logEvent|trackEvent|Amplitude|Mixpanel|Flurry|Adjust|Branch)[^\n]*)/gi,
          (m) => `# [HAYO-TRACKING-OFF] ${m}`);
      } else if ([".java", ".kt", ".swift", ".m", ".js", ".ts", ".cs"].includes(ext)) {
        content = content.replace(/(.*(?:logEvent|trackEvent|sendAnalytics|setUserProperty|recordEvent|trackScreen|setCurrentScreen|logCustom|analytics\.track|analytics\.log)\s*\(.*)/gi,
          (m) => `// [HAYO-TRACKING-OFF] ${m}`);
        content = content.replace(/^(import\s+.*(?:Firebase|Analytics|Crashlytics|Amplitude|Mixpanel|Flurry|Adjust).*)$/gim,
          (m) => `// [HAYO-TRACKING-OFF] ${m}`);
      }

      if (content !== original) {
        fs.writeFileSync(filePath, content, "utf-8");
        mods.push(`📡 تتبع: ${relPath}`);
      }
    } catch { /* skip */ }
  }

  return mods;
}

function directRemoveLicenseCheck(decompDir: string): string[] {
  const mods: string[] = [];
  const files = walkEditableFiles(decompDir);
  const licenseMethodNames = ["checkLicense", "verifyLicense", "validateLicense", "isLicensed", "isActivated", "checkSignature", "verifySignature", "isRegistered", "isExpired", "checkExpiry", "validateKey", "verifyKey", "checkSerial"];

  for (const { path: filePath, relPath, ext } of files) {
    try {
      let content = fs.readFileSync(filePath, "utf-8");
      const original = content;

      if (ext === ".smali") {
        const regex = new RegExp(
          `\\.method[^\\n]*(${licenseMethodNames.join("|")})[^\\n]*\\n([\\s\\S]*?)\\.end method`, "g"
        );
        content = content.replace(regex, (match, methodName) => {
          const header = match.split("\n")[0];
          const isNegative = /Expired|isExpired|checkExpiry/i.test(methodName);
          const val = isNegative ? "0x0" : "0x1";
          return `${header}\n    .locals 1\n    # [HAYO-LICENSE-BYPASS] ${methodName}\n    const/4 v0, ${val}\n    return v0\n.end method`;
        });
        content = content.replace(/(invoke-[^\n]*(?:PackageManager|checkSignature|getPackageInfo.*signatures)[^\n]*)/gi,
          (m) => `# [HAYO-SIG-BYPASS] ${m}`);
      } else if ([".java", ".kt"].includes(ext)) {
        for (const method of licenseMethodNames) {
          const regex = new RegExp(`((?:public|private|protected)?\\s*(?:static\\s+)?(?:fun|boolean)\\s+${method}\\s*\\([^)]*\\)\\s*(?::\\s*Boolean)?\\s*\\{)([\\s\\S]*?)(\\})`, "g");
          content = content.replace(regex, (match, header, body, close) => {
            const isNeg = /Expired/i.test(method);
            return `${header}\n    // [HAYO-LICENSE-BYPASS] ${method}\n    return ${isNeg ? "false" : "true"};\n${close}`;
          });
        }
      } else if ([".swift", ".m"].includes(ext)) {
        for (const method of licenseMethodNames) {
          const regex = new RegExp(`(func\\s+${method}\\s*\\([^)]*\\)\\s*->\\s*Bool\\s*\\{)([\\s\\S]*?)(\\})`, "g");
          content = content.replace(regex, (match, header, body, close) => {
            const isNeg = /Expired/i.test(method);
            return `${header}\n    // [HAYO-LICENSE-BYPASS]\n    return ${isNeg ? "false" : "true"}\n${close}`;
          });
        }
      } else if ([".js", ".ts", ".cs"].includes(ext)) {
        for (const method of licenseMethodNames) {
          const regex = new RegExp(`((?:async\\s+)?(?:function\\s+)?(?:bool\\s+)?${method}\\s*\\([^)]*\\)\\s*(?::\\s*(?:boolean|Bool))?\\s*\\{)([\\s\\S]*?)(\\})`, "gi");
          content = content.replace(regex, (match, header, body, close) => {
            const isNeg = /Expired/i.test(method);
            return `${header}\n    // [HAYO-LICENSE-BYPASS]\n    return ${isNeg ? "false" : "true"};\n${close}`;
          });
        }
      }

      if (content !== original) {
        fs.writeFileSync(filePath, content, "utf-8");
        mods.push(`🔑 رخصة: ${relPath}`);
      }
    } catch { /* skip */ }
  }

  return mods;
}

function directChangeAppName(decompDir: string, newName: string): string[] {
  const mods: string[] = [];
  const allFiles = readDirRecursive(decompDir);

  for (const filePath of allFiles) {
    const baseName = path.basename(filePath);
    try {
      let content = fs.readFileSync(filePath, "utf-8");
      const original = content;

      // Android strings.xml
      if (baseName.startsWith("strings") && filePath.endsWith(".xml")) {
        content = content.replace(/<string name="app_name">[^<]*<\/string>/, `<string name="app_name">${newName}</string>`);
      }
      // iOS Info.plist
      if (baseName === "Info.plist") {
        content = content.replace(/(<key>CFBundleDisplayName<\/key>\s*<string>)[^<]*(<\/string>)/, `$1${newName}$2`);
        content = content.replace(/(<key>CFBundleName<\/key>\s*<string>)[^<]*(<\/string>)/, `$1${newName}$2`);
      }
      // package.json (React Native / Electron)
      if (baseName === "package.json") {
        try {
          const pkg = JSON.parse(content);
          if (pkg.displayName || pkg.name) {
            if (pkg.displayName) pkg.displayName = newName;
            content = JSON.stringify(pkg, null, 2);
          }
        } catch { /* not valid json */ }
      }
      // .NET AssemblyInfo
      if (baseName.includes("AssemblyInfo")) {
        content = content.replace(/(AssemblyTitle\(")[^"]*("\))/, `$1${newName}$2`);
        content = content.replace(/(AssemblyProduct\(")[^"]*("\))/, `$1${newName}$2`);
      }

      if (content !== original) {
        fs.writeFileSync(filePath, content, "utf-8");
        mods.push(`📝 اسم → "${newName}": ${path.relative(decompDir, filePath)}`);
      }
    } catch { /* skip */ }
  }

  return mods;
}

// ════════════════════════════════════════════════════════════════
// Clone App — Full automatic: decompile → modify → sign → rebuild
// ════════════════════════════════════════════════════════════════

export interface CloneOptions {
  removeAds: boolean;
  unlockPremium: boolean;
  removeTracking: boolean;
  removeLicenseCheck: boolean;
  changeAppName?: string;
  changePackageName?: string;
  customInstructions?: string;
}

export async function cloneApp(
  fileBuffer: Buffer,
  fileName: string,
  options: CloneOptions
): Promise<{
  success: boolean;
  apkBuffer?: Buffer;
  signed: boolean;
  modifications: string[];
  error?: string;
}> {
  const ext = fileName.split(".").pop()?.toLowerCase();
  const allSupported = ["apk", "exe", "dll", "so", "ipa", "jar", "aar", "dex", "ex4", "ex5", "wasm", "elf"];
  if (!ext || !allSupported.includes(ext)) {
    return { success: false, signed: false, modifications: [], error: `الاستنساخ يدعم: ${allSupported.map(f => f.toUpperCase()).join(", ")}. الملف: .${ext}` };
  }

  // Step 1: Decompile for edit
  const decompResult = await decompileFileForEdit(fileBuffer, fileName);
  if (!decompResult.success || !decompResult.sessionId) {
    return { success: false, signed: false, modifications: [], error: decompResult.error || "فشل التفكيك" };
  }

  const sessionId = decompResult.sessionId;
  const session = editSessions.get(sessionId);
  if (!session) return { success: false, signed: false, modifications: [], error: "فشل إنشاء الجلسة" };

  const modifications: string[] = [];

  // Step 2: Apply DIRECT pattern-based modifications first (fast & reliable)
  if (options.removeAds) {
    const adMods = directRemoveAds(session.decompDir);
    modifications.push(...adMods);
    if (adMods.length === 0) modifications.push("⚠️ لم يتم العثور على أكواد إعلانات معروفة");
  }

  if (options.unlockPremium) {
    const premiumMods = directUnlockPremium(session.decompDir);
    modifications.push(...premiumMods);
    if (premiumMods.length === 0) modifications.push("⚠️ لم يتم العثور على أكواد حماية مدفوعة معروفة");
  }

  if (options.removeTracking) {
    const trackMods = directRemoveTracking(session.decompDir);
    modifications.push(...trackMods);
    if (trackMods.length === 0) modifications.push("⚠️ لم يتم العثور على أكواد تتبع معروفة");
  }

  if (options.removeLicenseCheck) {
    const licenseMods = directRemoveLicenseCheck(session.decompDir);
    modifications.push(...licenseMods);
    if (licenseMods.length === 0) modifications.push("⚠️ لم يتم العثور على أكواد تحقق من الرخصة");
  }

  if (options.changeAppName) {
    const nameMods = directChangeAppName(session.decompDir, options.changeAppName);
    modifications.push(...nameMods);
  }

  // Step 3: Use AI for custom instructions or if direct methods found nothing
  const directModCount = modifications.filter(m => m.startsWith("🚫") || m.startsWith("🔓") || m.startsWith("📡") || m.startsWith("🔑") || m.startsWith("📝")).length;

  if (options.customInstructions || directModCount === 0) {
    const aiInstructions: string[] = [];
    if (directModCount === 0 && options.removeAds) aiInstructions.push("ابحث عن أي أكواد إعلانات وعطّلها بأي طريقة ممكنة");
    if (directModCount === 0 && options.unlockPremium) aiInstructions.push("ابحث عن أي فحص للاشتراك أو الدفع وغيّره ليرجع true");
    if (options.customInstructions) aiInstructions.push(options.customInstructions);

    if (aiInstructions.length > 0) {
      try {
        const aiResult = await aiSmartModify(sessionId, aiInstructions.join("\n\n"));
        modifications.push(...aiResult.modifications.map(m => `🤖 AI: ${m.filePath} — ${m.explanation}`));
      } catch (err: any) {
        modifications.push(`⚠️ فشل التعديل بالذكاء الاصطناعي: ${err.message}`);
      }
    }
  }

  if (options.changePackageName) {
    modifications.push("⚠️ تغيير اسم الحزمة يحتاج APKTool — سيتم تطبيقه إذا متاح");
    // Package name change in manifest
    const manifestPath = path.join(session.decompDir, "AndroidManifest.xml");
    if (fs.existsSync(manifestPath)) {
      try {
        let manifest = fs.readFileSync(manifestPath, "utf-8");
        manifest = manifest.replace(/package="[^"]*"/, `package="${options.changePackageName}"`);
        fs.writeFileSync(manifestPath, manifest, "utf-8");
        modifications.push(`📦 اسم الحزمة → "${options.changePackageName}"`);
      } catch { /* skip */ }
    }
  }

  // Step 4: Rebuild with best available method
  if (ext === "apk") {
    const rebuildResult = await rebuildAPK(sessionId);
    if (!rebuildResult.success) {
      return { success: false, signed: false, modifications, error: rebuildResult.error || "فشل إعادة البناء" };
    }

    // Step 5: Ensure signing
    let finalBuffer = rebuildResult.apkBuffer!;
    let signed = rebuildResult.signed;

    if (!signed) {
      // Try uber-apk-signer as last resort
      const signResult = await signAPKBuffer(finalBuffer);
      if (signResult.signed) {
        finalBuffer = signResult.buffer;
        signed = true;
        modifications.push("✅ تم التوقيع بـ uber-apk-signer");
      } else {
        // Try jarsigner directly on buffer
        const tmpApk = path.join(os.tmpdir(), `clone-sign-${Date.now()}.apk`);
        fs.writeFileSync(tmpApk, finalBuffer);
        const signedBuffer = await signAPKFile(tmpApk);
        if (signedBuffer) {
          finalBuffer = signedBuffer;
          signed = true;
          modifications.push("✅ تم التوقيع بنجاح");
        } else {
          modifications.push("⚠️ تعذر التوقيع — قد تحتاج توقيع يدوي");
        }
        try { fs.unlinkSync(tmpApk); } catch {}
      }
    } else {
      modifications.push("✅ تم التوقيع أثناء البناء");
    }

    return { success: true, apkBuffer: finalBuffer, signed, modifications };
  }

  // For EXE/DLL/SO: export as ZIP with modified files
  // For JAR/AAR/IPA: repackage as original format
  if (!session) return { success: false, signed: false, modifications, error: "الجلسة انتهت" };

  try {
    const zip = new JSZip();
    const allFiles = readDirRecursive(session.decompDir);
    for (const filePath of allFiles) {
      const relPath = path.relative(session.decompDir, filePath);
      zip.file(relPath, fs.readFileSync(filePath));
    }

    // JAR/AAR: repackage as .jar/.aar (they are ZIP format)
    if (ext === "jar" || ext === "aar") {
      const jarBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
      modifications.push(`📦 تم إعادة تجميع ${ext.toUpperCase()} بنجاح`);
      return { success: true, apkBuffer: jarBuffer, signed: false, modifications };
    }

    // IPA: repackage as .ipa (ZIP format with Payload/ structure)
    if (ext === "ipa") {
      const ipaBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
      modifications.push("📦 تم إعادة تجميع IPA — يحتاج إعادة توقيع بشهادة Apple");
      return { success: true, apkBuffer: ipaBuffer, signed: false, modifications };
    }

    // DEX: export modified files
    if (ext === "dex") {
      const dexBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
      modifications.push("📦 تم تصدير ملفات DEX المعدّلة");
      return { success: true, apkBuffer: dexBuffer, signed: false, modifications };
    }

    // WASM: export modified WAT/text files
    if (ext === "wasm") {
      const wasmBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
      modifications.push("📦 تم تصدير تحليل WASM المعدّل — يحتاج wat2wasm لإعادة الترجمة");
      return { success: true, apkBuffer: wasmBuffer, signed: false, modifications };
    }

    // EX4/EX5: export AI-reconstructed MQ4/MQ5 source + analysis
    if (ext === "ex4" || ext === "ex5") {
      const mqBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
      modifications.push(`📦 تم تصدير كود ${ext === "ex4" ? "MQ4" : "MQ5"} المُعاد بناؤه + التحليل`);
      return { success: true, apkBuffer: mqBuffer, signed: false, modifications };
    }

    // EXE/DLL/SO/ELF: export modified analysis + source reconstruction
    const defaultBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
    modifications.push(`📦 تم تصدير التحليل والملفات المعدّلة (${ext.toUpperCase()})`);
    return { success: true, apkBuffer: defaultBuffer, signed: false, modifications };
    const zipBuffer = await zip.generateAsync({ type: "nodebuffer", compression: "DEFLATE" });
    return { success: true, apkBuffer: zipBuffer, signed: false, modifications };
  } catch (err: any) {
    return { success: false, signed: false, modifications, error: `فشل التصدير: ${err.message}` };
  }
}

// ════════════════════════════════════════════════════════════════
// APK Signing Helpers — Multiple methods for maximum compatibility
// ════════════════════════════════════════════════════════════════

async function signAPKBuffer(apkBuffer: Buffer): Promise<{ signed: boolean; buffer: Buffer }> {
  const tmpDir = path.join(os.tmpdir(), `hayo-sign-${Date.now()}`);
  const inputPath = path.join(tmpDir, "input.apk");
  const outputPath = path.join(tmpDir, "input-aligned-signed.apk"); // uber-apk-signer output pattern

  try {
    fs.mkdirSync(tmpDir, { recursive: true });
    fs.writeFileSync(inputPath, apkBuffer);

    // Try uber-apk-signer (best option — handles everything automatically)
    const uberPaths = [
      "/home/runner/uber-apk-signer.jar",
      path.join(process.cwd(), "uber-apk-signer.jar"),
      "/opt/uber-apk-signer.jar",
    ];

    for (const uberPath of uberPaths) {
      if (fs.existsSync(uberPath)) {
        try {
          execSync(`java -jar "${uberPath}" --apks "${inputPath}" --out "${tmpDir}" --allowResign`, {
            timeout: 120000, stdio: "pipe",
          });
          // uber-apk-signer creates: input-aligned-debugSigned.apk or similar
          const signed = fs.readdirSync(tmpDir).find(f => f.includes("Signed") || f.includes("signed"));
          if (signed) {
            const result = fs.readFileSync(path.join(tmpDir, signed));
            return { signed: true, buffer: result };
          }
        } catch (e: any) {
          console.warn("[Sign] uber-apk-signer failed:", e.message?.substring(0, 100));
        }
      }
    }

    return { signed: false, buffer: apkBuffer };
  } finally {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }
}

async function signAPKFile(apkPath: string): Promise<Buffer | null> {
  const keystorePath = path.join(os.tmpdir(), "hayo-debug.jks");

  // Ensure keystore exists
  if (!fs.existsSync(keystorePath)) {
    try {
      execSync(
        `keytool -genkeypair -v -keystore "${keystorePath}" -keyalg RSA -keysize 2048 -validity 10000 -alias hayo -storepass hayoai123 -keypass hayoai123 -dname "CN=HAYO AI, OU=Dev, O=HAYO, L=Unknown, ST=Unknown, C=US"`,
        { timeout: 30000, stdio: "pipe" }
      );
    } catch { return null; }
  }

  // Try apksigner
  try {
    const signedPath = apkPath.replace(".apk", "-signed.apk");
    execSync(
      `apksigner sign --ks "${keystorePath}" --ks-pass pass:hayoai123 --key-pass pass:hayoai123 --out "${signedPath}" "${apkPath}"`,
      { timeout: 60000, stdio: "pipe" }
    );
    if (fs.existsSync(signedPath)) return fs.readFileSync(signedPath);
  } catch {}

  // Try jarsigner
  try {
    execSync(
      `jarsigner -verbose -sigalg SHA256withRSA -digestalg SHA-256 -keystore "${keystorePath}" -storepass hayoai123 -keypass hayoai123 "${apkPath}" hayo`,
      { timeout: 60000, stdio: "pipe" }
    );
    return fs.readFileSync(apkPath);
  } catch {}

  return null;
}

// ════════════════════════════════════════════════════════════════
// Intelligence Report — Deep security scan
// ════════════════════════════════════════════════════════════════

export async function generateIntelligenceReport(
  sessionId: string
): Promise<{
  ssl: string[];
  root: string[];
  crypto: string[];
  secrets: string[];
  urls: string[];
  summary: string;
}> {
  const session = editSessions.get(sessionId);
  if (!session) throw new Error("الجلسة غير موجودة");

  const allFiles = readDirRecursive(session.decompDir);
  const findings = { ssl: [] as string[], root: [] as string[], crypto: [] as string[], secrets: [] as string[], urls: [] as string[] };

  const patterns = {
    ssl: [/TrustManager/gi, /X509TrustManager/gi, /ALLOW_ALL_HOSTNAME/gi, /SSLSocketFactory/gi, /certificate.*pin/gi],
    root: [/su\b/g, /Superuser/gi, /RootBeer/gi, /isRooted/gi, /com\.topjohnwu/gi, /magisk/gi],
    crypto: [/AES/g, /DES\b/g, /RSA/g, /SHA\-?256/gi, /MD5/gi, /Base64/g, /encrypt/gi, /decrypt/gi, /cipher/gi],
    secrets: [/api[_-]?key/gi, /secret[_-]?key/gi, /password/gi, /token/gi, /Bearer\s/g, /auth[_-]?token/gi, /private[_-]?key/gi],
    urls: [/https?:\/\/[^\s"'<>]+/g, /wss?:\/\/[^\s"'<>]+/g],
  };

  for (const filePath of allFiles) {
    const ext = path.extname(filePath).toLowerCase();
    if (![".smali", ".xml", ".json", ".txt", ".properties", ".java", ".kt", ".js", ".html", ".yml", ".yaml"].includes(ext)) continue;

    try {
      const stat = fs.statSync(filePath);
      if (stat.size > 500000) continue;
      const content = fs.readFileSync(filePath, "utf-8");
      const relPath = path.relative(session.decompDir, filePath);

      for (const [category, regexList] of Object.entries(patterns)) {
        for (const regex of regexList) {
          const matches = content.match(regex);
          if (matches) {
            const key = category as keyof typeof findings;
            for (const match of matches.slice(0, 3)) {
              // Get context (surrounding line)
              const idx = content.indexOf(match);
              const lineStart = content.lastIndexOf("\n", idx) + 1;
              const lineEnd = content.indexOf("\n", idx + match.length);
              const line = content.substring(lineStart, lineEnd > -1 ? lineEnd : lineStart + 200).trim();
              findings[key].push(`${relPath}: ${line.substring(0, 150)}`);
            }
          }
        }
      }
    } catch { /* skip */ }
  }

  // Deduplicate
  for (const key of Object.keys(findings) as Array<keyof typeof findings>) {
    findings[key] = [...new Set(findings[key])].slice(0, 50);
  }

  return {
    ...findings,
    summary: `SSL/TLS: ${findings.ssl.length} | Root Detection: ${findings.root.length} | Crypto: ${findings.crypto.length} | Secrets: ${findings.secrets.length} | URLs: ${findings.urls.length}`,
  };
}

// ════════════════════════════════════════════════════════════════
// Regex Search — Search across all files with regex pattern
// ════════════════════════════════════════════════════════════════

export function regexSearchFiles(
  sessionId: string,
  pattern: string,
  category?: string
): Array<{ filePath: string; line: number; match: string; context: string }> {
  const session = editSessions.get(sessionId);
  if (!session) throw new Error("الجلسة غير موجودة");

  // Preset patterns by category
  const presetPatterns: Record<string, string> = {
    ssl: "TrustManager|X509|SSLSocket|ALLOW_ALL|certificate",
    root: "su\\b|Superuser|isRooted|RootBeer|magisk|topjohnwu",
    crypto: "AES|DES\\b|RSA|SHA.?256|MD5|encrypt|decrypt|cipher|Base64",
    secrets: "api.?key|secret.?key|password|token|Bearer|auth.?token|private.?key",
    urls: "https?://[^\\s\"'<>]+",
  };

  const searchPattern = category ? presetPatterns[category] || pattern : pattern;
  let regex: RegExp;
  try {
    regex = new RegExp(searchPattern, "gi");
  } catch {
    throw new Error(`نمط Regex غير صالح: ${searchPattern}`);
  }

  const results: Array<{ filePath: string; line: number; match: string; context: string }> = [];
  const allFiles = readDirRecursive(session.decompDir);

  for (const filePath of allFiles) {
    const ext = path.extname(filePath).toLowerCase();
    if (![".smali", ".xml", ".json", ".txt", ".properties", ".java", ".kt", ".js", ".html", ".yml", ".yaml", ".cfg", ".ini", ".pro"].includes(ext)) continue;

    try {
      const stat = fs.statSync(filePath);
      if (stat.size > 500000) continue;
      const content = fs.readFileSync(filePath, "utf-8");
      const lines = content.split("\n");
      const relPath = path.relative(session.decompDir, filePath);

      for (let i = 0; i < lines.length; i++) {
        const match = lines[i].match(regex);
        if (match) {
          results.push({
            filePath: relPath,
            line: i + 1,
            match: match[0],
            context: lines[i].trim().substring(0, 200),
          });
          if (results.length >= 200) return results;
        }
        // Reset regex lastIndex for global flag
        regex.lastIndex = 0;
      }
    } catch { /* skip */ }
  }

  return results;
}
