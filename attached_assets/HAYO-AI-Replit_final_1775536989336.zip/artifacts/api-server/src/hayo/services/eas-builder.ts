/**
 * EAS Builder Service — builds Android APK via Expo EAS Build cloud
 * Uses EXPO_ACCESS_TOKEN env var (set as Replit Secret)
 */
import { execSync, spawn } from "child_process";
import fs from "fs";
import path from "path";
import os from "os";
import crypto from "crypto";

const EXPO_OWNER = "ahmet80";
const BUILD_DIR_ROOT = path.join(os.tmpdir(), "hayo-builds");

export interface BuildResult {
  expoJobId: string;
  expoSlug: string;
  buildLogsUrl: string;
}

export interface BuildStatus {
  status: "queued" | "in_progress" | "finished" | "errored" | "cancelled";
  downloadUrl?: string;
  errorMessage?: string;
  buildLogsUrl?: string;
}

// Ensure build dir root exists
if (!fs.existsSync(BUILD_DIR_ROOT)) {
  fs.mkdirSync(BUILD_DIR_ROOT, { recursive: true });
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 30);
}

export async function createExpoProject(
  appName: string,
  appCode: string,
  iconUrl?: string,
  options?: {
    extraPackages?: string[];
    embeddedData?: Array<{ filename: string; content: string }>;
    supabaseUrl?: string;
    supabaseKey?: string;
    customKeystoreBase64?: string;
  },
): Promise<{ projectDir: string; slug: string }> {
  const uid = crypto.randomBytes(4).toString("hex");
  const slug = `hayo-${slugify(appName)}-${uid}`;
  const projectDir = path.join(BUILD_DIR_ROOT, slug);

  fs.mkdirSync(projectDir, { recursive: true });
  fs.mkdirSync(path.join(projectDir, "assets"), { recursive: true });
  fs.mkdirSync(path.join(projectDir, "data"), { recursive: true });

  // ── Download custom icon if provided ─────────────────────────
  let iconPath: string | undefined;
  if (iconUrl) {
    try {
      const iconRes = await fetch(iconUrl, { signal: AbortSignal.timeout(15_000) });
      if (iconRes.ok) {
        const buf = Buffer.from(await iconRes.arrayBuffer());
        const dest = path.join(projectDir, "assets", "icon.png");
        fs.writeFileSync(dest, buf);
        iconPath = "./assets/icon.png";
        console.log(`[EAS] Icon downloaded: ${iconUrl} → ${dest}`);
      } else {
        console.warn(`[EAS] Failed to download icon (${iconRes.status}), using default`);
      }
    } catch (e) {
      console.warn(`[EAS] Icon download error: ${e}, using default`);
    }
  }

  // app.json — configured for Expo SDK 52
  const appJson: any = {
    expo: {
      name: appName,
      slug,
      version: "1.0.0",
      sdkVersion: "52.0.0",
      orientation: "portrait",
      owner: EXPO_OWNER,
      platforms: ["android"],
      android: {
        package: `com.hayo.${slug.replace(/-/g, "").slice(0, 30)}`,
        adaptiveIcon: {
          backgroundColor: "#1a1a2e",
          ...(iconPath ? { foregroundImage: iconPath } : {}),
        },
        versionCode: 1,
      },
      newArchEnabled: false,
    },
  };

  // Set icon if downloaded
  if (iconPath) {
    appJson.expo.icon = iconPath;
  }

  fs.writeFileSync(
    path.join(projectDir, "app.json"),
    JSON.stringify(appJson, null, 2)
  );

  // package.json — Expo SDK 52 with exact versions verified by `expo doctor`
  // CRITICAL: "main" must be "index.js" (not "App.tsx") so registerRootComponent is called.
  // Without registerRootComponent, the APK opens then immediately crashes on Android.
  fs.writeFileSync(
    path.join(projectDir, "package.json"),
    JSON.stringify({
      name: slug,
      version: "1.0.0",
      main: "index.js",
      scripts: { start: "expo start" },
      dependencies: {
        "expo": "~52.0.0",
        "react": "18.3.1",
        "react-native": "0.76.9",
        "@expo/vector-icons": "~14.0.4",
        "expo-status-bar": "~2.0.0",
        "expo-clipboard": "~7.0.0",
        "expo-linear-gradient": "~14.0.0",
        "expo-haptics": "~14.0.0",
        "expo-blur": "~14.0.0",
        "@react-native-async-storage/async-storage": "2.1.0",
        "expo-file-system": "~18.0.0",
        "expo-sharing": "~13.0.0",
        "expo-image-picker": "~16.0.0",
        "expo-camera": "~16.0.0",
        "expo-location": "~18.0.0",
        "expo-notifications": "~0.29.0",
        "expo-device": "~7.0.0",
        "expo-sensors": "~14.0.0",
        "expo-web-browser": "~14.0.0",
        "expo-linking": "~7.0.0",
        ...(options?.supabaseUrl ? {"@supabase/supabase-js": "^2.45.0"} : {}),
      },
      devDependencies: {
        "@babel/core": "^7.24.0",
        "@types/react": "~18.3.12",
        "typescript": "^5.3.3",
      },
    }, null, 2)
  );

  // tsconfig.json
  fs.writeFileSync(
    path.join(projectDir, "tsconfig.json"),
    JSON.stringify({ extends: "expo/tsconfig.base", compilerOptions: { strict: true } }, null, 2)
  );

  // eas.json
  fs.writeFileSync(
    path.join(projectDir, "eas.json"),
    JSON.stringify({
      cli: { version: ">= 10.0.0", appVersionSource: "local" },
      build: {
        production: {
          android: { buildType: "apk" },
        },
      },
    }, null, 2)
  );

  // babel.config.js
  fs.writeFileSync(
    path.join(projectDir, "babel.config.js"),
    `module.exports = function(api) { api.cache(true); return { presets: ['babel-preset-expo'] }; };`
  );

  // index.js — CRITICAL entry point that registers the root component.
  // Without this, Android APKs open and immediately crash.
  // "main": "index.js" in package.json points here.
  fs.writeFileSync(
    path.join(projectDir, "index.js"),
    `import { registerRootComponent } from 'expo';
import App from './App';
registerRootComponent(App);
`
  );

  // ── Write embedded data files ──
  if (options?.embeddedData?.length) {
    for (const d of options.embeddedData) {
      const safeName = d.filename.replace(/[^a-zA-Z0-9._-]/g, "_");
      fs.writeFileSync(path.join(projectDir, "data", safeName), d.content);
    }
  }

  // ── Write Supabase config ──
  if (options?.supabaseUrl && options?.supabaseKey) {
    fs.writeFileSync(path.join(projectDir, "supabase.ts"),
      `import { createClient } from '@supabase/supabase-js';\nexport const supabase = createClient('${options.supabaseUrl}', '${options.supabaseKey}');\n`);
  }

  // ── Custom keystore ──
  if (options?.customKeystoreBase64) {
    fs.writeFileSync(path.join(projectDir, "release.keystore"), Buffer.from(options.customKeystoreBase64, "base64"));
    const easJson = JSON.parse(fs.readFileSync(path.join(projectDir, "eas.json"), "utf-8"));
    easJson.build.production.android.credentialsSource = "local";
    fs.writeFileSync(path.join(projectDir, "eas.json"), JSON.stringify(easJson, null, 2));
    fs.writeFileSync(path.join(projectDir, "credentials.json"), JSON.stringify({
      android: { keystore: { keystorePath: "release.keystore", keystorePassword: "hayo123", keyAlias: "hayo", keyPassword: "hayo123" } }
    }, null, 2));
  }

  // App.tsx — the generated code
  fs.writeFileSync(path.join(projectDir, "App.tsx"), appCode);

  return { projectDir, slug };
}

export async function submitEASBuild(projectDir: string, slug: string): Promise<BuildResult> {
  const token = process.env.EXPO_ACCESS_TOKEN;
  if (!token) throw new Error("EXPO_ACCESS_TOKEN غير مضبوط");

  // ── Initialize git repository (required by EAS) ──────────────────
  const gitEnv = {
    ...process.env,
    HOME: process.env.HOME || "/root",
    GIT_AUTHOR_NAME: "HAYO AI",
    GIT_AUTHOR_EMAIL: "build@hayo.ai",
    GIT_COMMITTER_NAME: "HAYO AI",
    GIT_COMMITTER_EMAIL: "build@hayo.ai",
  };

  // Configure git identity globally (some environments need this)
  try {
    execSync('git config --global user.email "build@hayo.ai" && git config --global user.name "HAYO AI"', {
      env: gitEnv, stdio: "pipe",
    });
  } catch { /* non-fatal */ }

  const easEnv = {
    ...process.env,
    EXPO_TOKEN: token,
    CI: "1",
    EXPO_DEBUG: "0",
    EAS_BUILD_NO_EXPO_GO_WARNING: "true",   // suppress Expo Go warning
    ...gitEnv,
  };
  delete (easEnv as any).EAS_NO_VCS;  // remove any stale VCS override

  // ── Run yarn install locally to generate yarn.lock (EAS uses it directly) ──
  // This prevents yarn resolution failures on EAS servers.
  console.log("[EAS Builder] Running yarn install locally to generate yarn.lock...");
  try {
    // Use a persistent cache dir so subsequent builds are faster (~30s vs ~5min)
    const yarnCacheDir = path.join(os.tmpdir(), "hayo-yarn-cache");
    execSync("yarn install --non-interactive 2>&1", {
      cwd: projectDir,
      env: { ...process.env, HOME: process.env.HOME || "/root", YARN_CACHE_FOLDER: yarnCacheDir },
      stdio: "pipe",
      timeout: 360_000,  // 6 min (first install is slow)
    });
    // Remove node_modules to keep upload small — yarn.lock is all EAS needs
    execSync("rm -rf node_modules", { cwd: projectDir, stdio: "pipe" });
    console.log("[EAS Builder] yarn.lock generated successfully");
  } catch (yarnErr: any) {
    const msg = yarnErr.stdout?.toString() || yarnErr.stderr?.toString() || yarnErr.message;
    throw new Error(`فشل تثبيت التبعيات محلياً: ${msg.slice(0, 500)}`);
  }

  // ── Git init (must be after yarn so yarn.lock is included) ───────
  try {
    execSync("git init", { cwd: projectDir, env: gitEnv, stdio: "pipe" });
    execSync("git add -A", { cwd: projectDir, env: gitEnv, stdio: "pipe" });
    execSync("git commit -m 'init'", { cwd: projectDir, env: gitEnv, stdio: "pipe" });
  } catch (gitErr: any) {
    const msg = gitErr.stderr?.toString() || gitErr.stdout?.toString() || gitErr.message;
    throw new Error(`فشل تهيئة git: ${msg}`);
  }

  // ── eas init: register project with Expo (sets projectId in app.json) ──
  let initSucceeded = false;
  try {
    const initOut = execSync(
      "eas init --non-interactive --force 2>&1",
      { cwd: projectDir, env: easEnv, stdio: "pipe", timeout: 60_000 }
    );
    console.log("[EAS init]", initOut.toString().slice(0, 400));
    initSucceeded = true;
  } catch (initErr: any) {
    const errMsg = initErr.stdout?.toString() || initErr.stderr?.toString() || initErr.message;
    console.warn("[EAS init warning]", errMsg.slice(0, 300));
  }

  // Verify projectId was added to app.json — if not, inject it via Expo API
  if (!initSucceeded) {
    try {
      const currentAppJson = JSON.parse(fs.readFileSync(path.join(projectDir, "app.json"), "utf-8"));
      if (!currentAppJson.expo?.extra?.eas?.projectId) {
        console.log("[EAS] projectId missing — creating project via Expo API...");
        const createRes = await fetch("https://api.expo.dev/v2/projects", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ slug, privacy: "unlisted", accountName: EXPO_OWNER }),
        });
        if (createRes.ok) {
          const proj = await createRes.json() as any;
          const projectId = proj.data?.id;
          if (projectId) {
            currentAppJson.expo.extra = { ...(currentAppJson.expo.extra || {}), eas: { projectId } };
            fs.writeFileSync(path.join(projectDir, "app.json"), JSON.stringify(currentAppJson, null, 2));
            console.log(`[EAS] projectId injected: ${projectId}`);
          }
        } else {
          console.warn(`[EAS] Could not create project via API: ${createRes.status}`);
        }
      }
    } catch (injectErr: any) {
      console.warn("[EAS] projectId injection failed:", injectErr.message);
    }
  }

  // Re-commit after eas init (updates app.json with projectId)
  try {
    execSync("git add -A && git commit -m 'eas init' --allow-empty", { cwd: projectDir, env: gitEnv, stdio: "pipe" });
  } catch { /* ignore */ }

  return new Promise((resolve, reject) => {
    const cmd = spawn(
      "eas",
      ["build", "--platform", "android", "--profile", "production", "--non-interactive", "--no-wait", "--json"],
      {
        cwd: projectDir,
        env: easEnv,
        shell: true,
      }
    );

    let stdout = "";
    let stderr = "";

    cmd.stdout.on("data", (d: Buffer) => { stdout += d.toString(); });
    cmd.stderr.on("data", (d: Buffer) => { stderr += d.toString(); });

    cmd.on("close", (code) => {
      // Try to parse JSON output
      const jsonMatch = stdout.match(/\[[\s\S]*\]|\{[\s\S]*\}/);
      if (jsonMatch) {
        try {
          const parsed = JSON.parse(jsonMatch[0]);
          const buildInfo = Array.isArray(parsed) ? parsed[0] : parsed;
          if (buildInfo?.id) {
            return resolve({
              expoJobId: buildInfo.id,
              expoSlug: slug,
              buildLogsUrl: `https://expo.dev/accounts/${EXPO_OWNER}/projects/${slug}/builds/${buildInfo.id}`,
            });
          }
        } catch {}
      }

      // Fallback: extract build ID from URL in output
      const urlMatch = (stdout + stderr).match(/builds\/([a-f0-9-]{36})/);
      if (urlMatch) {
        const expoJobId = urlMatch[1];
        return resolve({
          expoJobId,
          expoSlug: slug,
          buildLogsUrl: `https://expo.dev/accounts/${EXPO_OWNER}/projects/${slug}/builds/${expoJobId}`,
        });
      }

      reject(new Error(`فشل إرسال البناء (code ${code}):\n${stderr.slice(0, 500)}`));
    });

    // Timeout after 3 minutes
    setTimeout(() => {
      cmd.kill();
      reject(new Error("انتهت مهلة إرسال البناء"));
    }, 180_000);
  });
}

export async function checkEASBuildStatus(expoJobId: string, expoSlug?: string): Promise<BuildStatus> {
  const token = process.env.EXPO_ACCESS_TOKEN;
  if (!token) throw new Error("EXPO_ACCESS_TOKEN غير مضبوط");

  const slug = expoSlug || "";

  // Query the specific build directly by its ID — most reliable approach
  const query = `{
    builds {
      byId(buildId: "${expoJobId}") {
        id
        status
        artifacts { buildUrl }
        error { message }
        expirationDate
        completionDate
      }
    }
  }`;

  const res = await fetch("https://api.expo.dev/graphql", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ query }),
  });

  if (!res.ok) {
    throw new Error(`Expo GraphQL error ${res.status}: ${res.statusText}`);
  }

  const json = await res.json() as any;

  // Fallback: if byId doesn't exist (older API), query by project
  let build = json?.data?.builds?.byId;

  if (!build && !json.errors?.length) {
    // Fallback to project-level query
    const fallbackQuery = slug
      ? `{ app { byFullName(fullName: "@${EXPO_OWNER}/${slug}") { builds(limit: 5, offset: 0) { id status artifacts { buildUrl } error { message } } } } }`
      : `{ account { byName(accountName: "${EXPO_OWNER}") { builds(limit: 20, offset: 0) { id status artifacts { buildUrl } error { message } } } } }`;

    const fallbackRes = await fetch("https://api.expo.dev/graphql", {
      method: "POST",
      headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ query: fallbackQuery }),
    });

    if (fallbackRes.ok) {
      const fallbackJson = await fallbackRes.json() as any;
      const builds: any[] = slug
        ? (fallbackJson?.data?.app?.byFullName?.builds || [])
        : (fallbackJson?.data?.account?.byName?.builds || []);
      build = builds.find((b: any) => b.id === expoJobId) || builds[0];
    }
  }

  if (!build) {
    // Build not yet visible — keep polling
    return { status: "in_progress" };
  }

  // Normalize status: Expo API returns UPPER_CASE
  const rawStatus = (build.status || "").toUpperCase();
  const normalizedStatus: BuildStatus["status"] =
    rawStatus === "FINISHED"                             ? "finished"
    : rawStatus === "ERRORED" || rawStatus === "EXPIRED" ? "errored"
    : rawStatus === "CANCELLED"                          ? "cancelled"
    : rawStatus === "IN_PROGRESS"                        ? "in_progress"
    : "queued";

  const downloadUrl = build.artifacts?.buildUrl || undefined;
  const buildLogsUrl = `https://expo.dev/accounts/${EXPO_OWNER}/projects/${slug}/builds/${expoJobId}`;

  return {
    status: normalizedStatus,
    downloadUrl,
    errorMessage: build.error?.message || undefined,
    buildLogsUrl,
  };
}

export function cleanupProjectDir(projectDir: string) {
  try {
    fs.rmSync(projectDir, { recursive: true, force: true });
  } catch {}
}

// ════════════════════════════════════════════════════════════════
// AI Code Review — inspect and fix code before submitting to EAS
// Uses Claude Opus for deep analysis + DeepSeek as backup
// ════════════════════════════════════════════════════════════════

export async function aiReviewAndFix(
  code: string,
  errorLog?: string
): Promise<{ fixedCode: string; issues: string[]; modelUsed: string; validatorModel: string }> {
  const { callPowerAI, callOfficeAI } = await import("../providers.js");

  const RULES = `القواعد الصارمة:
1. أعد الكود المُصلح بالكامل (ليس فقط التغييرات)
2. الحزم المسموحة فقط: react-native core, expo-status-bar, @expo/vector-icons (Ionicons/MaterialIcons/FontAwesome), expo-clipboard, expo-linear-gradient, expo-haptics, expo-blur, @react-native-async-storage/async-storage
3. ممنوع: react-navigation, expo-router, expo-camera, expo-av, expo-notifications, react-native-maps, أي حزمة غير مذكورة
4. ممنوع: expo-font, useFonts, Font.loadAsync
5. ممنوع: Clipboard from 'react-native' — استخدم expo-clipboard
6. ممنوع: fontFamily غير آمنة (Arial, Helvetica, Georgia) — فقط sans-serif, serif, monospace
7. ممنوع: StatusBar from 'react-native' — استخدم expo-status-bar
8. كل شيء في ملف واحد App.tsx
9. لازم يبدأ بـ import React ... وينتهي بـ export default
10. لازم registerRootComponent يكون في index.js منفصل — لا تضيفه في App.tsx`;

  // ═══ PHASE 1: AI #1 (Claude Opus) — Fix code ═══
  const fixPrompt = `أنت مطور React Native/Expo محترف. مهمتك إصلاح الكود.\n\n${RULES}\n\nأعد JSON:\n{"fixedCode": "الكود المصلح بالكامل", "issues": ["مشكلة 1", ...]}`;
  const fixMsg = errorLog
    ? `فشل البناء مع هذا الخطأ:\n--- ERROR ---\n${errorLog.substring(0, 3000)}\n--- END ---\n\nالكود:\n\`\`\`tsx\n${code.substring(0, 25000)}\n\`\`\`\n\nأصلح الأخطاء وأعد الكود كاملاً.`
    : `افحص وأصلح:\n\`\`\`tsx\n${code.substring(0, 25000)}\n\`\`\``;

  const phase1 = await callPowerAI(fixPrompt, fixMsg, 16000);
  let fixedCode = code;
  let issues: string[] = [];

  try {
    const cleaned = phase1.content.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const jsonMatch = cleaned.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      fixedCode = parsed.fixedCode || code;
      fixedCode = fixedCode.replace(/^```(?:tsx?|javascript|jsx)?\n?/i, "").replace(/\n?```\s*$/i, "").trim();
      issues = parsed.issues || [];
    }
  } catch {
    const codeMatch = phase1.content.match(/```tsx?\n([\s\S]*?)```/);
    if (codeMatch) fixedCode = codeMatch[1].trim();
  }

  // ═══ PHASE 2: AI #2 (Sonnet/DeepSeek) — Validate and catch remaining issues ═══
  const validatePrompt = `أنت مدقق كود React Native/Expo صارم. مهمتك فحص الكود المُصلح والتأكد أنه لن يسبب crash أو build error.

${RULES}

افحص هذا الكود وأصلح أي مشكلة باقية. إذا الكود سليم أعده كما هو.
أعد JSON فقط:
{"fixedCode": "الكود النهائي", "extraIssues": ["مشكلة إضافية 1", ...]}`;

  try {
    const phase2Raw = await callOfficeAI(
      validatePrompt,
      `دقق هذا الكود المُصلح بالفعل:\n\`\`\`tsx\n${fixedCode.substring(0, 25000)}\n\`\`\``,
      16000,
      "claude-sonnet-4-6"
    );

    const cleaned2 = phase2Raw.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();
    const json2 = cleaned2.match(/\{[\s\S]*\}/);
    if (json2) {
      const parsed2 = JSON.parse(json2[0]);
      if (parsed2.fixedCode && parsed2.fixedCode.length > 100) {
        fixedCode = parsed2.fixedCode.replace(/^```(?:tsx?|javascript|jsx)?\n?/i, "").replace(/\n?```\s*$/i, "").trim();
      }
      if (parsed2.extraIssues?.length) {
        issues.push(...parsed2.extraIssues.map((i: string) => `[تدقيق] ${i}`));
      }
    }
  } catch (e: any) {
    console.warn("[aiReviewAndFix] Phase 2 validator failed:", e.message);
    // Not fatal — phase 1 fix is still usable
  }

  // ═══ PHASE 3: Safety post-processing ═══
  // Remove known crash patterns even if AI missed them
  fixedCode = fixedCode.replace(/^import \* as Font from ['"]expo-font['"];?\n?/gm, "");
  fixedCode = fixedCode.replace(/^import \{[^}]*useFonts[^}]*\} from ['"]expo-font['"];?\n?/gm, "");
  fixedCode = fixedCode.replace(/const \[fontsLoaded[^\]]*\][^;]*;?\s*\n?/g, "");
  fixedCode = fixedCode.replace(/if\s*\(!?fontsLoaded\)\s*\{?\s*return\s+null\s*;?\s*\}?\s*\n?/g, "");
  if (/import \{ Clipboard \} from ['"]react-native['"]/.test(fixedCode)) {
    fixedCode = fixedCode.replace(/import \{ Clipboard \} from ['"]react-native['"]/g, "import * as Clipboard from 'expo-clipboard'");
    fixedCode = fixedCode.replace(/Clipboard\.getString\(\)/g, "Clipboard.getStringAsync()");
  }
  const unsafeFonts = ["Arial", "Helvetica", "Georgia", "Times New Roman", "Courier New", "Verdana", "Tahoma"];
  for (const font of unsafeFonts) {
    fixedCode = fixedCode.replace(new RegExp(`fontFamily:\\s*['"]${font}['"]`, "g"), "fontFamily: 'sans-serif'");
  }

  if (!fixedCode || fixedCode.length < 50) fixedCode = code;

  return {
    fixedCode,
    issues,
    modelUsed: phase1.modelUsed,
    validatorModel: "claude-sonnet-4-6",
  };
}

// ════════════════════════════════════════════════════════════════
// Create Expo Project from uploaded ZIP/files
// Extracts, validates, fixes with AI, then submits
// ════════════════════════════════════════════════════════════════

export async function createExpoProjectFromUpload(
  files: Array<{ name: string; content: string }>,
  appName: string,
  iconUrl?: string,
): Promise<{ projectDir: string; slug: string; fixLog: string[] }> {
  const uid = crypto.randomBytes(4).toString("hex");
  const slug = `hayo-${slugify(appName)}-${uid}`;
  const projectDir = path.join(BUILD_DIR_ROOT, slug);
  const fixLog: string[] = [];

  fs.mkdirSync(projectDir, { recursive: true });
  fs.mkdirSync(path.join(projectDir, "assets"), { recursive: true });

  // Download icon if provided
  if (iconUrl) {
    try {
      const iconRes = await fetch(iconUrl, { signal: AbortSignal.timeout(15000) });
      if (iconRes.ok) {
        fs.writeFileSync(path.join(projectDir, "assets", "icon.png"), Buffer.from(await iconRes.arrayBuffer()));
        fixLog.push("✅ تم تحميل الأيقونة");
      }
    } catch { fixLog.push("⚠️ فشل تحميل الأيقونة"); }
  }

  // Check if App.tsx exists in uploaded files
  let appTsx = files.find(f => f.name === "App.tsx" || f.name === "App.jsx" || f.name === "app.tsx");
  const hasPackageJson = files.find(f => f.name === "package.json");
  const hasAppJson = files.find(f => f.name === "app.json");

  if (!appTsx) {
    // Look deeper in folder structure
    appTsx = files.find(f => f.name.endsWith("/App.tsx") || f.name.endsWith("/App.jsx"));
  }

  if (!appTsx) {
    // No App.tsx — check if it's a raw code paste (single file)
    const codeFiles = files.filter(f => f.name.endsWith(".tsx") || f.name.endsWith(".jsx") || f.name.endsWith(".ts") || f.name.endsWith(".js"));
    if (codeFiles.length === 1) {
      appTsx = { name: "App.tsx", content: codeFiles[0].content };
      fixLog.push("📝 ملف واحد — استخدمه كـ App.tsx");
    } else {
      throw new Error("لم يتم العثور على App.tsx في الملفات المرفوعة");
    }
  }

  // AI review and fix the main App code
  fixLog.push("🤖 جاري فحص الكود بنموذجين AI...");
  const review = await aiReviewAndFix(appTsx.content);
  const fixerIssues = review.issues.filter(i => !i.startsWith("[تدقيق]"));
  const validatorIssues = review.issues.filter(i => i.startsWith("[تدقيق]"));
  fixLog.push(`🧠 AI#1 (${review.modelUsed}): ${fixerIssues.length} مشكلة تم إصلاحها`);
  fixLog.push(`🔍 AI#2 (${review.validatorModel}): ${validatorIssues.length} مشكلة إضافية`);
  for (const issue of review.issues) {
    fixLog.push(`  🔧 ${issue}`);
  }

  // Write the fixed App.tsx
  fs.writeFileSync(path.join(projectDir, "App.tsx"), review.fixedCode);

  // Write other uploaded files (components, utils, etc.) — skip node_modules, .git
  const skipPatterns = ["node_modules/", ".git/", "dist/", "build/", ".expo/", ".cache/", "__pycache__/"];
  for (const file of files) {
    if (file.name === "App.tsx" || file.name === "App.jsx" || file.name === "app.tsx") continue;
    if (file.name === "package.json" || file.name === "app.json") continue; // We generate our own
    if (skipPatterns.some(p => file.name.includes(p))) continue;
    if (!file.content || file.content.length > 500000) continue;

    const filePath = path.join(projectDir, file.name);
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    fs.writeFileSync(filePath, file.content);
  }

  // Generate standard Expo project files (same as createExpoProject)
  const appJson: any = {
    expo: {
      name: appName, slug, version: "1.0.0", sdkVersion: "52.0.0",
      orientation: "portrait", owner: EXPO_OWNER, platforms: ["android"],
      android: {
        package: `com.hayo.${slug.replace(/-/g, "").slice(0, 30)}`,
        adaptiveIcon: { backgroundColor: "#1a1a2e" },
        versionCode: 1,
      },
      newArchEnabled: false,
    },
  };
  if (fs.existsSync(path.join(projectDir, "assets", "icon.png"))) {
    appJson.expo.icon = "./assets/icon.png";
    appJson.expo.android.adaptiveIcon.foregroundImage = "./assets/icon.png";
  }
  fs.writeFileSync(path.join(projectDir, "app.json"), JSON.stringify(appJson, null, 2));

  // Merge dependencies from uploaded package.json if exists
  const baseDeps: Record<string, string> = {
    "expo": "~52.0.0", "react": "18.3.1", "react-native": "0.76.9",
    "@expo/vector-icons": "~14.0.4", "expo-status-bar": "~2.0.0",
    "expo-clipboard": "~7.0.0", "expo-linear-gradient": "~14.0.0",
    "expo-haptics": "~14.0.0", "expo-blur": "~14.0.0",
    "@react-native-async-storage/async-storage": "2.1.0",
  };

  if (hasPackageJson) {
    try {
      const uploadedPkg = JSON.parse(hasPackageJson.content);
      const uploadedDeps = { ...uploadedPkg.dependencies, ...uploadedPkg.devDependencies };
      // Merge safe dependencies (skip known problematic ones)
      const blocked = ["react-navigation", "expo-router", "expo-camera", "expo-av", "react-native-maps"];
      for (const [name, ver] of Object.entries(uploadedDeps)) {
        if (!blocked.some(b => name.includes(b)) && !baseDeps[name]) {
          baseDeps[name] = ver as string;
          fixLog.push(`📦 تبعية مضافة: ${name}`);
        }
      }
    } catch { fixLog.push("⚠️ فشل قراءة package.json المرفوع"); }
  }

  fs.writeFileSync(path.join(projectDir, "package.json"), JSON.stringify({
    name: slug, version: "1.0.0", main: "index.js",
    scripts: { start: "expo start" },
    dependencies: baseDeps,
    devDependencies: { "@babel/core": "^7.24.0", "@types/react": "~18.3.12", "typescript": "^5.3.3" },
  }, null, 2));

  fs.writeFileSync(path.join(projectDir, "tsconfig.json"), JSON.stringify({ extends: "expo/tsconfig.base", compilerOptions: { strict: true } }, null, 2));
  fs.writeFileSync(path.join(projectDir, "eas.json"), JSON.stringify({ cli: { version: ">= 10.0.0", appVersionSource: "local" }, build: { production: { android: { buildType: "apk" } } } }, null, 2));
  fs.writeFileSync(path.join(projectDir, "babel.config.js"), `module.exports = function(api) { api.cache(true); return { presets: ['babel-preset-expo'] }; };`);
  fs.writeFileSync(path.join(projectDir, "index.js"), `import { registerRootComponent } from 'expo';\nimport App from './App';\nregisterRootComponent(App);\n`);

  fixLog.push("✅ مشروع Expo جاهز للبناء");
  return { projectDir, slug, fixLog };
}

// ════════════════════════════════════════════════════════════════
// submitEASBuild with retry logic — retries up to 2 times on failure
// ════════════════════════════════════════════════════════════════

export async function submitEASBuildWithRetry(
  projectDir: string,
  slug: string,
  appCode: string,
  maxRetries = 2
): Promise<BuildResult & { retries: number; fixLog: string[] }> {
  const fixLog: string[] = [];
  let lastError = "";
  let currentCode = appCode;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      if (attempt > 0) {
        fixLog.push(`🔄 محاولة ${attempt + 1}/${maxRetries + 1}...`);
        // Dual-AI fix: AI#1 fixes, AI#2 validates
        const review = await aiReviewAndFix(currentCode, lastError);
        currentCode = review.fixedCode;
        fixLog.push(`🧠 AI#1 (${review.modelUsed}) أصلح ${review.issues.filter(i => !i.startsWith("[تدقيق]")).length} مشكلة`);
        fixLog.push(`🔍 AI#2 (${review.validatorModel}) دقق ووجد ${review.issues.filter(i => i.startsWith("[تدقيق]")).length} مشكلة إضافية`);
        for (const issue of review.issues) fixLog.push(`  🔧 ${issue}`);
        // Update App.tsx
        fs.writeFileSync(path.join(projectDir, "App.tsx"), currentCode);
        // Re-commit
        try {
          execSync("git add -A && git commit -m 'ai-fix' --allow-empty", {
            cwd: projectDir, stdio: "pipe",
            env: { ...process.env, GIT_AUTHOR_NAME: "HAYO AI", GIT_AUTHOR_EMAIL: "build@hayo.ai", GIT_COMMITTER_NAME: "HAYO AI", GIT_COMMITTER_EMAIL: "build@hayo.ai" },
          });
        } catch {}
      }

      const result = await submitEASBuild(projectDir, slug);
      return { ...result, retries: attempt, fixLog };
    } catch (err: any) {
      lastError = err.message || String(err);
      fixLog.push(`❌ فشل المحاولة ${attempt + 1}: ${lastError.substring(0, 200)}`);
      if (attempt === maxRetries) {
        throw new Error(`فشل البناء بعد ${maxRetries + 1} محاولات:\n${fixLog.join("\n")}`);
      }
    }
  }

  throw new Error("فشل غير متوقع");
}

// ════════════════════════════════════════════════════════════════
// Desktop App Builder — Electron project generator
// ════════════════════════════════════════════════════════════════

export async function createElectronProject(
  appName: string,
  appCode: string,
  iconUrl?: string,
): Promise<{ projectDir: string; slug: string }> {
  const uid = crypto.randomBytes(4).toString("hex");
  const slug = `hayo-desktop-${slugify(appName)}-${uid}`;
  const projectDir = path.join(BUILD_DIR_ROOT, slug);

  fs.mkdirSync(path.join(projectDir, "src"), { recursive: true });
  fs.mkdirSync(path.join(projectDir, "assets"), { recursive: true });

  // Download icon
  if (iconUrl) {
    try {
      const res = await fetch(iconUrl, { signal: AbortSignal.timeout(15000) });
      if (res.ok) fs.writeFileSync(path.join(projectDir, "assets", "icon.png"), Buffer.from(await res.arrayBuffer()));
    } catch {}
  }

  // package.json for Electron
  fs.writeFileSync(path.join(projectDir, "package.json"), JSON.stringify({
    name: slug, version: "1.0.0", main: "main.js",
    scripts: {
      start: "electron .",
      build: "electron-builder --win --x64",
      "build:linux": "electron-builder --linux",
      "build:mac": "electron-builder --mac",
    },
    dependencies: { electron: "^28.0.0" },
    devDependencies: { "electron-builder": "^24.0.0" },
    build: {
      appId: `com.hayo.${slug.replace(/-/g, "")}`,
      productName: appName,
      directories: { output: "dist" },
      win: { target: "nsis", icon: "assets/icon.png" },
      linux: { target: "AppImage" },
      mac: { target: "dmg" },
    },
  }, null, 2));

  // main.js — Electron main process
  fs.writeFileSync(path.join(projectDir, "main.js"), `
const { app, BrowserWindow } = require('electron');
const path = require('path');

function createWindow() {
  const win = new BrowserWindow({
    width: 1200, height: 800,
    webPreferences: { nodeIntegration: true, contextIsolation: false },
    icon: path.join(__dirname, 'assets', 'icon.png'),
  });
  win.loadFile('src/index.html');
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
`);

  // index.html — wraps the app code
  fs.writeFileSync(path.join(projectDir, "src", "index.html"), `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${appName}</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { font-family: 'Segoe UI', system-ui, sans-serif; background: #0a0a0f; color: #fff; }
  </style>
</head>
<body>
  <div id="root"></div>
  <script src="app.js"></script>
</body>
</html>`);

  // app.js — the generated code
  fs.writeFileSync(path.join(projectDir, "src", "app.js"), appCode);

  return { projectDir, slug };
}
