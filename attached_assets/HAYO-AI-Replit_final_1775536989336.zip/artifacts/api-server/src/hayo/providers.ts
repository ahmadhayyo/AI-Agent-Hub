/**
 * Multi-Model AI Provider System
 * claude: Claude Opus 4.5 (primary, strongest)
 * gpt4: Claude Haiku 4.5 (fast, replaces OpenAI which has billing issues)
 * gemini: Gemini 2.5 Flash (Google, upgraded from 2.0)
 * deepseek: DeepSeek R1 (reasoning specialist)
 */
import { createAnthropicClient } from "./llm";

export type AIProvider = "claude" | "gpt4" | "gemini" | "geminiPro" | "deepseek";

export interface ProviderConfig {
  id: AIProvider;
  name: string;
  model: string;
  icon: string;
  color: string;
  role: string;
  envKey: string;
}

export const PROVIDER_CONFIGS: Record<AIProvider, ProviderConfig> = {
  claude: {
    id: "claude",
    name: "Claude Opus",
    model: "claude-opus-4-5",
    icon: "🟣",
    color: "#7C3AED",
    role: "coordinator",
    envKey: "AI_INTEGRATIONS_ANTHROPIC_API_KEY",
  },
  gpt4: {
    id: "gpt4",
    name: "Claude Haiku",
    model: "claude-haiku-4-5",
    icon: "🟡",
    color: "#F59E0B",
    role: "coder",
    envKey: "AI_INTEGRATIONS_ANTHROPIC_API_KEY",
  },
  gemini: {
    id: "gemini",
    name: "Gemini 2.5 Flash",
    model: "gemini-2.5-flash",
    icon: "🔵",
    color: "#3B82F6",
    role: "reviewer",
    envKey: "GEMINI_API_KEY",
  },
  geminiPro: {
    id: "geminiPro",
    name: "Gemini 2.5 Pro",
    model: "gemini-2.5-pro",
    icon: "💎",
    color: "#06B6D4",
    role: "deep-analyst",
    envKey: "GEMINI_API_KEY",
  },
  deepseek: {
    id: "deepseek",
    name: "DeepSeek R1",
    model: "deepseek-reasoner",
    icon: "⚡",
    color: "#F59E0B",
    role: "planner",
    envKey: "DEEPSEEK_API_KEY",
  },
};

export function isProviderAvailable(provider: AIProvider): boolean {
  if (provider === "claude") {
    return !!(process.env.ANTHROPIC_API_KEY || process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY);
  }
  if (provider === "gpt4") {
    // gpt4 slot now uses Claude Haiku via Anthropic
    return !!(process.env.ANTHROPIC_API_KEY || process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY);
  }
  const config = PROVIDER_CONFIGS[provider];
  return !!(process.env[config.envKey]);
}

export function getAvailableProviders(): ProviderConfig[] {
  return Object.values(PROVIDER_CONFIGS).map(p => ({
    ...p,
    available: isProviderAvailable(p.id as AIProvider),
  } as any));
}

/**
 * Call a specific AI provider with a prompt.
 * gpt4 slot now uses Claude Haiku instead of OpenAI (billing issue).
 * Falls back to Claude Opus if any provider fails.
 */
export async function callProvider(
  provider: AIProvider,
  systemPrompt: string,
  userMessage: string
): Promise<{ content: string; provider: AIProvider; duration: number }> {
  const startTime = Date.now();
  const actualProvider = isProviderAvailable(provider) ? provider : "claude";

  try {
    let content = "";

    switch (actualProvider) {
      case "claude": {
        const anthropic = createAnthropicClient();
        const result = await anthropic.messages.create({
          model: PROVIDER_CONFIGS.claude.model,
          max_tokens: 8192,
          system: systemPrompt,
          messages: [{ role: "user", content: userMessage }],
        });
        content = result.content[0].type === "text" ? result.content[0].text : "";
        break;
      }

      case "gpt4": {
        // Uses Claude Haiku (fast Anthropic model) — OpenAI billing suspended
        const anthropic = createAnthropicClient();
        const result = await anthropic.messages.create({
          model: PROVIDER_CONFIGS.gpt4.model, // claude-haiku-4-5
          max_tokens: 4096,
          system: systemPrompt,
          messages: [{ role: "user", content: userMessage }],
        });
        content = result.content[0].type === "text" ? result.content[0].text : "";
        break;
      }

      case "gemini":
      case "geminiPro": {
        // Gemini models via Google Generative AI API
        const modelName = PROVIDER_CONFIGS[actualProvider].model;
        const res = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:generateContent?key=${process.env.GEMINI_API_KEY}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              systemInstruction: { parts: [{ text: systemPrompt }] },
              contents: [{
                role: "user",
                parts: [{ text: userMessage }],
              }],
              generationConfig: { maxOutputTokens: 8192, temperature: 0.3 },
            }),
            signal: AbortSignal.timeout(45000),
          }
        );
        const data = await res.json() as any;
        if (!res.ok || data.error) {
          throw new Error(`${PROVIDER_CONFIGS[actualProvider].name} API error ${res.status}: ${data.error?.message || JSON.stringify(data).slice(0, 200)}`);
        }
        content = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
        break;
      }

      case "deepseek": {
        const res = await fetch("https://api.deepseek.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${process.env.DEEPSEEK_API_KEY}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            model: PROVIDER_CONFIGS.deepseek.model,
            max_tokens: 4096,
            messages: [
              { role: "system", content: systemPrompt },
              { role: "user", content: userMessage },
            ],
          }),
          signal: AbortSignal.timeout(60000),
        });
        const data = await res.json() as any;
        if (!res.ok || data.error) {
          throw new Error(`DeepSeek API error ${res.status}: ${data.error?.message || JSON.stringify(data)}`);
        }
        content = data.choices?.[0]?.message?.content || "";
        break;
      }
    }

    return {
      content,
      provider: actualProvider,
      duration: Date.now() - startTime,
    };
  } catch (error: any) {
    throw new Error(`[${actualProvider}] ${error.message}`);
  }
}

/**
 * Power AI call — uses the strongest available model for heavy tasks.
 * Priority: claude-opus-4-5 → gemini-2.5-flash → claude-sonnet-4-6 → deepseek
 */
export async function callPowerAI(
  systemPrompt: string,
  userMessage: string,
  maxTokens = 16000
): Promise<{ content: string; modelUsed: string }> {
  const hasAnthropicKey = process.env.ANTHROPIC_API_KEY || (process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY && process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL);

  // 1. Try claude-opus-4-5 (strongest Anthropic model)
  if (hasAnthropicKey) {
    try {
      const anthropic = createAnthropicClient();
      const result = await anthropic.messages.create({
        model: "claude-opus-4-5",
        max_tokens: maxTokens,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }],
      });
      const block = result.content[0];
      return { content: block.type === "text" ? block.text : "", modelUsed: "claude-opus-4-5" };
    } catch (e: any) {
      console.warn("[callPowerAI] claude-opus-4-5 failed:", e.message);
    }
  }

  // 2. Try Gemini 2.5 Flash (fast and strong)
  if (process.env.GEMINI_API_KEY) {
    try {
      const model = "gemini-2.5-flash";
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${process.env.GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: systemPrompt }] },
            contents: [{ role: "user", parts: [{ text: userMessage }] }],
            generationConfig: { maxOutputTokens: maxTokens, temperature: 0.2 },
          }),
          signal: AbortSignal.timeout(30000),
        }
      );
      const data = await res.json() as any;
      if (res.ok && !data.error) {
        const content = data.candidates?.[0]?.content?.parts?.[0]?.text || "";
        if (content) return { content, modelUsed: "gemini-2.5-flash" };
      }
      console.warn("[callPowerAI] Gemini 2.5 Flash failed:", data.error?.message);
    } catch (e: any) {
      console.warn("[callPowerAI] Gemini 2.5 Flash error:", e.message);
    }
  }

  // 3. Fall back to claude-sonnet-4-6
  if (hasAnthropicKey) {
    try {
      const anthropic = createAnthropicClient();
      const result = await anthropic.messages.create({
        model: "claude-sonnet-4-6",
        max_tokens: maxTokens,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }],
      });
      const block = result.content[0];
      return { content: block.type === "text" ? block.text : "", modelUsed: "claude-sonnet-4-6" };
    } catch (e: any) {
      console.warn("[callPowerAI] claude-sonnet-4-6 failed:", e.message);
    }
  }

  // 4. DeepSeek as last resort
  if (process.env.DEEPSEEK_API_KEY) {
    const res = await fetch("https://api.deepseek.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "deepseek-reasoner",
        max_tokens: maxTokens,
        messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userMessage }],
      }),
    });
    const data = await res.json() as any;
    if (res.ok && !data.error) return { content: data.choices?.[0]?.message?.content || "", modelUsed: "deepseek-reasoner" };
  }

  throw new Error("لا يوجد نموذج AI قوي متاح. يرجى التحقق من الإعدادات.");
}

/**
 * Fast AI call for Office Suite tasks (uses Haiku for speed).
 * Falls back to DeepSeek if Anthropic is unavailable.
 */
export async function callOfficeAI(
  systemPrompt: string,
  userMessage: string,
  maxTokens = 8192,
  model: "claude-haiku-4-5" | "claude-sonnet-4-6" = "claude-haiku-4-5"
): Promise<string> {
  const hasAnthropicKey = process.env.ANTHROPIC_API_KEY || (process.env.AI_INTEGRATIONS_ANTHROPIC_API_KEY && process.env.AI_INTEGRATIONS_ANTHROPIC_BASE_URL);
  if (hasAnthropicKey) {
    try {
      const anthropic = createAnthropicClient();
      const result = await anthropic.messages.create({
        model,
        max_tokens: maxTokens,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }],
      });
      const block = result.content[0];
      return block.type === "text" ? block.text : "";
    } catch (e: any) {
      console.warn(`[callOfficeAI] ${model} failed, falling back:`, e.message);
    }
  }
  // Fallback to DeepSeek
  if (process.env.DEEPSEEK_API_KEY) {
    const res = await fetch("https://api.deepseek.com/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.DEEPSEEK_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "deepseek-chat",
        max_tokens: maxTokens,
        messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userMessage }],
      }),
    });
    const data = await res.json() as any;
    return data.choices?.[0]?.message?.content || "";
  }
  throw new Error("لا يوجد مزود AI متاح. يرجى التحقق من الإعدادات.");
}
