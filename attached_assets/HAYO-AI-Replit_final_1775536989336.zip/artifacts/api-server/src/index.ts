// ─── Global crash guards — MUST be first ─────────────────────────────
// node-telegram-bot-api (v0.66) uses the legacy `request` library which
// throws unhandled rejections on any non-2xx Telegram API response.
// Without these handlers Node.js v15+ terminates the process.
process.on("unhandledRejection", (reason: any) => {
  const msg: string = reason?.message || String(reason);
  console.warn("[process] unhandledRejection (suppressed):", msg.slice(0, 200));
  // Do NOT re-throw — just log and continue
});
process.on("uncaughtException", (err: Error) => {
  const msg = err?.message || String(err);
  // Only suppress known Telegram / network transient errors
  if (
    msg.includes("query is too old") ||
    msg.includes("ETELEGRAM") ||
    msg.includes("EFATAL") ||
    msg.includes("ECONNRESET") ||
    msg.includes("socket hang up")
  ) {
    console.warn("[process] uncaughtException (suppressed):", msg.slice(0, 200));
  } else {
    // Real unexpected error — log and exit cleanly
    console.error("[process] uncaughtException (fatal):", msg);
    process.exit(1);
  }
});

import app from "./app";
import { logger } from "./lib/logger";
import { startTelegramBot } from "./telegram/bot";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  const isProduction = process.env.NODE_ENV === "production";
  const forceBotInDev = process.env.FORCE_BOT === "true";
  const productionDomain = process.env.REPLIT_DOMAINS?.split(",")[0]?.trim();
  const devDomain = process.env.REPLIT_DEV_DOMAIN;
  const externalDomain = productionDomain || devDomain;

  if (isProduction || forceBotInDev) {
    if (isProduction && productionDomain) {
      // ── Webhook mode (production): Telegram pushes updates to our HTTPS endpoint ──
      // No polling → no 409 Conflict regardless of how many times the app is redeployed
      const webhookUrl = `https://${productionDomain}/api/telegram/bot-hook`;
      const telegramBot = startTelegramBot(webhookUrl);

      if (telegramBot) {
        // Register Express route to receive Telegram webhook POSTs
        app.post("/api/telegram/bot-hook", (req: any, res: any) => {
          try {
            telegramBot.processUpdate(req.body);
          } catch (e) {
            console.warn("[TelegramBot] processUpdate error:", (e as any)?.message);
          }
          res.sendStatus(200);
        });
        console.log("[bot] started in production WEBHOOK mode");
      }
    } else {
      // ── Polling mode (development with FORCE_BOT=true) ──
      startTelegramBot();
      console.log("[bot] started in dev-forced POLLING mode");
    }
  } else {
    console.log("[bot] skipped in development mode (set FORCE_BOT=true to override)");
  }

  // Keep-alive ping to prevent Replit autoscale from sleeping
  const PING_INTERVAL = 4 * 60 * 1000; // every 4 minutes
  const pingUrl = externalDomain
    ? `https://${externalDomain}/api/healthz`
    : `http://localhost:${port}/api/healthz`;
  console.log(`[keep-alive] will ping: ${pingUrl} every ${PING_INTERVAL/1000}s`);
  setTimeout(() => {
    const doPing = () =>
      fetch(pingUrl, { signal: AbortSignal.timeout(8000) })
        .then(r => logger.debug({ status: r.status }, "[keep-alive] ping ok"))
        .catch(e => logger.warn({ msg: e.message }, "[keep-alive] ping failed"));
    doPing();
    setInterval(doPing, PING_INTERVAL);
  }, 30_000);
});
