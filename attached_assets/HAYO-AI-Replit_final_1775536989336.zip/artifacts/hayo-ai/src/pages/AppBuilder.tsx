/**
 * HAYO AI — App Builder (APK Generator)
 * الوكيل الذكي يكتب كود React Native ثم يبنيه APK عبر HAYO APK Factory
 */
import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { toast } from "sonner";
import {
  Smartphone, Sparkles, Loader2, Download, ExternalLink, CheckCircle2,
  AlertCircle, Clock, ChevronRight, Code2, Zap, Play, History,
  RefreshCw, Home, Eye, Package, Brain, Cpu, RotateCcw, X, ImageIcon, Upload, Rocket,
} from "lucide-react";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import { useTranslation } from "react-i18next";

const HAYO_LOGO = import.meta.env.VITE_APP_LOGO || "";
const BASE = import.meta.env.BASE_URL || "/";

// ─── Types ─────────────────────────────────────────────────────
type Step = "describe" | "generating" | "review" | "building" | "done" | "error";
type AIModel = "claude" | "deepseek";

interface BuildRecord {
  id: number;
  appName: string;
  status: string;
  downloadUrl?: string | null;
  buildLogsUrl?: string | null;
  errorMessage?: string | null;
  createdAt: string;
}

// ─── Status helpers ────────────────────────────────────────────
function statusLabel(status: string) {
  const map: Record<string, { label: string; color: string; icon: any }> = {
    pending:    { label: "في الانتظار",   color: "text-yellow-400",  icon: Clock },
    submitting: { label: "جاري الإرسال",  color: "text-blue-400",   icon: Loader2 },
    building:   { label: "جاري البناء",   color: "text-indigo-400", icon: Cpu },
    in_progress:{ label: "جاري البناء",   color: "text-indigo-400", icon: Cpu },
    queued:     { label: "في الانتظار",   color: "text-yellow-400",  icon: Clock },
    finished:   { label: "اكتمل ✅",       color: "text-emerald-400", icon: CheckCircle2 },
    errored:    { label: "فشل البناء",    color: "text-red-400",    icon: AlertCircle },
    cancelled:  { label: "ملغي",          color: "text-muted-foreground", icon: X },
  };
  return map[status] || { label: status, color: "text-muted-foreground", icon: Clock };
}

// ─── AI Model options ───────────────────────────────────────────
const AI_MODELS: { id: AIModel; name: string; icon: string; badge?: string }[] = [
  { id: "claude",   name: "Claude Opus (Anthropic)", icon: "🧠", badge: "الأقوى" },
  { id: "deepseek", name: "DeepSeek Coder",           icon: "⚡", badge: "سريع" },
];

// ─── Example apps ───────────────────────────────────────────────
const EXAMPLES = [
  { name: "آلة حاسبة", desc: "آلة حاسبة جميلة بعمليات أساسية وعلمية" },
  { name: "قائمة مهام", desc: "تطبيق مهام بإمكانية الإضافة والحذف والتحديد مع حفظ محلي" },
  { name: "ساعة توقف", desc: "ساعة توقف مع إشارات مرجعية وعداد تنازلي" },
  { name: "مفكرة", desc: "تطبيق ملاحظات بحفظ محلي وبحث سريع وتصنيفات" },
  { name: "تطبيق طقس", desc: "تطبيق يجلب بيانات الطقس من الإنترنت حسب الموقع GPS مع توقعات 5 أيام" },
  { name: "تطبيق أخبار", desc: "تطبيق يجلب آخر الأخبار من API خارجي مع تصنيفات ومشاركة" },
  { name: "ماسح QR", desc: "تطبيق ماسح QR Code باستخدام الكاميرا مع حفظ السجل" },
  { name: "مدير كلمات المرور", desc: "تطبيق آمن لحفظ كلمات المرور مشفرة محلياً مع توليد تلقائي" },
  { name: "تتبع المصروفات", desc: "تطبيق تتبع المصروفات والدخل مع رسوم بيانية وتصنيفات" },
  { name: "دليل الأرقام", desc: "تطبيق مثل Truecaller — بحث عن أرقام من قاعدة بيانات مدمجة مع إظهار هوية المتصل" },
];

// ─── Main Component ─────────────────────────────────────────────
export default function AppBuilder() {
  const { t } = useTranslation();
  const { isAuthenticated, loading: authLoading } = useAuth();

  const [step, setStep] = useState<Step>("describe");
  const [appName, setAppName] = useState("");
  const [description, setDescription] = useState("");
  const [iconUrl, setIconUrl] = useState("");
  const [iconPreview, setIconPreview] = useState("");
  const [iconError, setIconError] = useState("");
  const [selectedModel, setSelectedModel] = useState<AIModel>("claude");
  const [generatedCode, setGeneratedCode] = useState("");
  const [currentBuildId, setCurrentBuildId] = useState<number | null>(null);
  const [buildData, setBuildData] = useState<any>(null);
  const [showCode, setShowCode] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // Tab mode: create from scratch, advanced, upload existing project, or desktop
  type BuildMode = "create" | "advanced" | "upload" | "desktop";
  const [buildMode, setBuildMode] = useState<BuildMode>("create");

  // Upload project state
  const [uploadFiles, setUploadFiles] = useState<Array<{ name: string; content: string }>>([]);
  const [uploadName, setUploadName] = useState("");
  const [isExtracting, setIsExtracting] = useState(false);
  const uploadRef = useRef<HTMLInputElement>(null);

  // Desktop state
  const [desktopCode, setDesktopCode] = useState("");

  // Advanced mode state
  const [dataFiles, setDataFiles] = useState<Array<{ filename: string; content: string; preview: string }>>([]);
  const [apiEndpoints, setApiEndpoints] = useState<string[]>([]);
  const [newApiUrl, setNewApiUrl] = useState("");
  const [supabaseUrl, setSupabaseUrl] = useState("");
  const [supabaseKey, setSupabaseKey] = useState("");
  const [selectedFeatures, setSelectedFeatures] = useState<string[]>([]);
  const [keystoreBase64, setKeystoreBase64] = useState("");
  const dataFileRef = useRef<HTMLInputElement>(null);
  const keystoreRef = useRef<HTMLInputElement>(null);

  const utils = trpc.useUtils();

  // Queries & Mutations
  const { data: builds, refetch: refetchBuilds } = trpc.builds.list.useQuery(
    undefined, { enabled: isAuthenticated }
  );

  const generateMutation = trpc.builds.generateCode.useMutation({
    onSuccess: (data: any) => {
      setGeneratedCode(data.code);
      setStep("review");
    },
    onError: (err: any) => {
      toast.error(`فشل توليد الكود: ${err.message}`);
      setStep("describe");
    },
  });

  // Desktop code generation
  const desktopGenMut = trpc.builds.generateDesktopCode.useMutation({
    onSuccess: (data: any) => {
      setDesktopCode(data.code);
      setStep("review");
      toast.success("✅ تم توليد كود تطبيق Desktop");
    },
    onError: (err: any) => {
      toast.error(`فشل توليد كود Desktop: ${err.message}`);
      setStep("describe");
    },
  });

  // Advanced app code generation
  const advancedGenMut = trpc.builds.generateAdvancedCode.useMutation({
    onSuccess: (data: any) => {
      setGeneratedCode(data.code);
      setStep("review");
      toast.success("✅ تم توليد كود التطبيق المتقدم");
    },
    onError: (err: any) => {
      toast.error(`فشل: ${err.message}`);
      setStep("describe");
    },
  });

  // Upload project build
  const uploadBuildMut = trpc.builds.createFromUpload.useMutation({
    onSuccess: (data: any) => {
      setCurrentBuildId(data.buildId);
      setStep("building");
      refetchBuilds();
      startPolling(data.buildId);
      toast.success("🚀 بدأ بناء المشروع المرفوع");
    },
    onError: (err: any) => {
      toast.error(`فشل: ${err.message}`);
      setStep("describe");
    },
  });

  // AI code review
  const reviewMut = trpc.builds.reviewCode.useMutation({
    onSuccess: (data: any) => {
      if (buildMode === "desktop") {
        setDesktopCode(data.fixedCode);
      } else {
        setGeneratedCode(data.fixedCode);
      }
      if (data.issues?.length > 0) {
        toast.success(`🔧 AI أصلح ${data.issues.length} مشكلة`);
      } else {
        toast.success("✅ الكود سليم");
      }
    },
    onError: (err: any) => toast.error(`فشل الفحص: ${err.message}`),
  });

  const createMutation = trpc.builds.create.useMutation({
    onSuccess: (data: any) => {
      setCurrentBuildId(data.buildId);
      setStep("building");
      refetchBuilds();
      startPolling(data.buildId);
    },
    onError: (err: any) => {
      // Parse Zod validation errors into human-readable Arabic messages
      let msg = err.message || "خطأ غير معروف";
      if (msg.includes("max") || msg.includes("too_big")) {
        msg = "الوصف طويل جداً — الحد الأقصى 1000 حرف";
      } else if (msg.includes("url") || msg.includes("Invalid url")) {
        msg = "رابط الأيقونة غير صحيح — يجب أن يبدأ بـ https://";
      } else if (msg.includes("min") || msg.includes("too_small")) {
        msg = "أحد الحقول قصير جداً — تأكد من ملء جميع البيانات";
      }
      toast.error(`فشل بدء البناء: ${msg}`, { duration: 6000 });
      setStep("review");
    },
  });

  const syncMutation = trpc.builds.sync.useMutation({
    onSuccess: (data: any) => {
      setBuildData(data);
      if (data?.status === "finished") {
        setStep("done");
        stopPolling();
        refetchBuilds();
        toast.success("🎉 تم بناء التطبيق بنجاح! يمكنك تحميله الآن.");
      } else if (data?.status === "errored") {
        setStep("error");
        stopPolling();
        refetchBuilds();
        toast.error("فشل بناء التطبيق");
      }
    },
  });

  function startPolling(buildId: number) {
    stopPolling();
    // Poll every 10s for faster "build finished" detection
    pollRef.current = setInterval(() => {
      syncMutation.mutate({ buildId });
    }, 10_000);
  }

  function stopPolling() {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
  }

  useEffect(() => () => stopPolling(), []);

  // Resume polling if we reload with an active build
  useEffect(() => {
    if (currentBuildId && step === "building") {
      startPolling(currentBuildId);
    }
  }, []);

  const handleGenerate = () => {
    if (!appName.trim()) { toast.error("أدخل اسم التطبيق"); return; }
    if (!description.trim() || description.length < 10) { toast.error("الوصف قصير جداً (10 أحرف على الأقل)"); return; }
    if (description.length > 3000) { toast.error("الوصف طويل جداً — الحد الأقصى 3000 حرف"); return; }
    setStep("generating");
    generateMutation.mutate({ appName: appName.trim(), description: description.trim(), model: selectedModel });
  };

  const handleBuild = () => {
    if (!generatedCode) return;
    if (createMutation.isPending) return;
    // Validate iconUrl if provided
    const cleanIconUrl = iconUrl.trim();
    if (cleanIconUrl) {
      try {
        const parsed = new URL(cleanIconUrl);
        if (!["http:", "https:"].includes(parsed.protocol)) {
          toast.error("رابط الأيقونة يجب أن يبدأ بـ https://");
          return;
        }
      } catch {
        toast.error("رابط الأيقونة غير صحيح — تأكد أنه يبدأ بـ https://");
        return;
      }
    }
    createMutation.mutate({
      appName: appName.trim(),
      description: description.trim().slice(0, 3000),
      generatedCode,
      iconUrl: cleanIconUrl || undefined,
    });
  };

  const handleReset = () => {
    stopPolling();
    setStep("describe");
    setGeneratedCode("");
    setDesktopCode("");
    setCurrentBuildId(null);
    setBuildData(null);
    setShowCode(false);
    setIconUrl("");
    setIconPreview("");
    setIconError("");
    setUploadFiles([]);
    setUploadName("");
    setDataFiles([]);
    setApiEndpoints([]);
    setNewApiUrl("");
    setSupabaseUrl("");
    setSupabaseKey("");
    setSelectedFeatures([]);
    setKeystoreBase64("");
  };

  // Handle data file upload (CSV/JSON)
  const handleDataFile = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      const preview = content.substring(0, 300);
      setDataFiles(prev => [...prev, { filename: file.name, content, preview }]);
      toast.success(`📊 ${file.name} — ${(content.length / 1024).toFixed(1)}KB`);
    };
    reader.readAsText(file);
  };

  // Handle keystore upload
  const handleKeystoreUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const arrayBuf = e.target?.result as ArrayBuffer;
      const base64 = btoa(String.fromCharCode(...new Uint8Array(arrayBuf)));
      setKeystoreBase64(base64);
      toast.success("🔑 تم تحميل ملف التوقيع");
    };
    reader.readAsArrayBuffer(file);
  };

  // Toggle feature
  const toggleFeature = (f: string) => {
    setSelectedFeatures(prev => prev.includes(f) ? prev.filter(x => x !== f) : [...prev, f]);
  };

  // Handle advanced build (one-click)
  const handleAdvancedBuild = () => {
    if (!appName.trim()) { toast.error("أدخل اسم التطبيق"); return; }
    if (!description.trim() || description.length < 10) { toast.error("الوصف قصير"); return; }
    setStep("generating");
    advancedGenMut.mutate(
      {
        appName: appName.trim(),
        description: description.trim(),
        model: selectedModel,
        dataFiles: dataFiles.map(d => ({ filename: d.filename, preview: d.preview })),
        apiEndpoints: apiEndpoints.length > 0 ? apiEndpoints : undefined,
        useSupabase: !!supabaseUrl,
        features: selectedFeatures.length > 0 ? selectedFeatures : undefined,
      },
      {
        onSuccess: (data: any) => {
          setGeneratedCode(data.code);
          toast.success("✅ تم التوليد — بدء البناء التلقائي...");
          createMutation.mutate({
            appName: appName.trim(),
            description: description.trim().slice(0, 3000),
            generatedCode: data.code,
            iconUrl: iconUrl.trim() || undefined,
            embeddedData: dataFiles.map(d => ({ filename: d.filename, content: d.content })),
            supabaseUrl: supabaseUrl || undefined,
            supabaseKey: supabaseKey || undefined,
            customKeystoreBase64: keystoreBase64 || undefined,
          });
        },
      }
    );
  };

  // Handle ZIP upload and extract
  const handleUploadFile = async (file: File) => {
    if (!file) return;
    setIsExtracting(true);
    try {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/files/extract-archive", { method: "POST", body: fd, credentials: "include" });
      const data = await res.json();
      if (!res.ok) { toast.error(data.error || "فشل الاستخراج"); return; }
      setUploadFiles(data.files);
      if (!uploadName) {
        // Try to get name from package.json
        const pkg = data.files.find((f: any) => f.name === "package.json");
        if (pkg) {
          try { setUploadName(JSON.parse(pkg.content).name || file.name.replace(/\.\w+$/, "")); } catch { setUploadName(file.name.replace(/\.\w+$/, "")); }
        } else {
          setUploadName(file.name.replace(/\.\w+$/, ""));
        }
      }
      toast.success(`✅ ${data.files.length} ملف مستخرج`);
    } catch (e: any) { toast.error(e.message); }
    finally { setIsExtracting(false); }
  };

  const handleUploadBuild = () => {
    if (!uploadFiles.length) { toast.error("ارفع ملفات المشروع أولاً"); return; }
    if (!uploadName.trim()) { toast.error("أدخل اسم التطبيق"); return; }
    setStep("building");
    uploadBuildMut.mutate({
      appName: uploadName.trim(),
      files: uploadFiles,
      iconUrl: iconUrl.trim() || undefined,
    });
  };

  // ─── Guard ───────────────────────────────────────────────────
  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="text-center space-y-4 max-w-sm">
          <Smartphone className="w-16 h-16 text-primary/40 mx-auto" />
          <h2 className="text-xl font-bold">{t("appBuilder.loginRequired")}</h2>
          <p className="text-muted-foreground text-sm">{t("appBuilder.loginDesc")}</p>
          <Link href={getLoginUrl()}>
            <Button className="w-full">{t("common.login")}</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background text-foreground" dir="rtl">
      {/* Header */}
      <header className="border-b border-border/50 bg-background/80 backdrop-blur-sm sticky top-0 z-30">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link href="/">
              <button className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors">
                <Home className="w-4 h-4" />
              </button>
            </Link>
            <div className="flex items-center gap-2">
              <img src={`${BASE}logo.png`} alt="HAYO" className="w-7 h-7 rounded-lg" onError={e => { (e.target as HTMLImageElement).style.display = "none"; }} />
              <span className="font-heading font-bold text-sm">{t("appBuilder.title")}</span>
            </div>
            <span className="hidden sm:flex items-center gap-1 text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 font-medium border border-emerald-500/20">
              <Zap className="w-3 h-3" /> HAYO APK Factory
            </span>
          </div>
          <LanguageSwitcher />
        </div>
      </header>

      <div className="max-w-5xl mx-auto px-4 py-8 space-y-8">

        {/* Hero */}
        <div className="text-center space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-xs font-medium text-primary">
            <Smartphone className="w-3.5 h-3.5" />
            {t("appBuilder.tagline")}
          </div>
          <h1 className="text-3xl sm:text-4xl font-heading font-black">
            {t("appBuilder.heroTitle")}
          </h1>
          <p className="text-muted-foreground max-w-lg mx-auto text-sm leading-relaxed">
            {t("appBuilder.heroDesc")}
          </p>
        </div>

        {/* Build Mode Tabs */}
        {step === "describe" && (
          <div className="flex gap-2 justify-center flex-wrap">
            {([
              { id: "create" as BuildMode, label: "إنشاء تطبيق", icon: "✨", desc: "AI يكتب الكود" },
              { id: "advanced" as BuildMode, label: "تطبيق متقدم", icon: "🚀", desc: "بيانات + APIs" },
              { id: "upload" as BuildMode, label: "رفع مشروع", icon: "📤", desc: "رفع ZIP جاهز" },
              { id: "desktop" as BuildMode, label: "تطبيق Desktop", icon: "🖥️", desc: "EXE / DMG" },
            ]).map(m => (
              <button key={m.id} onClick={() => setBuildMode(m.id)}
                className={`flex flex-col items-center gap-1 px-5 py-3 rounded-xl border text-sm font-medium transition-all ${
                  buildMode === m.id ? "bg-primary/15 border-primary text-primary" : "bg-card border-border text-muted-foreground hover:text-foreground hover:border-primary/30"
                }`}>
                <span className="text-xl">{m.icon}</span>
                <span>{m.label}</span>
                <span className="text-[10px] opacity-60">{m.desc}</span>
              </button>
            ))}
          </div>
        )}

        {/* Steps indicator */}
        <div className="flex items-center justify-center gap-2 text-xs">
          {[
            { key: "describe", label: t("appBuilder.stepDescribe") },
            { key: "generating", label: t("appBuilder.stepGenerating") },
            { key: "review", label: t("appBuilder.stepReview") },
            { key: "building", label: t("appBuilder.stepBuilding") },
            { key: "done", label: t("appBuilder.stepDone") },
          ].map((s, i) => {
            const steps = ["describe", "generating", "review", "building", "done", "error"];
            const currentIdx = steps.indexOf(step);
            const sIdx = steps.indexOf(s.key);
            const active = step === s.key || (s.key === "done" && step === "error");
            const done = currentIdx > sIdx;
            return (
              <div key={s.key} className="flex items-center gap-2">
                {i > 0 && <div className={`w-6 h-px ${done ? "bg-primary" : "bg-border"}`} />}
                <div className={`flex items-center gap-1 px-2 py-1 rounded-full transition-all ${
                  active ? "bg-primary/15 text-primary font-medium" :
                  done ? "text-primary" : "text-muted-foreground"
                }`}>
                  {done ? <CheckCircle2 className="w-3 h-3" /> : <span className="w-3 h-3 text-center text-[10px]">{i + 1}</span>}
                  <span className="hidden sm:block">{s.label}</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* ─── Step: Describe (Create Mode) ─────────────────────────────── */}
        {step === "describe" && buildMode === "create" && (
          <div className="max-w-2xl mx-auto space-y-6">
            {/* App Name */}
            <div className="space-y-2">
              <label className="text-sm font-medium">{t("appBuilder.appName")}</label>
              <input
                value={appName}
                onChange={e => setAppName(e.target.value)}
                placeholder={t("appBuilder.appNamePlaceholder")}
                maxLength={60}
                className="w-full px-4 py-3 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 placeholder:text-muted-foreground/50"
              />
            </div>

            {/* Description */}
            <div className="space-y-2">
              <label className="text-sm font-medium">{t("appBuilder.appDesc")}</label>
              <textarea
                value={description}
                onChange={e => setDescription(e.target.value.slice(0, 3000))}
                rows={6}
                maxLength={3000}
                placeholder="صِف بالتفصيل ما تريده... مثلاً: تطبيق آلة حاسبة بواجهة حديثة، يحتوي على العمليات الأساسية (جمع، طرح، ضرب، قسمة) والعمليات العلمية، مع تاريخ للعمليات السابقة."
                className="w-full px-4 py-3 bg-card border border-border rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 placeholder:text-muted-foreground/50 resize-none"
              />
              <p className={`text-xs text-left ${description.length >= 2700 ? "text-yellow-400 font-medium" : "text-muted-foreground"}`}>
                {description.length} / 3000
                {description.length >= 2700 && description.length < 3000 && " — اقترب الحد"}
                {description.length >= 3000 && " — وصلت الحد الأقصى"}
              </p>
            </div>

            {/* App Icon */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">
                <ImageIcon className="w-4 h-4 text-primary" />
                أيقونة التطبيق
                <span className="text-xs text-muted-foreground font-normal">(اختياري)</span>
              </label>
              <div className="flex items-center gap-3">
                {/* Icon preview */}
                <div className="w-16 h-16 rounded-2xl border-2 border-dashed border-border bg-secondary/30 flex items-center justify-center overflow-hidden shrink-0">
                  {iconPreview ? (
                    <img
                      src={iconPreview}
                      alt="أيقونة التطبيق"
                      className="w-full h-full object-cover rounded-2xl"
                      onError={() => { setIconPreview(""); toast.error("تعذّر تحميل الصورة — تأكد من صحة الرابط"); }}
                    />
                  ) : (
                    <Smartphone className="w-7 h-7 text-muted-foreground/40" />
                  )}
                </div>
                {/* URL input */}
                <div className="flex-1 space-y-1.5">
                  <input
                    value={iconUrl}
                    onChange={e => { setIconUrl(e.target.value); setIconError(""); }}
                    onBlur={() => {
                      const val = iconUrl.trim();
                      if (!val) { setIconError(""); return; }
                      try {
                        const parsed = new URL(val);
                        if (!["http:", "https:"].includes(parsed.protocol)) {
                          setIconError("يجب أن يبدأ الرابط بـ https://");
                          return;
                        }
                        setIconPreview(val);
                        setIconError("");
                      } catch {
                        setIconError("رابط غير صحيح — مثال: https://example.com/icon.png");
                      }
                    }}
                    placeholder="https://example.com/icon.png (1024×1024 مُفضَّل)"
                    className={`w-full px-3 py-2.5 bg-card border rounded-xl text-sm focus:outline-none focus:ring-2 placeholder:text-muted-foreground/40 font-mono text-xs ${
                      iconError ? "border-red-500 focus:ring-red-500/50" : "border-border focus:ring-primary/50"
                    }`}
                    dir="ltr"
                  />
                  {iconError ? (
                    <p className="text-[10px] text-red-400">{iconError}</p>
                  ) : (
                    <p className="text-[10px] text-muted-foreground">
                      أدخل رابط صورة PNG مربعة (1024×1024) — ستُستخدم كأيقونة التطبيق على الهاتف
                    </p>
                  )}
                </div>
                {iconUrl && (
                  <button onClick={() => { setIconUrl(""); setIconPreview(""); setIconError(""); }}
                    className="p-1.5 rounded-lg hover:bg-secondary text-muted-foreground hover:text-foreground transition-colors shrink-0">
                    <X className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>

            {/* Examples */}
            <div className="space-y-2">
              <p className="text-xs text-muted-foreground">أمثلة سريعة:</p>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {EXAMPLES.map(ex => (
                  <button key={ex.name}
                    onClick={() => { setAppName(ex.name); setDescription(ex.desc); }}
                    className="text-right px-3 py-2 bg-secondary/50 hover:bg-secondary border border-border/50 rounded-lg text-xs transition-all hover:border-primary/30 hover:text-primary">
                    {ex.name}
                  </button>
                ))}
              </div>
            </div>

            {/* AI Model */}
            <div className="space-y-2">
              <label className="text-sm font-medium">{t("appBuilder.aiModel")}</label>
              <div className="grid grid-cols-2 gap-3">
                {AI_MODELS.map(m => (
                  <button key={m.id}
                    onClick={() => setSelectedModel(m.id)}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl border text-xs font-medium transition-all ${
                      selectedModel === m.id
                        ? "border-primary bg-primary/10 text-primary"
                        : "border-border bg-card hover:border-primary/30 text-muted-foreground hover:text-foreground"
                    }`}>
                    <span className="text-xl">{m.icon}</span>
                    <div className="text-right">
                      <div className="font-bold">{m.name}</div>
                      {m.badge && (
                        <div className={`text-[9px] mt-0.5 ${selectedModel === m.id ? "text-primary/70" : "text-muted-foreground/60"}`}>
                          {m.badge}
                        </div>
                      )}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <Button onClick={handleGenerate} variant="outline" className="flex-1 py-6 text-base gap-2" disabled={buildMode !== "create"}>
                <Code2 className="w-5 h-5" />
                توليد ومراجعة
              </Button>
              <Button onClick={() => {
                if (!appName.trim()) { toast.error("أدخل اسم التطبيق"); return; }
                if (!description.trim() || description.length < 10) { toast.error("الوصف قصير"); return; }
                // One-click: generate → auto review → auto build
                setStep("generating");
                generateMutation.mutate(
                  { appName: appName.trim(), description: description.trim(), model: selectedModel },
                  {
                    onSuccess: (data: any) => {
                      setGeneratedCode(data.code);
                      // Auto-build immediately after generation
                      toast.success("✅ تم التوليد — بدء البناء التلقائي...");
                      const cleanIcon = iconUrl.trim();
                      createMutation.mutate({
                        appName: appName.trim(),
                        description: description.trim().slice(0, 3000),
                        generatedCode: data.code,
                        iconUrl: cleanIcon || undefined,
                      });
                    },
                  }
                );
              }} className="flex-1 py-6 text-base gap-2 bg-emerald-600 hover:bg-emerald-700" disabled={buildMode !== "create" || generateMutation.isPending || createMutation.isPending}>
                <Rocket className="w-5 h-5" />
                🚀 بناء تلقائي كامل
              </Button>
            </div>
          </div>
        )}

        {/* ─── Mode: Advanced App ──────────────────────────── */}
        {step === "describe" && buildMode === "advanced" && (
          <div className="max-w-2xl mx-auto space-y-6">
            {/* Basic Info */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">اسم التطبيق</label>
                <input value={appName} onChange={e => setAppName(e.target.value)} placeholder="مثال: دليل الأرقام..." className="w-full bg-secondary/50 border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium">نموذج AI</label>
                <div className="flex gap-2">
                  {AI_MODELS.map(m => (
                    <button key={m.id} onClick={() => setSelectedModel(m.id)} className={`flex-1 flex items-center gap-2 p-2.5 rounded-xl border text-xs ${selectedModel === m.id ? "border-primary bg-primary/10" : "border-border bg-card"}`}>
                      <span>{m.icon}</span><span className="font-medium">{m.name.split(" ")[0]}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">وصف التطبيق التفصيلي</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="صف بالتفصيل: ماذا يفعل التطبيق، ما الشاشات، ما الميزات، كيف يتفاعل مع البيانات..." rows={4} className="w-full bg-secondary/50 border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none" />
            </div>

            {/* Features Selection */}
            <div className="space-y-2">
              <label className="text-sm font-medium">الميزات المطلوبة</label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {[
                  { id: "camera", label: "الكاميرا", icon: "📷" },
                  { id: "location", label: "الموقع GPS", icon: "📍" },
                  { id: "notifications", label: "إشعارات", icon: "🔔" },
                  { id: "imagePicker", label: "اختيار صور", icon: "🖼️" },
                  { id: "fileSystem", label: "نظام ملفات", icon: "📁" },
                  { id: "sharing", label: "مشاركة", icon: "📤" },
                  { id: "sensors", label: "مستشعرات", icon: "📡" },
                  { id: "webBrowser", label: "متصفح ويب", icon: "🌐" },
                ].map(f => (
                  <button key={f.id} onClick={() => toggleFeature(f.id)} className={`flex items-center gap-2 p-2 rounded-lg border text-xs transition-all ${selectedFeatures.includes(f.id) ? "bg-primary/15 border-primary text-primary" : "bg-card border-border text-muted-foreground hover:border-primary/30"}`}>
                    <span>{f.icon}</span><span>{f.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Data Files */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">📊 بيانات مدمجة <span className="text-xs text-muted-foreground">(CSV / JSON)</span></label>
              <div className="border border-dashed border-border rounded-xl p-4 space-y-3">
                <button onClick={() => dataFileRef.current?.click()} className="w-full flex items-center justify-center gap-2 text-sm text-muted-foreground hover:text-foreground py-2">
                  <Upload className="w-4 h-4" /> رفع ملفات بيانات
                </button>
                <input ref={dataFileRef} type="file" accept=".csv,.json,.txt,.tsv" multiple className="hidden" onChange={e => { if (e.target.files) Array.from(e.target.files).forEach(handleDataFile); }} />
                {dataFiles.length > 0 && (
                  <div className="space-y-1.5">{dataFiles.map((d, i) => (
                    <div key={i} className="flex items-center gap-2 bg-muted/30 rounded-lg p-2 text-xs">
                      <span>📄</span><span className="font-mono flex-1 truncate">{d.filename}</span>
                      <span className="text-muted-foreground">{(d.content.length / 1024).toFixed(1)}KB</span>
                      <button onClick={() => setDataFiles(prev => prev.filter((_, j) => j !== i))} className="text-red-400"><X className="w-3 h-3" /></button>
                    </div>
                  ))}</div>
                )}
              </div>
            </div>

            {/* API Endpoints */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">🔗 APIs خارجية <span className="text-xs text-muted-foreground">(اختياري)</span></label>
              <div className="flex gap-2">
                <input value={newApiUrl} onChange={e => setNewApiUrl(e.target.value)} placeholder="https://api.example.com/data" className="flex-1 bg-secondary/50 border border-border rounded-lg px-3 py-2 text-sm font-mono text-left" dir="ltr" />
                <Button size="sm" onClick={() => { if (newApiUrl.startsWith("http")) { setApiEndpoints(prev => [...prev, newApiUrl]); setNewApiUrl(""); } else { toast.error("رابط غير صحيح"); } }}>إضافة</Button>
              </div>
              {apiEndpoints.length > 0 && (
                <div className="space-y-1">{apiEndpoints.map((url, i) => (
                  <div key={i} className="flex items-center gap-2 bg-muted/30 rounded-lg p-2 text-xs font-mono" dir="ltr">
                    <span className="text-emerald-400">🔗</span><span className="flex-1 truncate">{url}</span>
                    <button onClick={() => setApiEndpoints(prev => prev.filter((_, j) => j !== i))} className="text-red-400"><X className="w-3 h-3" /></button>
                  </div>
                ))}</div>
              )}
            </div>

            {/* Supabase */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">🗄️ Supabase (قاعدة بيانات سحابية) <span className="text-xs text-muted-foreground">(اختياري)</span></label>
              <div className="grid grid-cols-2 gap-2">
                <input value={supabaseUrl} onChange={e => setSupabaseUrl(e.target.value)} placeholder="https://xxx.supabase.co" className="bg-secondary/50 border border-border rounded-lg px-3 py-2 text-xs font-mono" dir="ltr" />
                <input value={supabaseKey} onChange={e => setSupabaseKey(e.target.value)} placeholder="anon key..." className="bg-secondary/50 border border-border rounded-lg px-3 py-2 text-xs font-mono" dir="ltr" type="password" />
              </div>
            </div>

            {/* Keystore */}
            <div className="space-y-2">
              <label className="text-sm font-medium flex items-center gap-2">🔑 توقيع مخصص <span className="text-xs text-muted-foreground">(اختياري)</span></label>
              <div className="flex gap-2 items-center">
                <Button variant="outline" size="sm" onClick={() => keystoreRef.current?.click()} className="gap-2 text-xs">
                  <Upload className="w-3 h-3" /> {keystoreBase64 ? "✅ تم التحميل" : "رفع keystore"}
                </Button>
                <input ref={keystoreRef} type="file" accept=".keystore,.jks" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleKeystoreUpload(f); }} />
                {keystoreBase64 && <button onClick={() => setKeystoreBase64("")} className="text-xs text-red-400">إزالة</button>}
                <span className="text-xs text-muted-foreground mr-auto">التطبيق يُوقّع باسمك</span>
              </div>
            </div>

            {/* Icon */}
            <div className="space-y-2">
              <label className="text-sm font-medium">🎨 أيقونة التطبيق</label>
              <input value={iconUrl} onChange={e => setIconUrl(e.target.value)} placeholder="رابط صورة PNG (اختياري)" className="w-full bg-secondary/50 border border-border rounded-lg px-3 py-2 text-sm" dir="ltr" />
            </div>

            {/* Build Button */}
            <Button onClick={handleAdvancedBuild} disabled={advancedGenMut.isPending || createMutation.isPending} className="w-full py-6 text-base gap-2 bg-gradient-to-r from-emerald-600 to-cyan-600 hover:from-emerald-500 hover:to-cyan-500">
              {advancedGenMut.isPending || createMutation.isPending ? <><Loader2 className="w-5 h-5 animate-spin" /> جاري التوليد والبناء...</> : <><Rocket className="w-5 h-5" /> 🚀 بناء تلقائي كامل</>}
            </Button>
          </div>
        )}

        {/* ─── Mode: Upload Project ────────────────────────── */}
        {step === "describe" && buildMode === "upload" && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium">اسم التطبيق</label>
              <input value={uploadName} onChange={e => setUploadName(e.target.value)} placeholder="اسم التطبيق..." className="w-full bg-secondary/50 border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </div>

            <div className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${uploadFiles.length > 0 ? "border-emerald-500/40 bg-emerald-500/5" : "border-border hover:border-primary/40"}`}
              onClick={() => uploadRef.current?.click()}>
              <input ref={uploadRef} type="file" accept=".zip,.rar" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) handleUploadFile(f); }} />
              {isExtracting ? (
                <div className="space-y-2"><Loader2 className="w-8 h-8 mx-auto animate-spin text-primary" /><p className="text-sm">جاري استخراج الملفات...</p></div>
              ) : uploadFiles.length > 0 ? (
                <div className="space-y-3">
                  <Package className="w-10 h-10 mx-auto text-emerald-400" />
                  <p className="font-semibold text-emerald-300">{uploadFiles.length} ملف مستخرج</p>
                  <div className="text-xs text-muted-foreground max-h-32 overflow-y-auto space-y-0.5 text-left" dir="ltr">
                    {uploadFiles.slice(0, 15).map((f, i) => <div key={i} className="truncate">📄 {f.name}</div>)}
                    {uploadFiles.length > 15 && <div className="text-primary">+{uploadFiles.length - 15} ملفات أخرى</div>}
                  </div>
                  <button onClick={e => { e.stopPropagation(); setUploadFiles([]); }} className="text-xs text-red-400"><X className="w-3 h-3 inline" /> إعادة اختيار</button>
                </div>
              ) : (
                <div className="space-y-2"><Upload className="w-8 h-8 mx-auto text-muted-foreground" /><p className="text-sm font-medium">اسحب ملف ZIP/RAR أو انقر</p><p className="text-xs text-muted-foreground">حجم مفتوح — يدعم React Native, Expo, أي مشروع</p></div>
              )}
            </div>

            <div className="bg-blue-500/5 border border-blue-500/20 rounded-xl p-3 text-xs text-blue-300 space-y-1">
              <p className="font-semibold">🤖 ما يحدث عند الرفع:</p>
              <p>1. AI (Claude Opus) يفحص كل الأكواد ويصلح الأخطاء تلقائياً</p>
              <p>2. يُبنى مشروع Expo متوافق مع SDK 52</p>
              <p>3. يُرسل لـ Expo EAS Cloud لبناء APK</p>
              <p>4. عند الفشل، AI يحلل الخطأ ويعيد المحاولة تلقائياً (3 محاولات)</p>
            </div>

            <Button onClick={handleUploadBuild} disabled={uploadFiles.length === 0 || !uploadName.trim() || uploadBuildMut.isPending} className="w-full py-6 text-base gap-2 bg-emerald-600 hover:bg-emerald-700">
              {uploadBuildMut.isPending ? <><Loader2 className="w-5 h-5 animate-spin" /> جاري المعالجة...</> : <><Zap className="w-5 h-5" /> فحص وبناء APK</>}
            </Button>
          </div>
        )}

        {/* ─── Mode: Desktop App ────────────────────────────── */}
        {step === "describe" && buildMode === "desktop" && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-medium">اسم التطبيق</label>
              <input value={appName} onChange={e => setAppName(e.target.value)} placeholder="اسم التطبيق Desktop..." className="w-full bg-secondary/50 border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">وصف التطبيق</label>
              <textarea value={description} onChange={e => setDescription(e.target.value)} placeholder="صف التطبيق بالتفصيل — ماذا يفعل، ما الميزات المطلوبة..." rows={5} className="w-full bg-secondary/50 border border-border rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/50 resize-none" />
            </div>

            <div className="grid grid-cols-2 gap-3">
              {AI_MODELS.map(m => (
                <button key={m.id} onClick={() => setSelectedModel(m.id)} className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${selectedModel === m.id ? "border-primary bg-primary/10" : "border-border bg-card hover:border-primary/30"}`}>
                  <span className="text-xl">{m.icon}</span>
                  <div className="text-right flex-1"><div className="text-sm font-semibold">{m.name}</div>{m.badge && <span className="text-[10px] text-primary">{m.badge}</span>}</div>
                </button>
              ))}
            </div>

            <div className="bg-violet-500/5 border border-violet-500/20 rounded-xl p-3 text-xs text-violet-300 space-y-1">
              <p className="font-semibold">🖥️ تطبيق Desktop (Electron):</p>
              <p>• يعمل على Windows (EXE), macOS (DMG), Linux (AppImage)</p>
              <p>• يدعم Node.js APIs — يقدر يقرأ ملفات، يتصل بالنظام</p>
              <p>• AI يولّد الكود → يتم تحميل مشروع Electron جاهز</p>
            </div>

            <Button onClick={() => {
              if (!appName.trim()) { toast.error("أدخل اسم التطبيق"); return; }
              if (!description.trim() || description.length < 10) { toast.error("الوصف قصير"); return; }
              setStep("generating");
              desktopGenMut.mutate({ appName: appName.trim(), description: description.trim(), model: selectedModel });
            }} disabled={desktopGenMut.isPending} className="w-full py-6 text-base gap-2 bg-violet-600 hover:bg-violet-700">
              <Brain className="w-5 h-5" /> توليد كود Desktop
            </Button>
          </div>
        )}

        {/* ─── Step: Generating ────────────────────────────── */}
        {step === "generating" && (
          <div className="max-w-md mx-auto text-center space-y-8 py-16">
            <div className="relative mx-auto w-24 h-24">
              <div className="absolute inset-0 rounded-full bg-primary/10 animate-ping" />
              <div className="relative w-24 h-24 rounded-full bg-primary/20 flex items-center justify-center">
                <Brain className="w-12 h-12 text-primary animate-pulse" />
              </div>
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-bold">{t("appBuilder.generatingTitle")}</h2>
              <p className="text-muted-foreground text-sm">{t("appBuilder.generatingDesc")}</p>
            </div>
            <div className="space-y-1 text-xs text-muted-foreground">
              {["تحليل المتطلبات...", "تصميم الواجهة...", "كتابة المنطق...", "مراجعة الكود..."].map((step_text, i) => (
                <div key={i} className="flex items-center gap-2 justify-center">
                  <Loader2 className="w-3 h-3 animate-spin text-primary" />
                  {step_text}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ─── Step: Review ───────────────────────────────── */}
        {step === "review" && (generatedCode || desktopCode) && (
          <div className="max-w-2xl mx-auto space-y-6">
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 flex items-start gap-3">
              <CheckCircle2 className="w-5 h-5 text-emerald-400 mt-0.5 shrink-0" />
              <div>
                <p className="font-bold text-sm text-emerald-400">تم توليد الكود بنجاح!</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {buildMode === "desktop" ? "كود Electron Desktop جاهز" : "كود React Native جاهز للبناء"}
                </p>
              </div>
            </div>

            {/* Code preview toggle */}
            <button
              onClick={() => setShowCode(!showCode)}
              className="w-full flex items-center justify-between px-4 py-3 bg-card border border-border rounded-xl hover:border-primary/30 transition-all">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Code2 className="w-4 h-4 text-primary" />
                {buildMode === "desktop" ? "app.js" : "App.tsx"} ({Math.round((generatedCode || desktopCode).length / 1000)}k حرف)
              </div>
              <Eye className={`w-4 h-4 text-muted-foreground transition-transform ${showCode ? "text-primary" : ""}`} />
            </button>

            {showCode && (
              <div className="bg-card border border-border rounded-xl overflow-hidden">
                <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-secondary/30">
                  <span className="text-xs text-muted-foreground font-mono">{buildMode === "desktop" ? "app.js" : "App.tsx"}</span>
                  <button onClick={() => { navigator.clipboard.writeText(generatedCode || desktopCode); toast.success("تم النسخ"); }}
                    className="text-xs text-primary hover:underline">نسخ</button>
                </div>
                <pre className="p-4 text-xs font-mono overflow-x-auto max-h-80 text-foreground/80 leading-relaxed">
                  {generatedCode || desktopCode}
                </pre>
              </div>
            )}

            {/* AI Review Button */}
            <Button variant="outline" onClick={() => reviewMut.mutate({ code: generatedCode || desktopCode })}
              disabled={reviewMut.isPending} className="w-full gap-2 border-primary/30 text-primary">
              {reviewMut.isPending ? <><Loader2 className="w-4 h-4 animate-spin" /> AI يفحص الكود...</> : <><Brain className="w-4 h-4" /> 🔍 فحص وإصلاح بالذكاء الاصطناعي</>}
            </Button>

            {/* Build info */}
            <div className="bg-card border border-border rounded-xl p-4 space-y-3">
              <h3 className="font-bold text-sm">{buildMode === "desktop" ? "ما سيحدث:" : "ما سيحدث بعد ضغط بناء APK:"}</h3>
              <div className="space-y-2">
                {buildMode === "desktop" ? [
                  { icon: "🤖", text: "AI يراجع الكود ويصلح الأخطاء" },
                  { icon: "📦", text: "يُنشأ مشروع Electron كامل" },
                  { icon: "💾", text: "تحميل المشروع كـ ZIP — شغّل npm run build" },
                ] : [
                  { icon: "🧠", text: "AI #1 (Claude Opus) يصلح الكود" },
                  { icon: "🔍", text: "AI #2 (Sonnet) يدقق ويتأكد" },
                  { icon: "📤", text: "رفع الكود إلى Expo EAS Cloud" },
                  { icon: "🔧", text: "بناء APK (~5-15 دقيقة)" },
                  { icon: "🔄", text: "عند الفشل — AI يحلل الخطأ ويعيد المحاولة (3 محاولات)" },
                  { icon: "📱", text: "APK جاهز للتثبيت" },
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm">
                    <span>{item.icon}</span>
                    <span className="text-muted-foreground">{item.text}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => setStep("describe")} className="flex-1 gap-2"
                disabled={createMutation.isPending}>
                <RotateCcw className="w-4 h-4" /> تعديل
              </Button>
              {buildMode === "desktop" ? (
                <Button onClick={() => {
                  // Download as Electron project ZIP
                  const blob = new Blob([desktopCode], { type: "application/javascript" });
                  const url = URL.createObjectURL(blob);
                  const a = document.createElement("a"); a.href = url; a.download = `${appName || "desktop-app"}-electron.js`; a.click();
                  URL.revokeObjectURL(url);
                  toast.success("✅ تم تحميل كود Desktop");
                  setStep("done");
                }} className="flex-2 flex-grow gap-2 bg-violet-600 hover:bg-violet-700">
                  <Download className="w-4 h-4" /> تحميل كود Desktop
                </Button>
              ) : (
                <Button onClick={handleBuild} className="flex-2 flex-grow gap-2 bg-emerald-600 hover:bg-emerald-700"
                  disabled={createMutation.isPending}>
                  {createMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Package className="w-4 h-4" />}
                  {createMutation.isPending ? "جاري الإرسال..." : t("appBuilder.buildApp")}
                </Button>
              )}
            </div>
          </div>
        )}

        {/* ─── Step: Building ──────────────────────────────── */}
        {step === "building" && (
          <div className="max-w-lg mx-auto text-center space-y-6 py-8">
            <div className="relative mx-auto w-28 h-28">
              <div className="absolute inset-0 rounded-full bg-indigo-500/10 animate-ping" style={{ animationDuration: "2s" }} />
              <div className="absolute inset-2 rounded-full bg-indigo-500/10 animate-ping" style={{ animationDuration: "2.5s", animationDelay: "0.3s" }} />
              <div className="relative w-28 h-28 rounded-full bg-indigo-500/20 flex items-center justify-center">
                <Cpu className="w-14 h-14 text-indigo-400" />
              </div>
            </div>

            <div className="space-y-2">
              <h2 className="text-xl font-bold">{t("appBuilder.buildingTitle")}</h2>
              <p className="text-muted-foreground text-sm">العملية تلقائية بالكامل — لا تحتاج أي تدخل</p>
            </div>

            {/* Visual Pipeline */}
            <div className="bg-card border border-border rounded-xl p-4 space-y-3 text-right">
              <div className="text-xs font-semibold text-muted-foreground mb-2">مراحل البناء التلقائي:</div>
              {[
                { icon: "🧠", label: "AI #1 (Claude Opus) يصلح الكود", status: "done" },
                { icon: "🔍", label: "AI #2 (Sonnet) يدقق ويؤكد", status: "done" },
                { icon: "📦", label: "إنشاء مشروع Expo", status: "done" },
                { icon: "📤", label: "رفع لـ Expo EAS Cloud", status: buildData?.status === "building" || buildData?.status === "in_progress" ? "done" : buildData ? "done" : "active" },
                { icon: "🔧", label: "بناء APK على السحابة", status: buildData?.status === "building" || buildData?.status === "in_progress" ? "active" : buildData?.status === "finished" ? "done" : "waiting" },
                { icon: "✅", label: "جاهز للتحميل", status: buildData?.status === "finished" ? "done" : "waiting" },
              ].map((stage, i) => (
                <div key={i} className={`flex items-center gap-3 text-sm py-1.5 ${
                  stage.status === "active" ? "text-primary" : stage.status === "done" ? "text-emerald-400" : "text-muted-foreground/40"
                }`}>
                  <span className="text-base w-6">{stage.icon}</span>
                  <span className={stage.status === "active" ? "font-semibold" : ""}>{stage.label}</span>
                  <span className="mr-auto">
                    {stage.status === "done" ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> :
                     stage.status === "active" ? <Loader2 className="w-4 h-4 animate-spin text-primary" /> :
                     <Clock className="w-4 h-4 text-muted-foreground/30" />}
                  </span>
                </div>
              ))}
              {buildData?.status === "errored" && (
                <div className="flex items-center gap-3 text-sm py-1.5 text-amber-400">
                  <span className="text-base w-6">🔄</span>
                  <span className="font-semibold">AI #1 يصلح + AI #2 يدقق ثم يعاد الإرسال...</span>
                  <Loader2 className="w-4 h-4 animate-spin mr-auto" />
                </div>
              )}
            </div>

            {buildData && (
              <div className="bg-card border border-border rounded-xl p-4 space-y-2 text-right">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">الحالة</span>
                  <span className={statusLabel(buildData.status).color}>
                    {statusLabel(buildData.status).label}
                  </span>
                </div>
                {buildData.buildLogsUrl && (
                  <a href={buildData.buildLogsUrl} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1 text-primary hover:underline text-xs justify-end">
                    عرض السجلات <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            )}

            <div className="flex gap-3">
              <Button variant="outline" onClick={() => currentBuildId && syncMutation.mutate({ buildId: currentBuildId })}
                disabled={syncMutation.isPending} className="flex-1 gap-2">
                {syncMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
                تحديث
              </Button>
              {buildData?.buildLogsUrl && (
                <a href={buildData.buildLogsUrl} target="_blank" rel="noopener noreferrer" className="flex-1">
                  <Button variant="outline" className="w-full gap-2">
                    <ExternalLink className="w-4 h-4" /> تفاصيل
                  </Button>
                </a>
              )}
            </div>

            <p className="text-xs text-muted-foreground">تحديث تلقائي كل 10 ثوانٍ — عند الفشل AI يصلح ويعيد المحاولة تلقائياً</p>
          </div>
        )}

        {/* ─── Step: Done ──────────────────────────────────── */}
        {step === "done" && buildData && (
          <div className="max-w-3xl mx-auto space-y-6 py-8">
            {/* Header */}
            <div className="text-center space-y-2">
              <div className="relative mx-auto w-20 h-20">
                <div className="absolute inset-0 rounded-full bg-emerald-500/20 animate-ping" style={{ animationDuration: "3s" }} />
                <div className="relative w-20 h-20 rounded-full bg-emerald-500/20 flex items-center justify-center">
                  <CheckCircle2 className="w-10 h-10 text-emerald-400" />
                </div>
              </div>
              <h2 className="text-2xl font-bold">🎉 تم بناء التطبيق!</h2>
              <p className="text-muted-foreground">{buildData.appName || appName}</p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-[280px_1fr] gap-6">
              {/* Phone Preview Mockup */}
              <div className="flex flex-col items-center gap-4">
                <div className="relative w-[220px] h-[440px] bg-black rounded-[2.5rem] p-2 border-4 border-gray-700 shadow-2xl shadow-black/50">
                  {/* Notch */}
                  <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-5 bg-black rounded-b-2xl z-10" />
                  {/* Screen */}
                  <div className="w-full h-full bg-gradient-to-b from-[#1a1a2e] to-[#16213e] rounded-[2rem] overflow-hidden flex flex-col items-center justify-center text-center p-4">
                    {iconPreview ? (
                      <img src={iconPreview} alt="icon" className="w-16 h-16 rounded-2xl mb-3 shadow-lg" />
                    ) : (
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary/30 to-emerald-500/30 flex items-center justify-center mb-3 text-3xl">📱</div>
                    )}
                    <p className="text-white font-bold text-sm">{buildData.appName || appName}</p>
                    <p className="text-white/40 text-[10px] mt-1">HAYO AI Builder</p>
                    <div className="mt-4 px-3 py-1.5 bg-emerald-500/20 rounded-full text-emerald-400 text-[10px]">✅ جاهز للتثبيت</div>
                  </div>
                </div>

                {/* QR Code for download link */}
                {buildData.downloadUrl && (
                  <div className="bg-card border border-border rounded-xl p-3 text-center space-y-2">
                    <img src={`https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(buildData.downloadUrl)}`} alt="QR" className="mx-auto rounded-lg" width={120} height={120} />
                    <p className="text-[10px] text-muted-foreground">امسح للتحميل على هاتفك</p>
                  </div>
                )}
              </div>

              {/* Details + Actions */}
              <div className="space-y-4">
                {/* App Info Card */}
                <div className="bg-card border border-border rounded-xl p-4 space-y-3">
                  <h3 className="font-bold text-sm">معلومات التطبيق</h3>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="bg-muted/30 rounded-lg p-2"><span className="text-muted-foreground">الاسم</span><div className="font-semibold mt-0.5">{buildData.appName || appName}</div></div>
                    <div className="bg-muted/30 rounded-lg p-2"><span className="text-muted-foreground">المنصة</span><div className="font-semibold mt-0.5">Android APK</div></div>
                    <div className="bg-muted/30 rounded-lg p-2"><span className="text-muted-foreground">الحالة</span><div className="font-semibold mt-0.5 text-emerald-400">مكتمل ✅</div></div>
                    <div className="bg-muted/30 rounded-lg p-2"><span className="text-muted-foreground">التاريخ</span><div className="font-semibold mt-0.5">{new Date().toLocaleDateString("ar-SA")}</div></div>
                  </div>
                  {keystoreBase64 && <div className="text-xs text-emerald-400 flex items-center gap-1.5"><CheckCircle2 className="w-3 h-3" /> موقّع بشهادتك الخاصة</div>}
                  {supabaseUrl && <div className="text-xs text-blue-400 flex items-center gap-1.5"><CheckCircle2 className="w-3 h-3" /> متصل بـ Supabase</div>}
                  {dataFiles.length > 0 && <div className="text-xs text-violet-400 flex items-center gap-1.5"><CheckCircle2 className="w-3 h-3" /> {dataFiles.length} ملف بيانات مدمج</div>}
                </div>

                {/* Download */}
                <div className="bg-card border border-emerald-500/40 rounded-xl p-4 space-y-3">
                  {buildData.downloadUrl ? (
                    <>
                      <a href={buildData.downloadUrl} rel="noopener noreferrer">
                        <Button className="w-full py-5 text-lg gap-3 bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-lg shadow-emerald-900/30">
                          <Download className="w-6 h-6" /> تحميل APK
                        </Button>
                      </a>
                      <div className="flex gap-2">
                        <button onClick={() => { navigator.clipboard.writeText(buildData.downloadUrl!); toast.success("تم نسخ الرابط ✅"); }} className="flex-1 text-xs text-muted-foreground hover:text-foreground flex items-center justify-center gap-1.5 py-2 bg-muted/30 rounded-lg">
                          <ExternalLink className="w-3 h-3" /> نسخ الرابط
                        </button>
                        {buildData.buildLogsUrl && (
                          <a href={buildData.buildLogsUrl} target="_blank" rel="noopener noreferrer" className="flex-1">
                            <button className="w-full text-xs text-muted-foreground hover:text-foreground flex items-center justify-center gap-1.5 py-2 bg-muted/30 rounded-lg">
                              <Eye className="w-3 h-3" /> سجلات البناء
                            </button>
                          </a>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="space-y-3 text-center">
                      <p className="text-sm text-amber-400">جاري تحضير الرابط...</p>
                      <Button variant="ghost" size="sm" className="gap-2" onClick={() => currentBuildId && syncMutation.mutate({ buildId: currentBuildId })}>
                        <RefreshCw className={`w-3 h-3 ${syncMutation.isPending ? "animate-spin" : ""}`} /> تحديث
                      </Button>
                    </div>
                  )}
                </div>

                {/* Install Guide */}
                <div className="bg-muted/20 rounded-xl p-3 text-xs text-right space-y-1.5 text-muted-foreground">
                  <p className="font-semibold text-foreground">📱 تثبيت APK:</p>
                  <p>① حمّل الملف ② افتحه من الإشعارات ③ فعّل "مصادر غير معروفة" إذا طُلب ④ أكمل التثبيت 🎊</p>
                </div>

                <Button variant="outline" onClick={handleReset} className="w-full gap-2">
                  <Sparkles className="w-4 h-4" /> بناء تطبيق جديد
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* ─── Step: Error ─────────────────────────────────── */}
        {step === "error" && (
          <div className="max-w-md mx-auto text-center space-y-6 py-8">
            <div className="w-24 h-24 mx-auto rounded-full bg-red-500/20 flex items-center justify-center">
              <AlertCircle className="w-12 h-12 text-red-400" />
            </div>
            <div className="space-y-2">
              <h2 className="text-xl font-bold">{t("appBuilder.errorTitle")}</h2>
              {buildData?.errorMessage && (
                <p className="text-xs text-red-400 bg-red-500/10 border border-red-500/20 rounded-lg p-3 text-right font-mono">
                  {buildData.errorMessage}
                </p>
              )}
            </div>
            {buildData?.buildLogsUrl && (
              <a href={buildData.buildLogsUrl} target="_blank" rel="noopener noreferrer">
                <Button variant="outline" className="gap-2">
                  <ExternalLink className="w-4 h-4" />
                  عرض سجلات الخطأ
                </Button>
              </a>
            )}
            {/* AI Debug — analyze error and fix */}
            {generatedCode && (
              <Button variant="outline" className="w-full gap-2 border-primary/30 text-primary"
                onClick={() => reviewMut.mutate({ code: generatedCode, errorLog: buildData?.errorMessage || "" })}
                disabled={reviewMut.isPending}>
                {reviewMut.isPending ? <><Loader2 className="w-4 h-4 animate-spin" /> AI يحلل الخطأ...</> : <><Brain className="w-4 h-4" /> 🔧 AI Debug — تحليل وإصلاح تلقائي</>}
              </Button>
            )}
            {reviewMut.isSuccess && (
              <Button onClick={() => { setStep("review"); toast.success("✅ تم الإصلاح — راجع الكود وأعد البناء"); }} className="w-full gap-2 bg-emerald-600">
                <Eye className="w-4 h-4" /> مراجعة الكود المُصلح
              </Button>
            )}
            <Button onClick={handleReset} className="w-full gap-2">
              <RotateCcw className="w-4 h-4" />
              المحاولة مجدداً
            </Button>
          </div>
        )}

        {/* ─── Build History ───────────────────────────────── */}
        {builds && (builds as BuildRecord[]).length > 0 && step === "describe" && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-sm font-bold">
              <History className="w-4 h-4 text-primary" />
              {t("appBuilder.history")}
            </div>
            <div className="space-y-2">
              {(builds as BuildRecord[]).map(build => {
                const s = statusLabel(build.status);
                const StatusIcon = s.icon;
                return (
                  <div key={build.id}
                    className="bg-card border border-border rounded-xl p-4 flex items-center justify-between hover:border-primary/20 transition-all">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-secondary/50 flex items-center justify-center">
                        <Smartphone className="w-5 h-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-medium text-sm">{build.appName}</p>
                        <p className="text-xs text-muted-foreground">
                          {new Date(build.createdAt).toLocaleDateString("ar-SA")}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className={`flex items-center gap-1 text-xs font-medium ${s.color}`}>
                        <StatusIcon className={`w-3 h-3 ${build.status === "building" || build.status === "in_progress" || build.status === "submitting" ? "animate-spin" : ""}`} />
                        {s.label}
                      </span>
                      {build.downloadUrl && (
                        <a href={build.downloadUrl} target="_blank" rel="noopener noreferrer">
                          <Button size="sm" className="text-xs gap-1 bg-emerald-600 hover:bg-emerald-700 h-7 px-2">
                            <Download className="w-3 h-3" /> تحميل
                          </Button>
                        </a>
                      )}
                      {/* Sync button for in-progress builds in history */}
                      {!build.downloadUrl && (build.status === "building" || build.status === "in_progress" || build.status === "submitting") && (
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-xs gap-1 h-7 px-2"
                          onClick={async () => {
                            const updated = await syncMutation.mutateAsync({ buildId: build.id });
                            if (updated && (updated as BuildRecord).downloadUrl) {
                              toast.success("✅ تم تحديث البناء — رابط التحميل جاهز!", { duration: 5000 });
                              refetchBuilds();
                            }
                          }}
                          disabled={syncMutation.isPending}
                        >
                          <RefreshCw className={`w-3 h-3 ${syncMutation.isPending ? "animate-spin" : ""}`} />
                          تحديث
                        </Button>
                      )}
                      {build.buildLogsUrl && !build.downloadUrl && build.status !== "building" && build.status !== "in_progress" && build.status !== "submitting" && (
                        <a href={build.buildLogsUrl} target="_blank" rel="noopener noreferrer">
                          <Button size="sm" variant="outline" className="text-xs gap-1 h-7 px-2">
                            <ExternalLink className="w-3 h-3" /> تفاصيل
                          </Button>
                        </a>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
