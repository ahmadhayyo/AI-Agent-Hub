/**
 * HAYO AI — System Maintenance & Security Dashboard
 * Admin-only: health check, AI diagnosis, code repair, security status
 */
import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { toast } from "sonner";
import {
  Shield, Activity, AlertTriangle, CheckCircle2, XCircle, Loader2,
  Home, RefreshCw, FileCode, Brain, Wrench, Search, Copy,
  Database, Cpu, HardDrive, Eye, ChevronDown, ChevronUp, Zap,
} from "lucide-react";
import { useTranslation } from "react-i18next";
import LanguageSwitcher from "@/components/LanguageSwitcher";

type Tab = "health" | "scan" | "diagnose" | "fix";

export default function SystemMaintenance() {
  const { user, isAuthenticated, loading } = useAuth();
  const [tab, setTab] = useState<Tab>("health");

  // Health
  const healthQ = trpc.maintenance.healthCheck.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });
  // Project structure
  const structureQ = trpc.maintenance.projectStructure.useQuery(undefined, { enabled: isAuthenticated && user?.role === "admin" });

  // Quick scan
  const [scanResult, setScanResult] = useState<any>(null);
  const scanMut = trpc.maintenance.quickScan.useMutation({
    onSuccess: (data) => { setScanResult(data); toast.success(`فحص سريع: ${data.score}/100`); },
    onError: (e) => toast.error(e.message),
  });

  // AI Diagnose
  const [diagScope, setDiagScope] = useState<"all" | "frontend" | "backend" | "routes" | "services">("all");
  const [diagNote, setDiagNote] = useState("");
  const [diagResult, setDiagResult] = useState<any>(null);
  const diagMut = trpc.maintenance.aiDiagnose.useMutation({
    onSuccess: (data) => { setDiagResult(data); toast.success("تم التشخيص!"); },
    onError: (e) => toast.error(e.message),
  });

  // AI Fix
  const [fixFile, setFixFile] = useState("");
  const [fixProblem, setFixProblem] = useState("");
  const [fixResult, setFixResult] = useState<any>(null);
  const [autoApply, setAutoApply] = useState(false);
  const [filePreview, setFilePreview] = useState<string | null>(null);
  const fixMut = trpc.maintenance.aiFix.useMutation({
    onSuccess: (data) => {
      setFixResult(data);
      toast.success(data.applied ? "✅ تم الإصلاح والحفظ تلقائياً!" : "✅ تم إنشاء الإصلاح — انسخ الكود");
    },
    onError: (e) => toast.error(e.message),
  });

  // Auth
  if (loading) return <div className="h-screen flex items-center justify-center bg-background"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  if (!isAuthenticated || user?.role !== "admin") return (
    <div className="h-screen flex items-center justify-center bg-background p-4">
      <div className="bg-card border border-red-500/30 rounded-2xl p-8 max-w-md text-center space-y-4">
        <Shield className="w-16 h-16 mx-auto text-red-400 opacity-60" />
        <h2 className="text-2xl font-bold">وصول المسؤول فقط</h2>
        <p className="text-muted-foreground">هذه الصفحة متاحة للمالك فقط</p>
        <Button asChild><Link href="/">العودة</Link></Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground" dir="rtl">
      {/* Header */}
      <header className="h-12 bg-card border-b border-border flex items-center justify-between px-4 sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <Link href="/" className="text-muted-foreground hover:text-primary"><Home className="w-4 h-4" /></Link>
          <div className="w-px h-5 bg-border" />
          <Shield className="w-5 h-5 text-red-400" />
          <span className="font-bold text-sm">صيانة النظام</span>
          <span className="text-[9px] bg-red-500/10 text-red-400 px-2 py-0.5 rounded-full">Admin Only</span>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6 space-y-6">
        {/* Tabs */}
        <div className="flex gap-2 flex-wrap">
          {([
            { id: "health" as Tab, label: "حالة النظام", icon: Activity },
            { id: "scan" as Tab, label: "فحص سريع", icon: Search },
            { id: "diagnose" as Tab, label: "تشخيص AI", icon: Brain },
            { id: "fix" as Tab, label: "إصلاح AI", icon: Wrench },
          ]).map(t => (
            <button key={t.id} onClick={() => setTab(t.id)} className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium transition-all ${tab === t.id ? "bg-primary/15 text-primary border border-primary/30" : "text-muted-foreground hover:bg-secondary/50 border border-transparent"}`}>
              <t.icon className="w-4 h-4" /> {t.label}
            </button>
          ))}
        </div>

        {/* ═══ Health ═══ */}
        {tab === "health" && (
          <div className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {healthQ.data ? Object.entries(healthQ.data.checks).map(([name, check]: [string, any]) => (
                <div key={name} className={`bg-card border rounded-xl p-4 ${check.ok ? "border-emerald-500/20" : "border-red-500/20"}`}>
                  <div className="flex items-center gap-2 mb-2">
                    {check.ok ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
                    <span className="text-sm font-bold capitalize">{name}</span>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    {name === "database" ? `${check.latency}ms` : name === "memory" ? `${check.latency} MB` : name === "uptime" ? `${Math.round(check.latency / 3600)}h` : check.ok ? "OK" : check.error}
                  </p>
                </div>
              )) : <div className="col-span-4 text-center text-muted-foreground text-sm py-8"><Loader2 className="w-6 h-6 animate-spin mx-auto mb-2" /> جاري الفحص...</div>}
            </div>

            {structureQ.data && (
              <div className="bg-card border border-border rounded-xl p-4 space-y-2">
                <h3 className="text-sm font-bold flex items-center gap-2"><FileCode className="w-4 h-4 text-primary" /> هيكل المشروع</h3>
                <div className="flex gap-4 text-xs text-muted-foreground">
                  <span>{structureQ.data.totalFiles} ملف</span>
                  <span>{structureQ.data.totalLines.toLocaleString()} سطر</span>
                </div>
                <details>
                  <summary className="text-xs text-primary cursor-pointer">عرض أكبر الملفات</summary>
                  <div className="mt-2 max-h-60 overflow-y-auto space-y-1">
                    {structureQ.data.files.slice(0, 30).map((f: any) => (
                      <div key={f.path} className="flex items-center justify-between text-[11px] py-1 border-b border-border/50">
                        <span className="font-mono text-muted-foreground truncate flex-1">{f.path}</span>
                        <span className="text-primary font-bold mr-2">{f.lines} سطر</span>
                      </div>
                    ))}
                  </div>
                </details>
              </div>
            )}
          </div>
        )}

        {/* ═══ Quick Scan ═══ */}
        {tab === "scan" && (
          <div className="space-y-6">
            <Button onClick={() => scanMut.mutate()} disabled={scanMut.isPending} className="w-full py-5 gap-2 bg-gradient-to-r from-blue-600 to-cyan-600">
              {scanMut.isPending ? <><Loader2 className="w-5 h-5 animate-spin" /> جاري الفحص السريع...</> : <><Search className="w-5 h-5" /> فحص سريع شامل (بدون AI)</>}
            </Button>

            {scanResult && (
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className={`w-20 h-20 rounded-2xl flex items-center justify-center text-2xl font-bold ${scanResult.score >= 80 ? "bg-emerald-500/10 text-emerald-400" : scanResult.score >= 50 ? "bg-amber-500/10 text-amber-400" : "bg-red-500/10 text-red-400"}`}>
                    {scanResult.score}%
                  </div>
                  <div>
                    <h3 className="font-bold text-lg">{scanResult.overall === "healthy" ? "النظام سليم ✅" : scanResult.overall === "warnings" ? "تحذيرات ⚠️" : "مشاكل حرجة ❌"}</h3>
                    <p className="text-sm text-muted-foreground">{scanResult.scannedFiles} ملف — {scanResult.scannedLines.toLocaleString()} سطر</p>
                  </div>
                </div>

                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {scanResult.diagnostics.filter((d: any) => d.status !== "ok").map((d: any, i: number) => (
                    <div key={i} className={`flex items-start gap-3 p-3 rounded-xl border text-xs ${d.status === "error" ? "bg-red-500/5 border-red-500/20" : "bg-amber-500/5 border-amber-500/20"}`}>
                      {d.status === "error" ? <XCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />}
                      <div>
                        <p className="font-medium">[{d.category}] {d.message}</p>
                        {d.file && <p className="text-muted-foreground mt-0.5 font-mono">{d.file}{d.line ? `:${d.line}` : ""}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ═══ AI Diagnose ═══ */}
        {tab === "diagnose" && (
          <div className="space-y-6">
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-bold flex items-center gap-2"><Brain className="w-5 h-5 text-primary" /> تشخيص بالذكاء الاصطناعي</h3>
              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">نطاق الفحص:</label>
                <div className="flex gap-2 flex-wrap">
                  {([
                    { id: "all" as const, label: "كل المشروع" },
                    { id: "frontend" as const, label: "الواجهة (Pages)" },
                    { id: "backend" as const, label: "الخلفية (Router)" },
                    { id: "routes" as const, label: "المسارات (Routes)" },
                    { id: "services" as const, label: "الخدمات (Services)" },
                  ]).map(s => (
                    <button key={s.id} onClick={() => setDiagScope(s.id)} className={`px-3 py-1.5 rounded-lg text-xs border ${diagScope === s.id ? "bg-primary/15 border-primary text-primary" : "border-border text-muted-foreground"}`}>{s.label}</button>
                  ))}
                </div>
              </div>
              <textarea value={diagNote} onChange={e => setDiagNote(e.target.value)} rows={3} placeholder="ملاحظات إضافية: وصف المشكلة أو الصفحة المحددة... (اختياري)" className="w-full bg-secondary/50 border border-border rounded-xl px-4 py-3 text-sm resize-none" />
              <Button onClick={() => diagMut.mutate({ scope: diagScope, userNote: diagNote || undefined })} disabled={diagMut.isPending} className="w-full py-5 gap-2 bg-gradient-to-r from-violet-600 to-purple-600">
                {diagMut.isPending ? <><Loader2 className="w-5 h-5 animate-spin" /> AI يشخّص (Opus + Sonnet)...</> : <><Brain className="w-5 h-5" /> تشخيص شامل بـ AI</>}
              </Button>
            </div>

            {diagResult && (
              <div className="space-y-4">
                <div className="bg-card border border-border rounded-xl p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-sm">📋 تقرير التشخيص</h3>
                    <button onClick={() => { navigator.clipboard.writeText(diagResult.report); toast.success("تم النسخ"); }} className="text-xs text-primary"><Copy className="w-3 h-3 inline mr-1" />نسخ</button>
                  </div>
                  <div className="text-sm text-muted-foreground whitespace-pre-wrap leading-relaxed max-h-60 overflow-y-auto">{diagResult.report}</div>
                </div>

                {diagResult.fixes?.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="font-bold text-sm">🔧 الإصلاحات المقترحة ({diagResult.fixes.length}):</h3>
                    {diagResult.fixes.map((fix: any, i: number) => (
                      <div key={i} className="bg-card border border-border rounded-xl p-4 space-y-2">
                        <p className="text-sm font-bold font-mono text-primary">{fix.file}</p>
                        <p className="text-xs text-muted-foreground">{fix.description}</p>
                        {fix.code && (
                          <pre className="bg-black/20 rounded-lg p-3 text-xs font-mono overflow-x-auto max-h-40 text-foreground/80" dir="ltr">{fix.code}</pre>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        )}

        {/* ═══ AI Fix ═══ */}
        {tab === "fix" && (
          <div className="space-y-6">
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <h3 className="font-bold flex items-center gap-2"><Wrench className="w-5 h-5 text-amber-400" /> إصلاح فوري بـ AI</h3>

              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">الملف المطلوب إصلاحه:</label>
                {structureQ.data ? (
                  <select value={fixFile} onChange={e => setFixFile(e.target.value)} className="w-full bg-secondary/50 border border-border rounded-lg px-3 py-2 text-sm font-mono" dir="ltr">
                    <option value="">اختر ملف...</option>
                    {structureQ.data.files.map((f: any) => (
                      <option key={f.path} value={f.path}>{f.path} ({f.lines} سطر)</option>
                    ))}
                  </select>
                ) : (
                  <input value={fixFile} onChange={e => setFixFile(e.target.value)} placeholder="src/pages/Chat.tsx" className="w-full bg-secondary/50 border border-border rounded-lg px-3 py-2 text-sm font-mono" dir="ltr" />
                )}
              </div>

              <div className="space-y-2">
                <label className="text-sm text-muted-foreground">وصف المشكلة:</label>
                <textarea value={fixProblem} onChange={e => setFixProblem(e.target.value)} rows={4} placeholder="مثال: زر الإرسال لا يعمل... الصفحة تعرض خطأ 500... البيانات لا تتحدث... TypeError عند الضغط على..." className="w-full bg-secondary/50 border border-border rounded-xl px-4 py-3 text-sm resize-none" />
              </div>

              <Button onClick={() => fixMut.mutate({ filePath: fixFile, problem: fixProblem, autoApply })} disabled={fixMut.isPending || !fixFile || !fixProblem.trim()} className="w-full py-5 gap-2 bg-gradient-to-r from-amber-600 to-red-600">
                {fixMut.isPending ? <><Loader2 className="w-5 h-5 animate-spin" /> AI يصلح الكود (Opus + Sonnet)...</> : <><Wrench className="w-5 h-5" /> إصلاح فوري بـ AI</>}
              </Button>

              {/* Auto-apply toggle */}
              <div className="flex items-center justify-between bg-secondary/30 rounded-xl p-3 border border-border">
                <div>
                  <p className="text-sm font-medium">حفظ تلقائي بعد الإصلاح</p>
                  <p className="text-[10px] text-muted-foreground">AI يعدّل الملف مباشرة مع نسخة احتياطية تلقائية</p>
                </div>
                <button onClick={() => setAutoApply(!autoApply)} className={`w-12 h-6 rounded-full transition-all ${autoApply ? "bg-emerald-500" : "bg-secondary"}`}>
                  <div className={`w-5 h-5 bg-white rounded-full shadow transition-transform ${autoApply ? "translate-x-6" : "translate-x-0.5"}`} />
                </button>
              </div>
            </div>

            {fixResult && (
              <div className="space-y-4">
                {fixResult.applied && (
                  <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-xl p-4 flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                      <div>
                        <p className="text-sm font-bold text-emerald-400">تم الحفظ تلقائياً ✅</p>
                        {fixResult.backupPath && <p className="text-[10px] text-muted-foreground font-mono">نسخة احتياطية: {fixResult.backupPath}</p>}
                      </div>
                    </div>
                  </div>
                )}

                <div className="bg-card border border-border rounded-xl p-4">
                  <h3 className="font-bold text-sm mb-2">📝 شرح الإصلاح:</h3>
                  <p className="text-sm text-muted-foreground whitespace-pre-wrap">{fixResult.explanation}</p>
                </div>
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-2 border-b border-border bg-secondary/30">
                    <span className="text-xs font-mono text-muted-foreground">{fixFile}</span>
                    <button onClick={() => { navigator.clipboard.writeText(fixResult.fixedCode); toast.success("تم نسخ الكود المصلح"); }} className="text-xs text-primary"><Copy className="w-3 h-3 inline mr-1" />نسخ</button>
                  </div>
                  <pre className="p-4 text-xs font-mono overflow-x-auto max-h-[400px] text-foreground/80 whitespace-pre" dir="ltr">{fixResult.fixedCode}</pre>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
