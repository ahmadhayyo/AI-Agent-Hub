/*
 * HAYO AI AGENT - Landing Page
 * Design: Midnight Architect - Dark Luxury Minimalism
 * i18n: All text uses useTranslation()
 */

import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { useTranslation } from "react-i18next";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import {
  Brain, Zap, Shield, MessageSquare, GitBranch, Layers, ArrowRight, Bot, Cpu, Globe,
  Terminal, ChevronDown, Upload, FileText, BarChart3, Code2, LayoutDashboard, CreditCard,
  User, Plug, FolderOpen, Eye, FileType, ShieldCheck, Menu, X, Swords, Briefcase, Smartphone, TrendingUp, ScanSearch, GraduationCap,
} from "lucide-react";

const HAYO_LOGO = `${import.meta.env.BASE_URL ?? "/"}logo.png`;
const HERO_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663136108263/gamB6PqNYpBtJh7rZp3Wsb/hero-bg-YVVRgkSHKjvsVpBnH2UZWY.webp";
const AI_BRAIN = "https://d2xsxph8kpxj0f.cloudfront.net/310519663136108263/gamB6PqNYpBtJh7rZp3Wsb/ai-brain-NJC34aooSKWh2r9bfbx2rL.webp";
const AGENTS_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663136108263/gamB6PqNYpBtJh7rZp3Wsb/agents-illustration-TFass5NhHkfaPTw5ttAzSp.webp";
const DASHBOARD_IMG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663136108263/gamB6PqNYpBtJh7rZp3Wsb/dashboard-preview-TFbGCfSybWYKVMeWkuDYEm.webp";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  visible: (i: number) => ({ opacity: 1, y: 0, transition: { delay: i * 0.1, duration: 0.6 } }),
};

function TypeWriter({ text, speed = 50 }: { text: string; speed?: number }) {
  const [displayed, setDisplayed] = useState("");
  const [index, setIndex] = useState(0);
  useEffect(() => {
    setDisplayed("");
    setIndex(0);
  }, [text]);
  useEffect(() => {
    if (index < text.length) {
      const timer = setTimeout(() => { setDisplayed((prev) => prev + text[index]); setIndex((prev) => prev + 1); }, speed);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [index, text, speed]);
  return <span>{displayed}{index < text.length && <span className="typing-cursor" />}</span>;
}

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { t } = useTranslation();

  const agents = [
    { name: t("agents.planner"), desc: t("agents.plannerDesc"), icon: GitBranch, color: "from-indigo-500 to-blue-500" },
    { name: t("agents.worker"), desc: t("agents.workerDesc"), icon: Cpu, color: "from-emerald-500 to-teal-500" },
    { name: t("agents.critic"), desc: t("agents.criticDesc"), icon: Shield, color: "from-amber-500 to-orange-500" },
    { name: t("agents.coordinator"), desc: t("agents.coordinatorDesc"), icon: Layers, color: "from-violet-500 to-purple-500" },
  ];

  const features = [
    { icon: Brain, title: t("homeFeatures.claudeAI") || "6 نماذج AI", desc: "Claude Opus + Sonnet + Haiku • GPT-4o • DeepSeek R1 • Gemini 2.5 • Groq LLaMA • Mistral — كلها في منصة واحدة" },
    { icon: Upload, title: t("homeFeatures.fileUpload") || "تحليل 70+ صيغة", desc: "PDF, Word, Excel, PowerPoint, صور, فيديو, صوت, كود, MQ4/MQ5, أرشيف — رفع وتحليل فوري" },
    { icon: Terminal, title: t("homeFeatures.codeExec") || "وكيل كود متعدد النماذج", desc: "6 نماذج تكتب وتصلح الكود • 11 فئة • Fix All • إنشاء مشاريع كاملة" },
    { icon: BarChart3, title: t("homeFeatures.dataAnalysis") || "تداول وتحليل أسواق", desc: "9 أزواج • 3 فريمات • تنفيذ تلقائي OANDA • EA Factory لـ MQ4/MQ5" },
    { icon: MessageSquare, title: t("homeFeatures.interactiveChat") || "دردشة ذكية متعددة", desc: "7 نماذج للاختيار • رفع ملفات • تسجيل صوتي • قراءة صوتية • توليد صور" },
    { icon: Bot, title: t("homeFeatures.multiAgent") || "22+ أداة احترافية", desc: "أعمال مكتبية • دراسات 7 أقسام • بناء تطبيقات • هندسة عكسية • 35+ تكامل" },
  ];

  const quickAccessItems = [
    { icon: MessageSquare, title: t("home.qa_smartChat"), desc: t("home.qa_smartChatDesc"), href: "/chat", color: "from-blue-500 to-cyan-500", iconBg: "bg-blue-500/20" },
    { icon: Terminal, title: t("home.qa_execAgent"), desc: t("home.qa_execAgentDesc"), href: "/agent", color: "from-emerald-500 to-teal-500", iconBg: "bg-emerald-500/20" },
    { icon: Code2, title: t("home.qa_byoc"), desc: t("home.qa_byocDesc"), href: "/byoc", color: "from-orange-500 to-amber-500", iconBg: "bg-orange-500/20" },
    { icon: Swords, title: t("home.qa_warRoom"), desc: t("home.qa_warRoomDesc"), href: "/war-room", color: "from-red-500 to-rose-500", iconBg: "bg-red-500/20" },
    { icon: TrendingUp, title: t("home.qa_trading"), desc: t("home.qa_tradingDesc"), href: "/trading", color: "from-emerald-500 to-green-500", iconBg: "bg-emerald-500/20" },
    { icon: Smartphone, title: t("home.qa_appBuilder"), desc: t("home.qa_appBuilderDesc"), href: "/app-builder", color: "from-pink-500 to-rose-500", iconBg: "bg-pink-500/20" },
    { icon: ScanSearch, title: t("home.qa_reverse"), desc: t("home.qa_reverseDesc"), href: "/reverse", color: "from-orange-500 to-amber-600", iconBg: "bg-orange-500/20" },
    { icon: GraduationCap, title: t("home.qa_studies"), desc: t("home.qa_studiesDesc"), href: "/studies", color: "from-violet-600 to-purple-700", iconBg: "bg-violet-500/20" },
    { icon: Briefcase, title: t("home.qa_office"), desc: t("home.qa_officeDesc"), href: "/office", color: "from-violet-500 to-purple-500", iconBg: "bg-violet-500/20" },
    { icon: LayoutDashboard, title: t("home.qa_dashboard"), desc: t("home.qa_dashboardDesc"), href: "/dashboard", color: "from-indigo-500 to-violet-500", iconBg: "bg-indigo-500/20" },
    { icon: Eye, title: t("home.qa_preview"), desc: t("home.qa_previewDesc"), href: "/preview", color: "from-pink-500 to-rose-500", iconBg: "bg-pink-500/20" },
    { icon: FolderOpen, title: t("home.qa_myProjects"), desc: t("home.qa_myProjectsDesc"), href: "/projects", color: "from-purple-500 to-fuchsia-500", iconBg: "bg-purple-500/20" },
    { icon: FileType, title: t("home.qa_converter"), desc: t("home.qa_converterDesc"), href: "/converter", color: "from-sky-500 to-blue-500", iconBg: "bg-sky-500/20" },
    { icon: Plug, title: t("home.qa_integrations"), desc: t("home.qa_integrationsDesc"), href: "/integrations", color: "from-green-500 to-emerald-500", iconBg: "bg-green-500/20" },
    { icon: CreditCard, title: t("home.qa_pricing"), desc: t("home.qa_pricingDesc"), href: "/pricing", color: "from-yellow-500 to-orange-500", iconBg: "bg-yellow-500/20" },
    { icon: ShieldCheck, title: t("home.qa_admin"), desc: t("home.qa_adminDesc"), href: "/admin", color: "from-red-500 to-pink-500", iconBg: "bg-red-500/20" },
    { icon: User, title: t("home.qa_account"), desc: t("home.qa_accountDesc"), href: "/account", color: "from-teal-500 to-cyan-500", iconBg: "bg-teal-500/20" },
    { icon: Zap, title: t("home.qa_performance") || "EA Factory", desc: t("home.qa_performanceDesc") || "مصنع استراتيجيات MQ4/MQ5 بالذكاء الاصطناعي", href: "/ea-factory", color: "from-amber-500 to-yellow-500", iconBg: "bg-amber-500/20" },
  ];

  const navItems = [
    { href: "/chat", icon: MessageSquare, label: t("nav.chat") },
    { href: "/agent", icon: Terminal, label: t("nav.agent") },
    { href: "/byoc", icon: Code2, label: t("nav.byoc") },
    { href: "/war-room", icon: Swords, label: t("nav.warRoom") || "WarRoom" },
    { href: "/trading", icon: TrendingUp, label: t("nav.trading") || "تداول" },
    { href: "/app-builder", icon: Smartphone, label: t("nav.appBuilder") || "تطبيقات" },
    { href: "/office", icon: Briefcase, label: t("nav.office") || "مكتبية" },
    { href: "/ea-factory", icon: Cpu, label: "EA Factory" },
    { href: "/prompt-factory", icon: Brain, label: "برومبت" },
    { href: "/studies", icon: GraduationCap, label: "دراسات" },
    { href: "/integrations", icon: Plug, label: t("nav.integrations") || "تكاملات" },
    { href: "/pricing", icon: CreditCard, label: t("nav.pricing") || "أسعار" },
    { href: "/dashboard", icon: LayoutDashboard, label: t("nav.dashboard") },
  ];

  const mobileNavItems = [
    ...navItems,
    { href: "/preview", icon: Eye, label: t("nav.preview") },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/40 bg-background/80 backdrop-blur-xl">
        <div className="container flex items-center justify-between h-16">
          <Link href="/" className="flex items-center gap-3 group">
            <img src={HAYO_LOGO} alt="HAYO AI" className="w-9 h-9 rounded-lg shadow-lg shadow-indigo-500/20 group-hover:shadow-indigo-500/40 transition-shadow" />
            <span className="font-heading font-bold text-lg tracking-tight">HAYO AI</span>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden lg:flex items-center gap-1">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href} className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-all">
                <item.icon className="w-4 h-4" />
                {item.label}
              </Link>
            ))}
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2">
            <LanguageSwitcher />
            <Link href="/agent" className="hidden sm:block">
              <Button variant="outline" size="sm" className="border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10 gap-1">
                <span className="relative flex h-2 w-2"><span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span><span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span></span>
                {t("home.executiveAgent")}
              </Button>
            </Link>
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="lg:hidden p-2 rounded-lg hover:bg-accent transition-colors">
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} className="lg:hidden border-t border-border/40 bg-background/95 backdrop-blur-xl">
            <div className="container py-4 grid grid-cols-2 gap-2">
              {mobileNavItems.map((item) => (
                <Link key={item.href} href={item.href} className="flex items-center gap-2 px-3 py-2.5 rounded-lg text-sm text-muted-foreground hover:text-foreground hover:bg-accent transition-all" onClick={() => setMobileMenuOpen(false)}>
                  <item.icon className="w-4 h-4 text-indigo-400" />
                  {item.label}
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center pt-16">
        <div className="absolute inset-0 z-0">
          <img src={HERO_BG} alt="" className="w-full h-full object-cover opacity-40" />
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
        </div>

        <div className="container relative z-10 grid lg:grid-cols-2 gap-12 items-center py-20">
          <motion.div initial="hidden" animate="visible" className="space-y-8">
            <motion.div custom={0} variants={fadeUp} className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-indigo-500/30 bg-indigo-500/10 text-indigo-400 text-sm font-medium">
              <span className="w-2 h-2 rounded-full bg-indigo-400 animate-pulse" />
              {t("home.poweredBy")}
            </motion.div>

            <motion.h1 custom={1} variants={fadeUp} className="font-heading text-5xl md:text-6xl lg:text-7xl font-extrabold leading-[1.1] tracking-tight">
              <span className="block">{t("home.heroTitle1")}</span>
              <span className="block gradient-text">{t("home.heroTitle2")}</span>
            </motion.h1>

            <motion.p custom={2} variants={fadeUp} className="text-lg md:text-xl text-muted-foreground max-w-lg leading-relaxed">
              <TypeWriter text={t("home.heroDesc")} speed={30} />
            </motion.p>

            <motion.div custom={3} variants={fadeUp} className="flex flex-wrap gap-4">
              <Link href="/chat">
                <Button size="lg" className="bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white shadow-xl shadow-indigo-500/25 text-base px-8 h-12">
                  {t("home.startChat")}
                  <ArrowRight className="w-4 h-4 mr-2 rtl:rotate-180" />
                </Button>
              </Link>
              <Link href="/agent">
                <Button variant="outline" size="lg" className="border-emerald-500/50 text-emerald-400 hover:bg-emerald-500/10 text-base px-8 h-12 gap-2">
                  <Terminal className="w-4 h-4" />
                  {t("home.executiveAgent")}
                </Button>
              </Link>
              <Link href="/byoc">
                <Button variant="outline" size="lg" className="border-orange-500/50 text-orange-400 hover:bg-orange-500/10 text-base px-8 h-12 gap-2">
                  <Code2 className="w-4 h-4" />
                  {t("home.byocDev")}
                </Button>
              </Link>
            </motion.div>

            <motion.div custom={4} variants={fadeUp} className="flex items-center gap-6 pt-4">
              <div className="text-center"><div className="text-2xl font-heading font-bold text-foreground">6+</div><div className="text-xs text-muted-foreground">{t("home.smartAgents") || "نماذج AI"}</div></div>
              <div className="w-px h-8 bg-border" />
              <div className="text-center"><div className="text-2xl font-heading font-bold text-foreground">22+</div><div className="text-xs text-muted-foreground">{t("home.builtInTools") || "أداة مدمجة"}</div></div>
              <div className="w-px h-8 bg-border" />
              <div className="text-center"><div className="text-2xl font-heading font-bold text-foreground">10</div><div className="text-xs text-muted-foreground">{t("home.supportedLangs") || "لغة مدعومة"}</div></div>
              <div className="w-px h-8 bg-border" />
              <div className="text-center"><div className="text-2xl font-heading font-bold text-foreground">35+</div><div className="text-xs text-muted-foreground">{t("home.integrationsCount") || "تكامل خارجي"}</div></div>
            </motion.div>
          </motion.div>

          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.4, duration: 0.8 }} className="hidden lg:flex justify-center">
            <div className="relative">
              <div className="absolute -inset-4 bg-gradient-to-r from-indigo-500/20 to-violet-500/20 rounded-full blur-3xl" />
              <img src={AI_BRAIN} alt="HAYO AI Brain" className="relative w-[420px] h-[420px] object-contain animate-float drop-shadow-2xl" />
            </div>
          </motion.div>
        </div>

        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10">
          <a href="#quick-access"><ChevronDown className="w-6 h-6 text-muted-foreground animate-bounce" /></a>
        </div>
      </section>

      {/* Quick Access Section */}
      <section id="quick-access" className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-indigo-500/[0.02] to-transparent" />
        <div className="container relative">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-100px" }} className="text-center mb-16 space-y-4">
            <motion.span custom={0} variants={fadeUp} className="text-sm font-medium text-indigo-400 tracking-widest uppercase">{t("home.quickAccess")}</motion.span>
            <motion.h2 custom={1} variants={fadeUp} className="font-heading text-4xl md:text-5xl font-bold tracking-tight">
              {t("home.allTools").split(" ").slice(0, -2).join(" ")} <span className="gradient-text">{t("home.allTools").split(" ").slice(-2).join(" ")}</span>
            </motion.h2>
            <motion.p custom={2} variants={fadeUp} className="text-muted-foreground text-lg max-w-2xl mx-auto">{t("home.allToolsDesc")}</motion.p>
          </motion.div>

          <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {quickAccessItems.map((item, i) => (
              <motion.div key={item.href + item.title} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-30px" }} custom={i} variants={fadeUp}>
                <Link href={item.href}>
                  <div className="group glass-card rounded-xl p-5 hover:border-indigo-500/30 transition-all duration-300 hover:glow-indigo cursor-pointer h-full">
                    <div className={`w-11 h-11 rounded-lg ${item.iconBg} flex items-center justify-center mb-3 group-hover:scale-110 transition-transform`}>
                      <item.icon className="w-5 h-5 text-foreground" />
                    </div>
                    <h3 className="font-heading font-semibold text-sm mb-1 text-foreground">{item.title}</h3>
                    <p className="text-muted-foreground text-xs leading-relaxed">{item.desc}</p>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 relative">
        <div className="container">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-100px" }} className="text-center mb-16 space-y-4">
            <motion.span custom={0} variants={fadeUp} className="text-sm font-medium text-indigo-400 tracking-widest uppercase">{t("home.features")}</motion.span>
            <motion.h2 custom={1} variants={fadeUp} className="font-heading text-4xl md:text-5xl font-bold tracking-tight">
              <span className="gradient-text">{t("home.unlimitedCapabilities")}</span>
            </motion.h2>
            <motion.p custom={2} variants={fadeUp} className="text-muted-foreground text-lg max-w-2xl mx-auto">{t("home.featuresDesc")}</motion.p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {features.map((feature, i) => (
              <motion.div key={feature.title} initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-50px" }} custom={i} variants={fadeUp}
                className="group glass-card rounded-xl p-6 hover:border-indigo-500/30 transition-all duration-300 hover:glow-indigo">
                <div className="w-12 h-12 rounded-lg bg-gradient-to-br from-indigo-500/20 to-violet-500/20 flex items-center justify-center mb-4 group-hover:from-indigo-500/30 group-hover:to-violet-500/30 transition-colors">
                  <feature.icon className="w-6 h-6 text-indigo-400" />
                </div>
                <h3 className="font-heading font-semibold text-lg mb-2 text-foreground">{feature.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{feature.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Agents Section */}
      <section id="agents" className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-indigo-500/[0.03] to-transparent" />
        <div className="container relative">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-100px" }} className="text-center mb-16 space-y-4">
            <motion.span custom={0} variants={fadeUp} className="text-sm font-medium text-indigo-400 tracking-widest uppercase">{t("home.agentSystem")}</motion.span>
            <motion.h2 custom={1} variants={fadeUp} className="font-heading text-4xl md:text-5xl font-bold tracking-tight">
              <span className="gradient-text">{t("home.fourAgents")}</span>
            </motion.h2>
          </motion.div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div initial={{ opacity: 0, x: -40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.7 }}>
              <img src={AGENTS_IMG} alt="HAYO AI Agents" className="w-full rounded-2xl shadow-2xl shadow-black/30 border border-border/40" />
            </motion.div>

            <div className="space-y-4">
              {agents.map((agent, i) => (
                <motion.div key={agent.name} initial="hidden" whileInView="visible" viewport={{ once: true }} custom={i} variants={fadeUp}
                  className="glass-card rounded-xl p-5 flex items-start gap-4 hover:border-indigo-500/30 transition-all duration-300">
                  <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${agent.color} flex items-center justify-center flex-shrink-0 shadow-lg`}>
                    <agent.icon className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-heading font-semibold text-foreground">{agent.name}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{agent.desc}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Demo / Dashboard Preview */}
      <section id="demo" className="py-24 relative">
        <div className="container">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true, margin: "-100px" }} className="text-center mb-16 space-y-4">
            <motion.span custom={0} variants={fadeUp} className="text-sm font-medium text-indigo-400 tracking-widest uppercase">{t("home.demo")}</motion.span>
            <motion.h2 custom={1} variants={fadeUp} className="font-heading text-4xl md:text-5xl font-bold tracking-tight">
              <span className="gradient-text">{t("home.proDashboard")}</span>
            </motion.h2>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 40 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }} className="relative">
            <div className="absolute -inset-4 bg-gradient-to-r from-indigo-500/10 to-violet-500/10 rounded-3xl blur-2xl" />
            <div className="relative rounded-2xl overflow-hidden border border-border/40 shadow-2xl shadow-black/40">
              <img src={DASHBOARD_IMG} alt="HAYO AI Dashboard" className="w-full" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-t from-indigo-500/[0.05] to-transparent" />
        <div className="container relative">
          <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} className="glass-card rounded-2xl p-12 md:p-16 text-center space-y-6 glow-indigo">
            <motion.h2 custom={0} variants={fadeUp} className="font-heading text-3xl md:text-4xl font-bold">
              {t("home.ctaTitle")}
            </motion.h2>
            <motion.p custom={1} variants={fadeUp} className="text-muted-foreground text-lg max-w-xl mx-auto">
              {t("home.ctaDesc")}
            </motion.p>
            <motion.div custom={2} variants={fadeUp} className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link href="/chat">
                <Button size="lg" className="bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white shadow-xl shadow-indigo-500/25 text-base px-10 h-13">
                  {t("home.startFree")}
                  <ArrowRight className="w-5 h-5 mr-2 rtl:rotate-180" />
                </Button>
              </Link>
              <Link href="/agent">
                <Button size="lg" variant="outline" className="border-emerald-500/30 hover:bg-emerald-500/10 text-base px-10 h-13 gap-2">
                  <Terminal className="w-5 h-5" />
                  {t("home.executiveAgent")}
                </Button>
              </Link>
              <Link href="/pricing">
                <Button size="lg" variant="outline" className="border-indigo-500/30 hover:bg-indigo-500/10 text-base px-10 h-13">
                  {t("home.viewPricing")}
                </Button>
              </Link>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/40 py-12">
        <div className="container">
          <div className="grid md:grid-cols-3 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <img src={HAYO_LOGO} alt="HAYO AI" className="w-8 h-8 rounded-lg" />
                <span className="font-heading font-bold">HAYO AI AGENT</span>
              </div>
              <p className="text-sm text-muted-foreground">{t("home.footerDesc")}</p>
            </div>
            <div>
              <h4 className="font-heading font-semibold mb-4 text-sm">{t("home.tools")}</h4>
              <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                <Link href="/chat" className="hover:text-foreground transition-colors flex items-center gap-1.5"><MessageSquare className="w-3 h-3" /> {t("nav.chat")}</Link>
                <Link href="/agent" className="hover:text-foreground transition-colors flex items-center gap-1.5"><Terminal className="w-3 h-3" /> {t("nav.agent")}</Link>
                <Link href="/byoc" className="hover:text-foreground transition-colors flex items-center gap-1.5"><Code2 className="w-3 h-3" /> {t("nav.byoc")}</Link>
                <Link href="/converter" className="hover:text-foreground transition-colors flex items-center gap-1.5"><FileType className="w-3 h-3" /> {t("nav.converter")}</Link>
                <Link href="/projects" className="hover:text-foreground transition-colors flex items-center gap-1.5"><FolderOpen className="w-3 h-3" /> {t("nav.projects")}</Link>
                <Link href="/integrations" className="hover:text-foreground transition-colors flex items-center gap-1.5"><Plug className="w-3 h-3" /> {t("nav.integrations")}</Link>
              </div>
            </div>
            <div>
              <h4 className="font-heading font-semibold mb-4 text-sm">{t("home.accountSection")}</h4>
              <div className="grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                <Link href="/dashboard" className="hover:text-foreground transition-colors flex items-center gap-1.5"><LayoutDashboard className="w-3 h-3" /> {t("nav.dashboard")}</Link>
                <Link href="/pricing" className="hover:text-foreground transition-colors flex items-center gap-1.5"><CreditCard className="w-3 h-3" /> {t("nav.pricing")}</Link>
                <Link href="/account" className="hover:text-foreground transition-colors flex items-center gap-1.5"><User className="w-3 h-3" /> {t("nav.account")}</Link>
                <Link href="/admin" className="hover:text-foreground transition-colors flex items-center gap-1.5"><ShieldCheck className="w-3 h-3" /> {t("nav.admin")}</Link>
              </div>
            </div>
          </div>
          <div className="border-t border-border/40 pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-sm text-muted-foreground">&copy; 2025 HAYO AI AGENT. {t("home.copyright")}</p>
            <p className="text-sm text-muted-foreground">Powered by Claude • GPT-4o • DeepSeek • Gemini • Groq • Mistral</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
