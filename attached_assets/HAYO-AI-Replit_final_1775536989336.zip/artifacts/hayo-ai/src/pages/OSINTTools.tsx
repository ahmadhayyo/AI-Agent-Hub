/**
 * HAYO OSINT — أدوات الاستخبارات المفتوحة
 * 9 أدوات حقيقية مربوطة بـ APIs خارجية فعلية
 */
import { useState, useCallback } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { getLoginUrl } from "@/const";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { toast } from "sonner";
import { useTranslation } from "react-i18next";
import LanguageSwitcher from "@/components/LanguageSwitcher";
import {
  Shield, Home, Loader2, Search, Globe, Mail, User, Phone, Server,
  Lock, Network, MapPin, ExternalLink, Copy, Check, AlertTriangle,
  ChevronDown, ChevronUp, Eye, Code2, X,
} from "lucide-react";

type Tool = "ip" | "whois" | "dns" | "email" | "username" | "phone" | "tech" | "ssl" | "subdomain";

const TOOLS: Array<{ id: Tool; icon: any; label: string; desc: string; placeholder: string; color: string }> = [
  { id: "ip", icon: MapPin, label: "تحديد موقع IP", desc: "الدولة، المدينة، ISP، الإحداثيات", placeholder: "8.8.8.8", color: "from-red-500 to-orange-500" },
  { id: "whois", icon: Globe, label: "WHOIS Lookup", desc: "مالك الدومين، تاريخ التسجيل", placeholder: "example.com", color: "from-blue-500 to-cyan-500" },
  { id: "dns", icon: Server, label: "DNS Records", desc: "سجلات A, MX, TXT, NS, CNAME", placeholder: "example.com", color: "from-emerald-500 to-teal-500" },
  { id: "email", icon: Mail, label: "فحص تسريب الإيميل", desc: "هل ظهر في تسريبات بيانات؟", placeholder: "user@example.com", color: "from-violet-500 to-purple-500" },
  { id: "username", icon: User, label: "بحث اسم المستخدم", desc: "20+ موقع: GitHub, Telegram, X...", placeholder: "ahmed_dev", color: "from-pink-500 to-rose-500" },
  { id: "phone", icon: Phone, label: "فحص رقم الهاتف", desc: "الدولة، الشبكة، النوع", placeholder: "+905551234567", color: "from-amber-500 to-yellow-500" },
  { id: "tech", icon: Code2, label: "تقنيات الموقع", desc: "Framework, Server, CMS, Analytics", placeholder: "google.com", color: "from-indigo-500 to-blue-500" },
  { id: "ssl", icon: Lock, label: "شهادات SSL", desc: "سجل الشهادات والتواريخ", placeholder: "github.com", color: "from-emerald-500 to-green-500" },
  { id: "subdomain", icon: Network, label: "Subdomain Finder", desc: "اكتشاف النطاقات الفرعية", placeholder: "microsoft.com", color: "from-orange-500 to-red-500" },
];

function CopyBtn({ text }: { text: string }) {
  const [ok, setOk] = useState(false);
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setOk(true); toast.success("تم النسخ"); setTimeout(() => setOk(false), 2000); }}
      className="p-1 rounded hover:bg-secondary/50 text-muted-foreground"><Check className={`w-3 h-3 ${ok ? "text-emerald-400" : "hidden"}`} /><Copy className={`w-3 h-3 ${ok ? "hidden" : ""}`} /></button>
  );
}

function ResultCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="px-4 py-2.5 border-b border-border bg-secondary/30 flex items-center gap-2">
        <Eye className="w-4 h-4 text-primary" />
        <span className="text-sm font-bold">{title}</span>
      </div>
      <div className="p-4 text-sm space-y-2">{children}</div>
    </div>
  );
}

function DataRow({ label, value, copyable }: { label: string; value: any; copyable?: boolean }) {
  if (value === null || value === undefined || value === "") return null;
  const str = typeof value === "object" ? JSON.stringify(value) : String(value);
  return (
    <div className="flex items-start justify-between gap-2 py-1.5 border-b border-border/30 last:border-0">
      <span className="text-xs text-muted-foreground shrink-0">{label}</span>
      <div className="flex items-center gap-1">
        <span className="text-xs text-foreground text-left font-mono break-all">{str}</span>
        {copyable && <CopyBtn text={str} />}
      </div>
    </div>
  );
}

export default function OSINTPage() {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const { t } = useTranslation();
  const [activeTool, setActiveTool] = useState<Tool>("ip");
  const [input, setInput] = useState("");
  const [dnsType, setDnsType] = useState("A");
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  // tRPC mutations
  const ipMut = trpc.osint.ipLookup.useMutation();
  const whoisMut = trpc.osint.whoisLookup.useMutation();
  const dnsMut = trpc.osint.dnsLookup.useMutation();
  const emailMut = trpc.osint.emailBreachCheck.useMutation();
  const usernameMut = trpc.osint.usernameSearch.useMutation();
  const phoneMut = trpc.osint.phoneLookup.useMutation();
  const techMut = trpc.osint.techLookup.useMutation();
  const sslMut = trpc.osint.sslLookup.useMutation();
  const subMut = trpc.osint.subdomainSearch.useMutation();

  const handleSearch = useCallback(async () => {
    if (!input.trim()) { toast.error("أدخل قيمة البحث"); return; }
    setLoading(true); setResult(null);
    try {
      let data: any;
      switch (activeTool) {
        case "ip": data = await ipMut.mutateAsync({ ip: input }); break;
        case "whois": data = await whoisMut.mutateAsync({ domain: input }); break;
        case "dns": data = await dnsMut.mutateAsync({ domain: input, type: dnsType }); break;
        case "email": data = await emailMut.mutateAsync({ email: input }); break;
        case "username": data = await usernameMut.mutateAsync({ username: input }); break;
        case "phone": data = await phoneMut.mutateAsync({ phone: input }); break;
        case "tech": data = await techMut.mutateAsync({ url: input }); break;
        case "ssl": data = await sslMut.mutateAsync({ domain: input }); break;
        case "subdomain": data = await subMut.mutateAsync({ domain: input }); break;
      }
      setResult(data);
      toast.success("تم البحث بنجاح ✅");
    } catch (e: any) { toast.error(e.message || "فشل البحث"); }
    finally { setLoading(false); }
  }, [activeTool, input, dnsType]);

  const toolConfig = TOOLS.find(t => t.id === activeTool)!;

  if (authLoading) return <div className="h-screen flex items-center justify-center bg-background"><Loader2 className="w-8 h-8 animate-spin text-primary" /></div>;
  if (!isAuthenticated) return (
    <div className="h-screen flex items-center justify-center bg-background p-4">
      <div className="bg-card border border-border rounded-2xl p-8 max-w-md text-center space-y-4">
        <Shield className="w-16 h-16 mx-auto text-red-400" /><h2 className="text-2xl font-bold">OSINT Tools</h2>
        <Button asChild className="w-full"><a href={getLoginUrl()}>تسجيل الدخول</a></Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background text-foreground" dir="rtl">
      {/* Header */}
      <header className="h-12 bg-card border-b border-border flex items-center justify-between px-4 sticky top-0 z-30">
        <div className="flex items-center gap-3">
          <Link href="/" className="text-muted-foreground hover:text-primary"><Home className="w-4 h-4" /></Link>
          <div className="w-px h-5 bg-border" />
          <Shield className="w-5 h-5 text-red-400" />
          <span className="font-bold text-sm">OSINT Intelligence</span>
          <span className="text-[9px] bg-red-500/10 text-red-400 px-2 py-0.5 rounded-full">استخبارات مصادر مفتوحة</span>
        </div>
        <LanguageSwitcher />
      </header>

      <div className="max-w-6xl mx-auto p-4 md:p-6 space-y-6">
        {/* Tools Grid */}
        <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-9 gap-2">
          {TOOLS.map(tool => {
            const Icon = tool.icon;
            const active = activeTool === tool.id;
            return (
              <button key={tool.id} onClick={() => { setActiveTool(tool.id); setResult(null); setInput(""); }}
                className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-all ${active ? "bg-primary/10 border-primary/40 shadow-lg shadow-primary/10" : "border-border hover:border-primary/20 hover:bg-secondary/30"}`}>
                <div className={`w-9 h-9 rounded-lg bg-gradient-to-br ${tool.color} flex items-center justify-center`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <span className="text-[10px] font-medium text-center leading-tight">{tool.label}</span>
              </button>
            );
          })}
        </div>

        {/* Search Box */}
        <div className="bg-card border border-border rounded-2xl p-5 space-y-4">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${toolConfig.color} flex items-center justify-center shrink-0`}>
              <toolConfig.icon className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="font-bold text-lg">{toolConfig.label}</h2>
              <p className="text-xs text-muted-foreground">{toolConfig.desc}</p>
            </div>
          </div>

          <div className="flex gap-2">
            <input value={input} onChange={e => setInput(e.target.value)} placeholder={toolConfig.placeholder}
              onKeyDown={e => { if (e.key === "Enter") handleSearch(); }}
              className="flex-1 bg-secondary/50 border border-border rounded-xl px-4 py-3 text-sm font-mono focus:ring-2 focus:ring-primary/50" dir="ltr" />
            {activeTool === "dns" && (
              <select value={dnsType} onChange={e => setDnsType(e.target.value)} className="bg-secondary/50 border border-border rounded-xl px-3 text-xs">
                {["A", "AAAA", "MX", "TXT", "NS", "CNAME", "SOA", "SRV"].map(t => <option key={t}>{t}</option>)}
              </select>
            )}
            <Button onClick={handleSearch} disabled={loading || !input.trim()} className={`px-6 gap-2 bg-gradient-to-r ${toolConfig.color}`}>
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />}
              {loading ? "جاري..." : "بحث"}
            </Button>
          </div>
        </div>

        {/* Results */}
        {result && (
          <div className="space-y-4">
            {/* IP Geolocation */}
            {activeTool === "ip" && (
              <ResultCard title={`📍 موقع IP: ${result.query}`}>
                <div className="grid grid-cols-2 gap-x-6">
                  <DataRow label="الدولة" value={`${result.country} (${result.countryCode})`} />
                  <DataRow label="المنطقة" value={result.regionName} />
                  <DataRow label="المدينة" value={result.city} />
                  <DataRow label="الرمز البريدي" value={result.zip} />
                  <DataRow label="خط العرض" value={result.lat} copyable />
                  <DataRow label="خط الطول" value={result.lon} copyable />
                  <DataRow label="المنطقة الزمنية" value={result.timezone} />
                  <DataRow label="مزود الخدمة" value={result.isp} />
                  <DataRow label="المنظمة" value={result.org} />
                  <DataRow label="AS Number" value={result.as} copyable />
                  <DataRow label="موبايل" value={result.mobile ? "✅ نعم" : "❌ لا"} />
                  <DataRow label="بروكسي/VPN" value={result.proxy ? "⚠️ نعم" : "✅ لا"} />
                  <DataRow label="استضافة" value={result.hosting ? "🖥️ نعم" : "👤 لا"} />
                </div>
                <a href={`https://www.google.com/maps?q=${result.lat},${result.lon}`} target="_blank" rel="noopener"
                  className="flex items-center gap-1 text-xs text-primary mt-3 hover:underline"><MapPin className="w-3 h-3" /> فتح في Google Maps <ExternalLink className="w-3 h-3" /></a>
              </ResultCard>
            )}

            {/* WHOIS */}
            {activeTool === "whois" && (
              <ResultCard title={`🌐 WHOIS: ${result.domain}`}>
                <DataRow label="الدومين" value={result.domain} copyable />
                <DataRow label="المسجّل" value={result.registrar} />
                <DataRow label="تاريخ التسجيل" value={result.created} />
                <DataRow label="تاريخ الانتهاء" value={result.expires} />
                <DataRow label="آخر تحديث" value={result.updated} />
                <DataRow label="الحالة" value={result.status?.join(", ")} />
                <DataRow label="Nameservers" value={result.nameservers?.join(", ")} />
              </ResultCard>
            )}

            {/* DNS */}
            {activeTool === "dns" && (
              <ResultCard title={`🔍 DNS (${result.type}): ${result.domain}`}>
                {result.records?.length > 0 ? result.records.map((r: any, i: number) => (
                  <div key={i} className="flex items-center justify-between py-1 border-b border-border/30">
                    <span className="text-xs text-muted-foreground">{r.name}</span>
                    <span className="text-xs font-mono text-foreground">{r.data}</span>
                    <span className="text-[10px] text-muted-foreground">TTL: {r.ttl}</span>
                  </div>
                )) : <p className="text-xs text-muted-foreground">لا توجد سجلات {result.type}</p>}
              </ResultCard>
            )}

            {/* Email Breach */}
            {activeTool === "email" && (
              <ResultCard title={`📧 فحص تسريب: ${result.email}`}>
                <div className={`p-3 rounded-lg ${result.breached ? "bg-red-500/10 border border-red-500/20" : "bg-emerald-500/10 border border-emerald-500/20"}`}>
                  <p className={`text-sm font-bold ${result.breached ? "text-red-400" : "text-emerald-400"}`}>
                    {result.breached ? `⚠️ تم العثور على ${result.breachCount} تسريب!` : "✅ آمن — لم يُعثر على تسريبات"}
                  </p>
                </div>
                {result.breaches?.length > 0 && (
                  <div className="space-y-1 mt-2">{result.breaches.map((b: any, i: number) => (
                    <span key={i} className="inline-block text-[10px] px-2 py-1 rounded bg-red-500/10 text-red-400 ml-1">{b.Name || b}</span>
                  ))}</div>
                )}
                {result.note && <p className="text-[10px] text-muted-foreground mt-2">{result.note}</p>}
              </ResultCard>
            )}

            {/* Username Search */}
            {activeTool === "username" && (
              <ResultCard title={`👤 بحث: @${result.username}`}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {result.sites?.map((site: any, i: number) => (
                    <a key={i} href={site.url} target="_blank" rel="noopener"
                      className={`flex items-center gap-2 p-2.5 rounded-lg border transition-all hover:shadow ${site.found === true ? "bg-emerald-500/5 border-emerald-500/20" : site.found === false ? "bg-red-500/5 border-red-500/20 opacity-50" : "border-border hover:border-primary/20"}`}>
                      <span className="text-xs font-bold">{site.name}</span>
                      {site.found === true && <Check className="w-3 h-3 text-emerald-400 mr-auto" />}
                      {site.found === false && <X className="w-3 h-3 text-red-400 mr-auto" />}
                      {site.found === null && <ExternalLink className="w-3 h-3 text-muted-foreground mr-auto" />}
                      {site.info?.name && <span className="text-[10px] text-muted-foreground">{site.info.name}</span>}
                    </a>
                  ))}
                </div>
              </ResultCard>
            )}

            {/* Phone */}
            {activeTool === "phone" && (
              <ResultCard title={`📱 رقم: ${result.phone}`}>
                {result.valid !== null ? (
                  <>
                    <DataRow label="صالح" value={result.valid ? "✅ نعم" : "❌ لا"} />
                    <DataRow label="الدولة" value={result.country_name} />
                    <DataRow label="الموقع" value={result.location} />
                    <DataRow label="الشبكة" value={result.carrier} />
                    <DataRow label="النوع" value={result.line_type} />
                    <DataRow label="الكود الدولي" value={result.country_code} />
                  </>
                ) : (
                  <p className="text-xs text-muted-foreground">{result.note}</p>
                )}
              </ResultCard>
            )}

            {/* Tech Stack */}
            {activeTool === "tech" && (
              <ResultCard title={`🔧 تقنيات: ${result.domain}`}>
                <DataRow label="العنوان" value={result.title} />
                <DataRow label="الوصف" value={result.metaDesc} />
                <DataRow label="HTTP Status" value={result.statusCode} />
                <DataRow label="SSL" value={result.ssl ? "🔒 مفعّل" : "⚠️ غير مفعّل"} />
                <DataRow label="Server" value={result.headers?.server} />
                <DataRow label="Powered By" value={result.headers?.["x-powered-by"]} />
                {result.technologies?.length > 0 && (
                  <div className="mt-2"><p className="text-xs text-muted-foreground mb-1">التقنيات المكتشفة:</p>
                    <div className="flex flex-wrap gap-1">{result.technologies.map((t: string, i: number) => (
                      <span key={i} className="text-[10px] px-2 py-1 rounded-lg bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">{t}</span>
                    ))}</div>
                  </div>
                )}
              </ResultCard>
            )}

            {/* SSL */}
            {activeTool === "ssl" && (
              <ResultCard title={`🔒 شهادات SSL: ${result.domain} (${result.total} شهادة)`}>
                {result.certificates?.map((c: any, i: number) => (
                  <div key={i} className="p-2 rounded-lg border border-border/30 space-y-1 mb-2">
                    <DataRow label="الاسم" value={c.commonName} copyable />
                    <DataRow label="المُصدر" value={c.issuer} />
                    <DataRow label="من" value={c.notBefore} />
                    <DataRow label="إلى" value={c.notAfter} />
                  </div>
                ))}
              </ResultCard>
            )}

            {/* Subdomains */}
            {activeTool === "subdomain" && (
              <ResultCard title={`🌐 نطاقات فرعية: ${result.domain} (${result.count})`}>
                <div className="max-h-64 overflow-y-auto space-y-0.5">
                  {result.subdomains?.map((s: string, i: number) => (
                    <div key={i} className="flex items-center justify-between py-1 border-b border-border/20">
                      <span className="text-xs font-mono text-foreground">{s}</span>
                      <CopyBtn text={s} />
                    </div>
                  ))}
                </div>
              </ResultCard>
            )}

            {/* Raw JSON */}
            <details className="bg-card border border-border rounded-xl overflow-hidden">
              <summary className="px-4 py-2 text-xs text-muted-foreground cursor-pointer hover:bg-secondary/30">📋 عرض البيانات الخام (JSON)</summary>
              <pre className="p-4 text-[10px] font-mono text-foreground/60 overflow-x-auto max-h-60" dir="ltr">{JSON.stringify(result, null, 2)}</pre>
            </details>
          </div>
        )}
      </div>
    </div>
  );
}
