/*
 * HAYO AI — RE:PLATFORM v3.0
 * Tab 1: تحليل  Tab 2: استنساخ  Tab 3: تحرير & بناء  Tab 4: استخبارات
 * Formats: APK·EXE·DLL·EX4/5·IPA·JAR·AAR·DEX·SO·WASM
 */
import { useState, useRef, useCallback, useEffect } from "react";
import Editor from "@monaco-editor/react";
import DashboardLayout from "@/components/DashboardLayout";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import {
  Upload, FileCode2, FolderOpen, ChevronRight, ChevronDown,
  Download, Bot, Copy, Loader2, X, CheckCircle2,
  Info, Lock, Unlock, ScanSearch, Package, Cpu,
  Shield, BookOpen, Wrench, Archive, FileJson,
  Search, Save, Hammer, Binary, AlertTriangle,
  Dot, CheckCheck, Undo2, Sparkles, Eye, Zap,
  GitBranch, Globe, Key, Terminal, Scan, Fingerprint,
  ToggleLeft, ToggleRight, Rocket,
} from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";

// ═══ Types ═══
interface DecompiledFile { path:string; name:string; extension:string; size:number; content?:string; isBinary:boolean; }
interface FileTreeNode { name:string; path:string; type:"file"|"folder"; size?:number; children?:FileTreeNode[]; }
interface VulnerabilityFinding { severity:"critical"|"high"|"medium"|"low"|"info"; category:string; title:string; description:string; evidence:string[]; }
interface DecompileResult { success:boolean; fileType:string; totalFiles:number; totalSize:number; structure:FileTreeNode[]; files:DecompiledFile[]; manifest?:any; metadata?:any; downloadId?:string; error?:string; analysisAvailable:boolean; vulnerabilities?:VulnerabilityFinding[]; formatLabel?:string; }
interface EditSession { sessionId:string; structure:FileTreeNode[]; fileCount:number; apkToolAvailable:boolean; usedApkTool:boolean; fileType?:string; }
interface IntelReport { ssl:string[]; root:string[]; crypto:string[]; secrets:string[]; urls:string[]; summary:string; }
interface SmartModifyResult { modifications:Array<{filePath:string;explanation:string;originalSnippet:string;modifiedSnippet:string}>; summary:string; filesModified:number; }

// ═══ Constants ═══
const ALL_FORMATS = ["apk","exe","dll","ex4","ex5","ipa","jar","aar","dex","so","wasm"] as const;
const ACCEPT_STR = ALL_FORMATS.map(f=>`.${f}`).join(",");
const FMT_ICON:Record<string,string> = {apk:"🤖",exe:"🖥️",dll:"⚙️",ex4:"📈",ex5:"📊",ipa:"🍎",jar:"☕",aar:"🟢",dex:"🔵",so:"🔧",wasm:"🌐"};
const FMT_LABEL:Record<string,string> = {apk:"Android APK",exe:"Windows EXE",dll:"Windows DLL",ex4:"MetaTrader 4",ex5:"MetaTrader 5",ipa:"iOS IPA",jar:"Java JAR",aar:"Android AAR",dex:"Dalvik DEX",so:"Linux SO/ELF",wasm:"WebAssembly"};
const DANGER_PERMS = new Set(["READ_CONTACTS","WRITE_CONTACTS","READ_SMS","SEND_SMS","READ_PHONE_STATE","CALL_PHONE","ACCESS_FINE_LOCATION","CAMERA","RECORD_AUDIO","READ_EXTERNAL_STORAGE","WRITE_EXTERNAL_STORAGE","USE_BIOMETRIC"]);

function fileIcon(ext:string){const m:Record<string,string>={".java":"☕",".kt":"🟣",".smali":"🔩",".js":"🟨",".ts":"🟦",".xml":"📄",".json":"📋",".swift":"🦅",".c":"©️",".cpp":"➕",".cs":"🟪",".html":"🌐",".css":"🎨",".mq4":"📈",".mq5":"📊",".plist":"🍎",".txt":"📝",".pro":"📌",".properties":"⚙️",".gradle":"🔨"};return m[ext]||"📄";}
function lang(ext:string){const m:Record<string,string>={".java":"java",".kt":"kotlin",".smali":"java",".js":"javascript",".ts":"typescript",".xml":"xml",".json":"json",".html":"html",".css":"css",".swift":"swift",".c":"c",".cpp":"cpp",".cs":"csharp",".mq4":"cpp",".mq5":"cpp",".md":"markdown",".yml":"yaml",".yaml":"yaml",".properties":"ini",".gradle":"groovy"};return m[ext]||"plaintext";}
function fmtB(b:number){if(b<1024)return b+" B";if(b<1048576)return(b/1024).toFixed(1)+" KB";return(b/1048576).toFixed(1)+" MB";}

// ═══ Tree Node ═══
function TNode({node,onSelect,sel,mods,d=0}:{node:FileTreeNode;onSelect:(n:FileTreeNode)=>void;sel:string;mods?:Set<string>;d?:number}){
  const ai=node.name==="ai-decompile";
  const[open,setOpen]=useState(d<2||ai);
  if(node.type==="folder") return(<div>
    <button onClick={()=>setOpen(e=>!e)} className={`flex items-center gap-1.5 w-full text-left px-2 py-1 rounded text-sm ${ai?"hover:bg-primary/10 text-primary/80":"hover:bg-white/5"}`} style={{paddingLeft:`${8+d*14}px`}}>
      {open?<ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0"/>:<ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0"/>}
      {ai?<Sparkles className="w-3.5 h-3.5 text-primary shrink-0"/>:<FolderOpen className="w-3.5 h-3.5 text-amber-400/80 shrink-0"/>}
      <span className={ai?"text-primary font-medium truncate":"text-muted-foreground truncate"}>{node.name}</span>
    </button>
    {open&&node.children?.map((c,i)=><TNode key={i} node={c} onSelect={onSelect} sel={sel} mods={mods} d={d+1}/>)}
  </div>);
  const ext="."+( node.name.split(".").pop()||"");
  return(<button onClick={()=>onSelect(node)} className={`flex items-center gap-1.5 w-full text-left px-2 py-1 rounded text-xs ${node.path===sel?"bg-primary/20 text-primary":"hover:bg-white/5 text-muted-foreground hover:text-foreground"}`} style={{paddingLeft:`${8+d*14}px`}}>
    <span className="shrink-0 w-4 text-center text-xs">{fileIcon(ext)}</span>
    <span className="truncate">{node.name}</span>
    {mods?.has(node.path)&&<Dot className="w-4 h-4 text-yellow-400 shrink-0 ml-auto"/>}
  </button>);
}

// ═══ Vuln Panel ═══
const SC:Record<string,string>={critical:"text-red-400 bg-red-500/10 border-red-500/30",high:"text-orange-400 bg-orange-500/10 border-orange-500/30",medium:"text-yellow-400 bg-yellow-500/10 border-yellow-500/30",low:"text-blue-400 bg-blue-500/10 border-blue-500/30",info:"text-muted-foreground bg-muted/20 border-border"};
const SL:Record<string,string>={critical:"حرج",high:"عالي",medium:"متوسط",low:"منخفض",info:"معلومة"};
function VPanel({findings}:{findings:VulnerabilityFinding[]}){
  const[exp,setExp]=useState<number|null>(null);
  const ct=findings.reduce((a,f)=>{a[f.severity]=(a[f.severity]||0)+1;return a;},{} as Record<string,number>);
  return(<div className={`bg-card border rounded-xl p-3 space-y-2 ${ct.critical?"border-red-500/40":ct.high?"border-orange-500/30":"border-border"}`}>
    <div className="flex items-center gap-2"><Shield className={`w-4 h-4 ${ct.critical?"text-red-400":"text-muted-foreground"}`}/><span className="text-sm font-semibold">ثغرات</span><span className="mr-auto text-xs text-muted-foreground">{findings.length}</span></div>
    <div className="flex gap-1.5 flex-wrap">{(["critical","high","medium","low","info"] as const).map(s=>ct[s]?<span key={s} className={`text-[10px] px-2 py-0.5 rounded-full border ${SC[s]}`}>{SL[s]} ×{ct[s]}</span>:null)}</div>
    <div className="space-y-1 max-h-64 overflow-y-auto">{findings.map((f,i)=><div key={i} className={`border rounded-lg overflow-hidden ${SC[f.severity]}`}>
      <button className="w-full flex items-center gap-2 px-2.5 py-1.5 text-xs text-left" onClick={()=>setExp(exp===i?null:i)}><AlertTriangle className="w-3 h-3 shrink-0"/><span className="font-medium truncate flex-1">{f.title}</span><span className="text-[9px] opacity-60">{f.category}</span></button>
      {exp===i&&<div className="px-2.5 pb-2 text-[11px] space-y-1 border-t border-current/10"><p className="text-foreground/80 pt-1">{f.description}</p>{f.evidence.length>0&&<div className="font-mono bg-black/20 rounded p-1.5 max-h-24 overflow-y-auto">{f.evidence.map((e,j)=><div key={j} className="truncate opacity-80">{e}</div>)}</div>}</div>}
    </div>)}</div>
  </div>);
}

// ══════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ══════════════════════════════════════════════════════════════
export default function ReverseEngineer(){
  const fRef=useRef<HTMLInputElement>(null);
  const efRef=useRef<HTMLInputElement>(null);
  const cfRef=useRef<HTMLInputElement>(null);
  const editBufRef=useRef<File|null>(null);
  type Tab="analyze"|"clone"|"edit"|"intel";
  const[tab,setTab]=useState<Tab>("analyze");

  // Disclaimer
  const[disc,setDisc]=useState(()=>!localStorage.getItem("re_v3"));
  const acceptDisc=()=>{localStorage.setItem("re_v3","1");setDisc(false);};

  // ══ TAB 1: ANALYZE ══
  const[aFile,setAFile]=useState<File|null>(null);
  const[drag,setDrag]=useState(false);
  const[decomp,setDecomp]=useState(false);
  const[res,setRes]=useState<DecompileResult|null>(null);
  const[selNode,setSelNode]=useState<FileTreeNode|null>(null);
  const[selContent,setSelContent]=useState("");
  const[analyzing,setAnalyzing]=useState(false);
  const[aiText,setAiText]=useState("");
  const[showAi,setShowAi]=useState(false);
  const[dlId,setDlId]=useState("");
  const[aSessId,setASessId]=useState("");

  // ══ TAB 2: CLONE ══
  const[cFile,setCFile]=useState<File|null>(null);
  const[cloning,setCloning]=useState(false);
  const[cOpts,setCOpts]=useState({removeAds:true,unlockPremium:true,removeTracking:false,removeLicenseCheck:true,changeAppName:"",changePackageName:"",customInstructions:""});
  const[cResult,setCResult]=useState<{modifications:string[]}|null>(null);

  // ══ TAB 3: EDIT ══
  const[eFile,setEFile]=useState<File|null>(null);
  const[eDecomp,setEDecomp]=useState(false);
  const[eSess,setESess]=useState<EditSession|null>(null);
  const[eNode,setENode]=useState<FileTreeNode|null>(null);
  const[eContent,setEContent]=useState("");
  const[eOrig,setEOrig]=useState("");
  const[eMods,setEMods]=useState<Set<string>>(new Set());
  const[saving,setSaving]=useState(false);
  const[eCache,setECache]=useState<Map<string,string>>(new Map());
  const[eType,setEType]=useState("apk");
  // Smart modify
  const[smartInst,setSmartInst]=useState("");
  const[smarting,setSmarting]=useState(false);
  const[smartRes,setSmartRes]=useState<SmartModifyResult|null>(null);
  // Search
  const[sq,setSq]=useState("");
  const[searching,setSearching]=useState(false);
  const[sResults,setSResults]=useState<any[]>([]);
  // Per-file modify
  const[aiInst,setAiInst]=useState("");
  const[modifying,setModifying]=useState(false);
  const[pending,setPending]=useState<{modifiedCode:string;explanation:string}|null>(null);
  // Build
  const[building,setBuilding]=useState(false);
  const[sessMins,setSessMins]=useState(30);

  // ══ TAB 4: INTEL ══
  const[intel,setIntel]=useState<IntelReport|null>(null);
  const[intelLoading,setIntelLoading]=useState(false);
  const[irPat,setIrPat]=useState("");
  const[irRes,setIrRes]=useState<any[]>([]);
  const[irSearching,setIrSearching]=useState(false);
  const[irCat,setIrCat]=useState("");

  // Session timer
  useEffect(()=>{
    if(!eSess)return;
    const iv=setInterval(async()=>{try{const r=await fetch(`/api/reverse/session/${eSess.sessionId}`,{credentials:"include"});const d=await r.json();if(d.exists){setSessMins(d.minutesLeft);setEMods(new Set(d.modifiedPaths));}else{setESess(null);toast.error("انتهت الجلسة");}}catch{}},60000);
    return()=>clearInterval(iv);
  },[eSess]);

  // Ctrl+S
  useEffect(()=>{
    const h=(e:KeyboardEvent)=>{if((e.ctrlKey||e.metaKey)&&e.key==="s"&&tab==="edit"){e.preventDefault();doSave();}};
    window.addEventListener("keydown",h);return()=>window.removeEventListener("keydown",h);
  },[tab,eContent,eSess,eNode]);

  const valid=(f:File)=>{const e=f.name.split(".").pop()?.toLowerCase();if(!e||!ALL_FORMATS.includes(e as any)){toast.error(`صيغة غير مدعومة: .${e}`);return false;}return true;};

  // ═══ TAB 1 HANDLERS ═══
  const doDecompile=async()=>{
    if(!aFile)return;setDecomp(true);setRes(null);setAiText("");setSelNode(null);setSelContent("");
    const fd=new FormData();fd.append("file",aFile);
    try{
      const r=await fetch("/api/reverse/decompile",{method:"POST",body:fd,credentials:"include"});const d=await r.json();
      if(!r.ok){toast.error(d.error||"فشل");return;}
      setRes(d);if(d.downloadId)setDlId(d.downloadId);toast.success(`✅ ${d.totalFiles} ملف`);
      // Create session for intel
      const fd2=new FormData();fd2.append("file",aFile);
      try{const r2=await fetch("/api/reverse/decompile-for-edit",{method:"POST",body:fd2,credentials:"include"});const d2=await r2.json();if(r2.ok&&d2.sessionId)setASessId(d2.sessionId);}catch{}
    }catch(e:any){toast.error(e.message);}finally{setDecomp(false);}
  };
  const doSelNode=(n:FileTreeNode)=>{setSelNode(n);setAiText("");setShowAi(false);if(res){const f=res.files.find(f=>f.path===n.path);setSelContent(f?.content||( f?.isBinary?`[ثنائي] ${f.name}`:"لا محتوى"));}};
  const doAiAnalysis=async(type:string)=>{
    if(!selContent||selContent.startsWith("["))return;setAnalyzing(true);setShowAi(true);setAiText("");
    try{const r=await fetch("/api/reverse/analyze",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:selContent,fileName:selNode?.name,analysisType:type})});const d=await r.json();if(!r.ok){toast.error(d.error);setShowAi(false);return;}setAiText(d.analysis);}catch(e:any){toast.error(e.message);setShowAi(false);}finally{setAnalyzing(false);}
  };

  // ═══ TAB 2 HANDLERS ═══
  const doClone=async()=>{
    if(!cFile)return;setCloning(true);setCResult(null);
    const fd=new FormData();fd.append("file",cFile);
    fd.append("removeAds",String(cOpts.removeAds));fd.append("unlockPremium",String(cOpts.unlockPremium));
    fd.append("removeTracking",String(cOpts.removeTracking));fd.append("removeLicenseCheck",String(cOpts.removeLicenseCheck));
    if(cOpts.changeAppName)fd.append("changeAppName",cOpts.changeAppName);
    if(cOpts.changePackageName)fd.append("changePackageName",cOpts.changePackageName);
    if(cOpts.customInstructions)fd.append("customInstructions",cOpts.customInstructions);
    try{
      const r=await fetch("/api/reverse/clone",{method:"POST",body:fd,credentials:"include"});
      if(!r.ok){const d=await r.json();setCResult({modifications:d.modifications||[]});toast.error(d.error||"فشل");return;}
      let mods:string[]=[];try{mods=JSON.parse(r.headers.get("X-Modifications")||"[]");}catch{}
      setCResult({modifications:mods});
      const blob=await r.blob();const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;
      const ext=cFile.name.split(".").pop()?.toLowerCase();
      a.download=ext==="apk"?`cloned-${cFile.name}`:`cloned-${cFile.name}.zip`;a.click();URL.revokeObjectURL(url);
      toast.success(r.headers.get("X-APK-Signed")==="true"?"🎉 استنساخ + توقيع — جاهز!":"✅ تم الاستنساخ");
    }catch(e:any){toast.error(e.message);}finally{setCloning(false);}
  };

  // ═══ TAB 3 HANDLERS ═══
  const doEditDecomp=async()=>{
    if(!eFile)return;setEDecomp(true);setESess(null);setECache(new Map());setENode(null);setEContent("");
    editBufRef.current=eFile;const fd=new FormData();fd.append("file",eFile);
    try{const r=await fetch("/api/reverse/decompile-for-edit",{method:"POST",body:fd,credentials:"include"});const d=await r.json();if(!r.ok){toast.error(d.error);return;}setESess(d);setEType(d.fileType||"apk");setEMods(new Set());setSessMins(30);toast.success(`✅ ${d.fileCount} ملف [${(d.fileType||"apk").toUpperCase()}]`);}catch(e:any){toast.error(e.message);}finally{setEDecomp(false);}
  };

  const loadFile=useCallback(async(node:FileTreeNode)=>{
    if(node.type==="folder")return;setENode(node);setPending(null);
    if(eCache.has(node.path)){const c=eCache.get(node.path)!;setEContent(c);setEOrig(c);return;}
    if(!eSess)return;
    try{const r=await fetch("/api/reverse/file-content",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:eSess.sessionId,filePath:node.path})});const d=await r.json();if(!r.ok){setEContent(`[خطأ: ${d.error}]`);return;}const c=d.content??"";setECache(p=>new Map(p).set(node.path,c));setEContent(c);setEOrig(c);}catch{setEContent("[تعذر القراءة]");}
  },[eCache,eSess]);

  const doSave=async()=>{
    if(!eSess||!eNode)return;setSaving(true);
    try{const r=await fetch("/api/reverse/save-edit",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:eSess.sessionId,filePath:eNode.path,content:eContent})});const d=await r.json();if(!r.ok){toast.error(d.error);return;}setEMods(p=>new Set(p).add(eNode.path));setEOrig(eContent);setECache(p=>new Map(p).set(eNode.path,eContent));toast.success("✅ حفظ");}catch(e:any){toast.error(e.message);}finally{setSaving(false);}
  };

  const doSmartModify=async()=>{
    if(!eSess||!smartInst.trim())return;setSmarting(true);setSmartRes(null);
    try{const r=await fetch("/api/reverse/ai-smart-modify",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:eSess.sessionId,instruction:smartInst})});const d=await r.json();if(!r.ok){toast.error(d.error);return;}setSmartRes(d);if(d.filesModified>0){const i=await(await fetch(`/api/reverse/session/${eSess.sessionId}`,{credentials:"include"})).json();if(i.exists)setEMods(new Set(i.modifiedPaths));}toast.success(`✅ ${d.filesModified} ملف`);}catch(e:any){toast.error(e.message);}finally{setSmarting(false);}
  };

  const doSearch=async()=>{
    if(!sq.trim()||!eSess)return;setSearching(true);setSResults([]);
    try{const r=await fetch("/api/reverse/ai-search",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:eSess.sessionId,query:sq})});const d=await r.json();if(!r.ok){toast.error(d.error);return;}setSResults(d.results);}catch(e:any){toast.error(e.message);}finally{setSearching(false);}
  };

  const doAiModify=async()=>{
    if(!eContent||!aiInst||!eNode)return;setModifying(true);setPending(null);
    try{const r=await fetch("/api/reverse/ai-modify",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:eContent,instruction:aiInst,fileName:eNode.name})});const d=await r.json();if(!r.ok){toast.error(d.error);return;}setPending(d);}catch(e:any){toast.error(e.message);}finally{setModifying(false);}
  };
  const applyMod=()=>{if(!pending)return;setEContent(pending.modifiedCode);setPending(null);toast.success("تطبيق — اضغط حفظ");};

  const doBuild=async()=>{
    if(!eSess||eMods.size===0){toast.error("لا تعديلات!");return;}setBuilding(true);
    try{const r=await fetch("/api/reverse/rebuild",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:eSess.sessionId})});if(!r.ok){const d=await r.json();throw new Error(d.error);}const blob=await r.blob();const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=r.headers.get("X-APK-Signed")==="true"?"modified-signed.apk":`modified.${eType==="apk"?"apk":"zip"}`;a.click();URL.revokeObjectURL(url);toast.success(r.headers.get("X-APK-Signed")==="true"?"🎉 APK موقّع!":"✅ بناء");}catch(e:any){toast.error(e.message);}finally{setBuilding(false);}
  };

  // ═══ TAB 4 HANDLERS ═══
  const iSess=eSess?.sessionId||aSessId;
  const doIntel=async()=>{
    if(!iSess){toast.error("افتح ملفاً أولاً");return;}setIntelLoading(true);setIntel(null);
    try{const r=await fetch("/api/reverse/intelligence-report",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:iSess})});const d=await r.json();if(!r.ok){toast.error(d.error);return;}setIntel(d);}catch(e:any){toast.error(e.message);}finally{setIntelLoading(false);}
  };
  const doRegex=async(pat?:string,cat?:string)=>{
    if(!iSess)return;setIrSearching(true);setIrRes([]);
    try{const r=await fetch("/api/reverse/regex-search",{method:"POST",credentials:"include",headers:{"Content-Type":"application/json"},body:JSON.stringify({sessionId:iSess,pattern:pat||irPat,category:cat})});const d=await r.json();if(!r.ok){toast.error(d.error);return;}setIrRes(d.results);}catch(e:any){toast.error(e.message);}finally{setIrSearching(false);}
  };

  // ═══ RENDER ═══
  const tabs:{id:Tab;label:string;icon:any}[]=[{id:"analyze",label:"تحليل",icon:Eye},{id:"clone",label:"استنساخ",icon:GitBranch},{id:"edit",label:"تحرير & بناء",icon:Hammer},{id:"intel",label:"استخبارات",icon:Fingerprint}];

  return(<DashboardLayout>
    {/* Disclaimer */}
    <Dialog open={disc} onOpenChange={()=>{}}><DialogContent className="max-w-md" dir="rtl"><DialogHeader><DialogTitle className="flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-amber-400"/>تنبيه قانوني</DialogTitle><DialogDescription asChild><div className="text-right text-sm space-y-2"><span className="block">للاستخدام المشروع فقط:</span><span className="block text-emerald-400 text-xs">✅ تفكيك تطبيقاتك · استعادة كود · تحليل أمني</span><span className="block text-red-400 text-xs">❌ تطبيقات الآخرين بدون إذن</span></div></DialogDescription></DialogHeader><DialogFooter><Button onClick={acceptDisc} className="w-full">أوافق</Button></DialogFooter></DialogContent></Dialog>

    <div className="flex flex-col h-full p-4 gap-4" dir="rtl">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="relative"><div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500/30 to-cyan-500/30 flex items-center justify-center border border-emerald-500/30"><ScanSearch className="w-5 h-5 text-emerald-400"/></div><span className="absolute -top-1 -left-1 text-[8px] font-bold bg-emerald-500 text-black px-1 rounded">v3</span></div>
        <div><h1 className="text-lg font-bold tracking-wide">RE:PLATFORM</h1><p className="text-[10px] text-muted-foreground font-mono tracking-widest">{ALL_FORMATS.map(f=>f.toUpperCase()).join(" · ")}</p></div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-muted/30 rounded-xl p-1 self-start border border-border">
        {tabs.map(t=><button key={t.id} onClick={()=>setTab(t.id)} className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab===t.id?"bg-card shadow text-foreground border border-border":"text-muted-foreground hover:text-foreground"}`}><t.icon className="w-4 h-4"/>{t.label}</button>)}
        {eSess&&<span className="self-center text-[10px] text-muted-foreground mr-2">⏱{sessMins}م</span>}
      </div>

      {/* ═══ TAB 1: ANALYZE ═══ */}
      {tab==="analyze"&&<div className="flex-1 grid grid-cols-1 lg:grid-cols-[280px_240px_1fr] gap-4 min-h-0">
        {/* Upload + Info */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center gap-2 text-xs text-muted-foreground bg-emerald-500/5 border border-emerald-500/20 rounded-lg px-3 py-2"><Info className="w-3.5 h-3.5 text-emerald-400 shrink-0"/><span>تفكيك <b className="text-emerald-300">5</b> · تحليل <b className="text-emerald-300">3</b> نقاط</span></div>
          <div className={`border-2 border-dashed rounded-2xl p-5 text-center cursor-pointer transition-all ${drag?"border-emerald-400 bg-emerald-500/10":"border-border hover:border-emerald-400/50"}`} onDragOver={e=>{e.preventDefault();setDrag(true);}} onDragLeave={()=>setDrag(false)} onDrop={e=>{e.preventDefault();setDrag(false);const f=e.dataTransfer.files[0];if(f&&valid(f)){setAFile(f);setRes(null);}}} onClick={()=>fRef.current?.click()}>
            <input ref={fRef} type="file" accept={ACCEPT_STR} className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f&&valid(f)){setAFile(f);setRes(null);}}}/>
            {aFile?<div className="space-y-2"><div className="text-3xl">{FMT_ICON[aFile.name.split(".").pop()?.toLowerCase()||""]||"📦"}</div><p className="font-medium text-sm truncate">{aFile.name}</p><p className="text-xs text-muted-foreground">{fmtB(aFile.size)}</p><button onClick={e=>{e.stopPropagation();setAFile(null);setRes(null);}} className="text-xs text-red-400"><X className="w-3 h-3 inline"/>تغيير</button></div>
            :<div className="space-y-2"><Upload className="w-8 h-8 mx-auto text-muted-foreground"/><p className="text-sm font-medium">اسحب أو انقر</p><p className="text-[10px] text-muted-foreground">{ALL_FORMATS.map(f=>f.toUpperCase()).join(" · ")}</p></div>}
          </div>
          {aFile&&!res&&<Button onClick={doDecompile} disabled={decomp} className="w-full gap-2 bg-emerald-600 hover:bg-emerald-700 py-5">{decomp?<><Loader2 className="w-4 h-4 animate-spin"/>تفكيك...</>:<><Binary className="w-4 h-4"/>تفكيك</>}</Button>}
          {res&&<div className="bg-card border border-emerald-500/30 rounded-xl p-3 space-y-2">
            <div className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400"/><span className="font-semibold text-sm">تم</span>{dlId&&<Button size="sm" variant="outline" onClick={()=>window.open(`/api/reverse/download/${dlId}`,"_blank")} className="mr-auto h-7 text-xs gap-1"><Archive className="w-3 h-3"/>ZIP</Button>}</div>
            <div className="grid grid-cols-2 gap-1.5 text-xs"><div className="bg-muted/30 rounded p-2 text-center"><div className="font-bold text-emerald-300">{res.totalFiles}</div><div className="text-muted-foreground">ملف</div></div><div className="bg-muted/30 rounded p-2 text-center"><div className="font-bold text-emerald-300">{fmtB(res.totalSize)}</div><div className="text-muted-foreground">حجم</div></div></div>
            {res.metadata?.aiModelUsed&&<div className="rounded-lg bg-primary/10 border border-primary/30 px-2 py-1.5 flex items-center gap-1.5"><Sparkles className="w-3 h-3 text-primary"/><div><div className="text-primary font-semibold text-[11px]">AI عميق</div><div className="text-muted-foreground text-[10px]">{res.metadata.aiModelUsed}</div></div></div>}
          </div>}
          {res?.manifest?.permissions?.length>0&&<div className="bg-card border border-border rounded-xl p-3 space-y-2"><div className="flex items-center gap-2 text-sm font-semibold"><FileJson className="w-4 h-4 text-blue-400"/>صلاحيات</div><div className="max-h-32 overflow-y-auto space-y-0.5">{res.manifest.permissions.map((p:string)=><div key={p} className="flex items-center gap-1.5 text-xs">{DANGER_PERMS.has(p)?<Unlock className="w-3 h-3 text-red-400"/>:<Lock className="w-3 h-3 text-muted-foreground"/>}<span className={DANGER_PERMS.has(p)?"text-red-300":"text-muted-foreground"}>{p}</span></div>)}</div></div>}
          {res?.vulnerabilities&&res.vulnerabilities.length>0&&<VPanel findings={res.vulnerabilities}/>}
        </div>
        {/* Tree */}
        <div className="bg-card border border-border rounded-2xl overflow-hidden flex flex-col">
          <div className="flex items-center gap-2 px-3 py-2.5 border-b border-border bg-muted/20"><FolderOpen className="w-4 h-4 text-amber-400"/><span className="text-sm font-medium">الملفات</span>{res&&<span className="mr-auto text-xs text-muted-foreground">{res.totalFiles}</span>}</div>
          <div className="flex-1 overflow-y-auto p-1">{!res?<div className="flex flex-col items-center justify-center h-full py-12 text-muted-foreground text-sm"><FolderOpen className="w-10 h-10 mb-2 opacity-20"/><p>ارفع ملفاً</p></div>:res.structure.map((n,i)=><TNode key={i} node={n} onSelect={doSelNode} sel={selNode?.path||""}/>)}</div>
        </div>
        {/* Viewer */}
        <div className="flex flex-col gap-3 min-h-0">
          <div className="bg-card border border-border rounded-2xl overflow-hidden flex flex-col" style={{minHeight:"300px",flex:1}}>
            <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-muted/20 shrink-0">
              <FileCode2 className="w-4 h-4 text-primary"/><span className="text-sm font-medium truncate flex-1">{selNode?.name||"اختر ملفاً"}</span>
              {selContent&&!selContent.startsWith("[")&&<div className="flex items-center gap-1">
                <DropdownMenu><DropdownMenuTrigger asChild><Button size="sm" variant="outline" disabled={analyzing} className="gap-1.5 h-7 px-2 text-xs border-primary/30"><Bot className="w-3.5 h-3.5 text-primary"/>AI<ChevronDown className="w-3 h-3"/></Button></DropdownMenuTrigger><DropdownMenuContent align="start" className="w-40 z-50"><DropdownMenuItem onClick={()=>doAiAnalysis("explain")} className="gap-2 text-xs cursor-pointer"><BookOpen className="w-3 h-3"/>شرح</DropdownMenuItem><DropdownMenuItem onClick={()=>doAiAnalysis("security")} className="gap-2 text-xs cursor-pointer"><Shield className="w-3 h-3 text-red-400"/>أمني</DropdownMenuItem><DropdownMenuItem onClick={()=>doAiAnalysis("logic")} className="gap-2 text-xs cursor-pointer"><Wrench className="w-3 h-3 text-blue-400"/>منطق</DropdownMenuItem><DropdownMenuItem onClick={()=>doAiAnalysis("full")} className="gap-2 text-xs cursor-pointer"><Bot className="w-3 h-3 text-primary"/>شامل</DropdownMenuItem></DropdownMenuContent></DropdownMenu>
                <Button size="sm" variant="ghost" onClick={()=>{navigator.clipboard.writeText(selContent);toast.success("نسخ");}} className="h-7 w-7 p-0"><Copy className="w-3.5 h-3.5"/></Button>
                <Button size="sm" variant="ghost" onClick={()=>{const b=new Blob([selContent],{type:"text/plain"});const u=URL.createObjectURL(b);const a=document.createElement("a");a.href=u;a.download=selNode?.name||"file";a.click();}} className="h-7 w-7 p-0"><Download className="w-3.5 h-3.5"/></Button>
              </div>}
            </div>
            <div className="flex-1 overflow-auto">{selContent?<pre className="p-4 text-xs font-mono leading-relaxed whitespace-pre-wrap break-all">{selContent}</pre>:<div className="flex flex-col items-center justify-center h-full text-muted-foreground"><FileCode2 className="w-10 h-10 mb-3 opacity-20"/><p className="text-sm">اختر ملفاً</p></div>}</div>
          </div>
          {showAi&&<div className="bg-card border border-primary/30 rounded-2xl overflow-hidden flex flex-col" style={{maxHeight:"380px"}}><div className="flex items-center gap-2 px-3 py-2.5 border-b border-border bg-primary/5 shrink-0"><Bot className="w-4 h-4 text-primary"/><span className="text-sm font-medium">AI</span><Button size="sm" variant="ghost" onClick={()=>setShowAi(false)} className="mr-auto h-6 w-6 p-0"><X className="w-3 h-3"/></Button></div><div className="flex-1 overflow-y-auto p-4 text-sm leading-relaxed">{analyzing?<div className="flex items-center gap-3 justify-center py-12 text-muted-foreground"><Loader2 className="w-5 h-5 animate-spin text-primary"/>يحلل...</div>:<div className="whitespace-pre-wrap">{aiText}</div>}</div></div>}
        </div>
      </div>}

      {/* ═══ TAB 2: CLONE ═══ */}
      {tab==="clone"&&<div className="flex-1 flex flex-col gap-4 max-w-3xl mx-auto w-full">
        <div className="text-center space-y-2"><div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-violet-500/30 to-pink-500/30 flex items-center justify-center border border-violet-500/30"><GitBranch className="w-7 h-7 text-violet-400"/></div><h2 className="text-xl font-bold">App Cloner</h2><p className="text-sm text-muted-foreground">تفكيك → تعديل → توقيع → بناء تلقائي</p></div>
        <div className="border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer hover:border-violet-400/50 transition-all" onClick={()=>cfRef.current?.click()}>
          <input ref={cfRef} type="file" accept={ACCEPT_STR} className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f&&valid(f))setCFile(f);}}/>
          {cFile?<div className="space-y-2"><span className="text-3xl">{FMT_ICON[cFile.name.split(".").pop()?.toLowerCase()||""]||"📦"}</span><p className="font-medium">{cFile.name}</p><p className="text-sm text-muted-foreground">{fmtB(cFile.size)}</p><button onClick={e=>{e.stopPropagation();setCFile(null);setCResult(null);}} className="text-xs text-red-400"><X className="w-3 h-3 inline"/>تغيير</button></div>
          :<div className="space-y-2"><Upload className="w-8 h-8 mx-auto text-muted-foreground"/><p className="text-sm">اسحب أو انقر</p><p className="text-xs text-muted-foreground">{ALL_FORMATS.map(f=>f.toUpperCase()).join(" · ")}</p></div>}
        </div>
        <div className="grid grid-cols-2 gap-3">
          {([["removeAds","إزالة الإعلانات","🚫","AdMob, Facebook, Unity"],["unlockPremium","فتح المدفوع","🔓","isPremium, isSubscribed"],["removeTracking","إزالة التتبع","📡","Firebase, Analytics"],["removeLicenseCheck","تجاوز الرخصة","🔑","checkLicense, verifySignature"]] as const).map(([k,l,ic,d])=><button key={k} onClick={()=>setCOpts(p=>({...p,[k]:!p[k as keyof typeof p]}))} className={`p-3 rounded-xl border text-right transition-all ${cOpts[k as keyof typeof cOpts]?"bg-violet-500/10 border-violet-500/40 text-violet-300":"bg-card border-border text-muted-foreground hover:border-violet-500/30"}`}><div className="flex items-center gap-2"><span className="text-lg">{ic}</span><span className="font-medium text-sm">{l}</span><span className="mr-auto">{cOpts[k as keyof typeof cOpts]?<ToggleRight className="w-5 h-5 text-violet-400"/>:<ToggleLeft className="w-5 h-5"/>}</span></div><p className="text-[10px] mt-1 opacity-60">{d}</p></button>)}
        </div>
        <div className="grid grid-cols-2 gap-3">
          <input value={cOpts.changeAppName} onChange={e=>setCOpts(p=>({...p,changeAppName:e.target.value}))} placeholder="اسم جديد (اختياري)" className="bg-muted/30 border border-border rounded-lg px-3 py-2 text-sm text-right placeholder:text-muted-foreground/50 focus:outline-none focus:border-violet-500/50"/>
          <input value={cOpts.changePackageName} onChange={e=>setCOpts(p=>({...p,changePackageName:e.target.value}))} placeholder="حزمة جديدة (اختياري)" className="bg-muted/30 border border-border rounded-lg px-3 py-2 text-sm text-right placeholder:text-muted-foreground/50 focus:outline-none focus:border-violet-500/50 font-mono"/>
        </div>
        <textarea value={cOpts.customInstructions} onChange={e=>setCOpts(p=>({...p,customInstructions:e.target.value}))} placeholder="تعليمات إضافية للذكاء الاصطناعي..." rows={2} className="bg-muted/30 border border-border rounded-lg px-3 py-2 text-sm text-right placeholder:text-muted-foreground/50 resize-none"/>
        <Button onClick={doClone} disabled={!cFile||cloning} className="w-full gap-2 py-6 text-base bg-gradient-to-r from-violet-600 to-pink-600 hover:from-violet-500 hover:to-pink-500">{cloning?<><Loader2 className="w-5 h-5 animate-spin"/>جاري الاستنساخ...</>:<><Rocket className="w-5 h-5"/>استنساخ الآن</>}</Button>
        {cResult&&<div className="bg-card border border-border rounded-xl p-4 space-y-2"><div className="text-sm font-semibold flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-emerald-400"/>سجل التعديلات</div><div className="max-h-48 overflow-y-auto space-y-1">{cResult.modifications.map((m,i)=><div key={i} className="text-xs text-muted-foreground bg-muted/20 rounded px-2 py-1">{m}</div>)}</div></div>}
      </div>}

      {/* ═══ TAB 3: EDIT & BUILD ═══ */}
      {tab==="edit"&&<div className="flex-1 flex flex-col gap-4 min-h-0">
        <div className="flex items-center gap-2 flex-wrap">
          <Button variant="outline" size="sm" className="gap-2 h-9" onClick={()=>efRef.current?.click()}><Upload className="w-4 h-4"/>{eFile?eFile.name.slice(0,20)+"…":"رفع ملف"}</Button>
          <input ref={efRef} type="file" accept={ACCEPT_STR} className="hidden" onChange={e=>{const f=e.target.files?.[0];if(f&&valid(f)){setEFile(f);editBufRef.current=f;setESess(null);setECache(new Map());setENode(null);setEContent("");}}}/>
          {eFile&&!eSess&&<Button onClick={doEditDecomp} disabled={eDecomp} size="sm" className="gap-2 bg-emerald-600 h-9">{eDecomp?<><Loader2 className="w-4 h-4 animate-spin"/>تفكيك...</>:<><Binary className="w-4 h-4"/>فتح</>}</Button>}
          {eSess&&eNode&&<Button onClick={doSave} disabled={saving} size="sm" variant="outline" className="gap-2 h-9 border-emerald-500/30">{saving?<Loader2 className="w-4 h-4 animate-spin"/>:<Save className="w-4 h-4 text-emerald-400"/>}حفظ</Button>}
          {eSess&&<Button onClick={doBuild} disabled={building||eMods.size===0} size="sm" className="gap-2 bg-primary h-9 mr-auto">{building?<><Loader2 className="w-4 h-4 animate-spin"/>بناء...</>:<><Hammer className="w-4 h-4"/>بناء ({eMods.size})</>}</Button>}
        </div>
        <div className="flex-1 grid grid-cols-1 lg:grid-cols-[260px_1fr_280px] gap-4 min-h-0" style={{minHeight:"500px"}}>
          {/* Tree + Search */}
          <div className="flex flex-col gap-3 min-h-0">
            <div className="bg-card border border-border rounded-xl p-3 space-y-2">
              <div className="text-xs font-semibold flex items-center gap-1.5"><Search className="w-3.5 h-3.5 text-primary"/>بحث ذكي</div>
              <div className="flex gap-1"><input value={sq} onChange={e=>setSq(e.target.value)} onKeyDown={e=>e.key==="Enter"&&doSearch()} placeholder="ابحث عن: الدفع، الإعلانات..." className="flex-1 bg-muted/30 border border-border rounded-lg px-2 py-1.5 text-xs text-right placeholder:text-muted-foreground/50" disabled={!eSess||searching}/><Button size="sm" onClick={doSearch} disabled={!eSess||searching||!sq.trim()} className="h-8 w-8 p-0">{searching?<Loader2 className="w-3.5 h-3.5 animate-spin"/>:<Search className="w-3.5 h-3.5"/>}</Button></div>
              {sResults.length>0&&<div className="space-y-1 max-h-40 overflow-y-auto">{sResults.map((r,i)=><button key={i} onClick={()=>{const fn=(ns:FileTreeNode[],p:string):FileTreeNode|null=>{for(const n of ns){if(n.path===p)return n;if(n.children){const f=fn(n.children,p);if(f)return f;}}return null;};if(eSess){const nd=fn(eSess.structure,r.path);if(nd)loadFile(nd);}}} className="w-full text-right text-xs bg-muted/20 hover:bg-muted/40 rounded p-2 border border-border"><div className="font-medium text-foreground/80 truncate">{r.path}</div><div className="text-muted-foreground mt-0.5">{r.relevance}</div></button>)}</div>}
            </div>
            <div className="bg-card border border-border rounded-xl overflow-hidden flex flex-col flex-1 min-h-0">
              <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-muted/20 shrink-0"><FolderOpen className="w-3.5 h-3.5 text-amber-400"/><span className="text-xs font-medium">الملفات</span>{eMods.size>0&&<span className="mr-auto text-[10px] px-1.5 py-0.5 bg-yellow-500/20 text-yellow-300 rounded-full">{eMods.size}</span>}</div>
              <div className="flex-1 overflow-y-auto p-1">{!eSess?<div className="flex flex-col items-center justify-center h-full py-10 text-muted-foreground text-sm"><Package className="w-8 h-8 mb-2 opacity-20"/><p>ارفع ملف</p></div>:eSess.structure.map((n,i)=><TNode key={i} node={n} onSelect={loadFile} sel={eNode?.path||""} mods={eMods}/>)}</div>
            </div>
          </div>
          {/* Editor */}
          <div className="bg-card border border-border rounded-2xl overflow-hidden flex flex-col min-h-0">
            <div className="flex items-center gap-2 px-3 py-2 border-b border-border bg-muted/20 shrink-0">
              <FileCode2 className="w-4 h-4 text-primary"/><span className="text-sm font-medium truncate flex-1">{eNode?.name||"اختر ملفاً"}</span>
              {eNode&&eMods.has(eNode.path)&&<span className="text-[10px] px-1.5 py-0.5 bg-yellow-500/20 text-yellow-300 rounded-full">معدّل</span>}
              {pending&&<div className="flex items-center gap-1 mr-auto"><Button size="sm" onClick={applyMod} className="h-6 text-xs gap-1 bg-emerald-600 px-2"><CheckCheck className="w-3 h-3"/>تطبيق</Button><Button size="sm" variant="ghost" onClick={()=>setPending(null)} className="h-6 w-6 p-0 text-red-400"><X className="w-3 h-3"/></Button></div>}
            </div>
            {eNode&&!eContent.startsWith("[")?<div className="flex-1 min-h-0"><Editor height="100%" language={lang("."+(eNode.name.split(".").pop()||""))} value={eContent} onChange={v=>v!==undefined&&setEContent(v)} theme="vs-dark" options={{fontSize:12,minimap:{enabled:false},wordWrap:"on",scrollBeyondLastLine:false,automaticLayout:true,readOnly:!eSess,lineNumbers:"on",folding:true,tabSize:2}}/></div>
            :<div className="flex-1 flex flex-col items-center justify-center text-muted-foreground"><FileCode2 className="w-10 h-10 mb-3 opacity-20"/><p className="text-sm">اختر ملفاً</p></div>}
          </div>
          {/* AI Panel */}
          <div className="flex flex-col gap-3 min-h-0">
            {/* Smart Modify */}
            <div className="bg-card border border-primary/20 rounded-xl p-3 space-y-3 shrink-0">
              <div className="text-sm font-semibold flex items-center gap-1.5"><Sparkles className="w-4 h-4 text-primary"/>تعديل ذكي شامل</div>
              <p className="text-[10px] text-muted-foreground">اكتب ما تريد — AI يبحث ويعدل تلقائياً</p>
              <div className="flex flex-wrap gap-1.5">{["أزل الإعلانات","افتح المدفوع","غيّر الاسم","أزل التتبع"].map(q=><button key={q} onClick={()=>setSmartInst(q)} className="text-xs px-2 py-1 bg-muted/30 hover:bg-muted/60 rounded-md border border-border text-muted-foreground hover:text-foreground">{q}</button>)}</div>
              <textarea value={smartInst} onChange={e=>setSmartInst(e.target.value)} placeholder="اكتب تعليماتك..." rows={3} className="w-full bg-muted/30 border border-border rounded-lg px-3 py-2 text-xs text-right placeholder:text-muted-foreground/50 resize-none" disabled={!eSess||smarting}/>
              <Button onClick={doSmartModify} disabled={!eSess||smarting||!smartInst.trim()} className="w-full gap-2 text-sm">{smarting?<><Loader2 className="w-4 h-4 animate-spin"/>يعدّل...</>:<><Zap className="w-4 h-4"/>تنفيذ</>}</Button>
            </div>
            {smartRes&&<div className="bg-card border border-emerald-500/30 rounded-xl p-3 space-y-2 max-h-48 overflow-y-auto"><div className="text-xs font-semibold text-emerald-300">✅ {smartRes.filesModified} ملف</div><p className="text-xs text-muted-foreground">{smartRes.summary}</p>{smartRes.modifications.map((m,i)=><div key={i} className="text-[11px] bg-muted/20 rounded p-2"><div className="font-mono text-emerald-300/80">{m.filePath}</div><div className="text-muted-foreground">{m.explanation}</div></div>)}</div>}
            {eNode&&<div className="bg-card border border-border rounded-xl p-3 space-y-2"><div className="text-xs font-semibold flex items-center gap-1.5"><Bot className="w-3.5 h-3.5"/>تعديل هذا الملف</div><textarea value={aiInst} onChange={e=>setAiInst(e.target.value)} placeholder="تعليمات..." rows={2} className="w-full bg-muted/30 border border-border rounded-lg px-3 py-2 text-xs text-right placeholder:text-muted-foreground/50 resize-none" disabled={modifying}/><Button onClick={doAiModify} disabled={modifying||!aiInst.trim()} size="sm" className="w-full gap-2 text-xs">{modifying?<Loader2 className="w-3 h-3 animate-spin"/>:<Bot className="w-3 h-3"/>}تعديل</Button></div>}
            {eSess&&<div className="bg-card border border-border rounded-xl p-3 text-xs space-y-1.5 mt-auto"><div className="font-semibold text-muted-foreground">الجلسة</div><div className="flex justify-between"><span className="text-muted-foreground">معدّلة</span><span className="text-yellow-300">{eMods.size}</span></div><div className="flex justify-between"><span className="text-muted-foreground">وقت</span><span className={sessMins<5?"text-red-400":"text-emerald-400"}>{sessMins}م</span></div><div className="flex justify-between"><span className="text-muted-foreground">نوع</span><span className="text-emerald-300">{eType.toUpperCase()}</span></div></div>}
          </div>
        </div>
      </div>}

      {/* ═══ TAB 4: INTEL ═══ */}
      {tab==="intel"&&<div className="flex-1 flex flex-col gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-gradient-to-br from-cyan-500/20 to-blue-500/20 border border-cyan-500/20"><Fingerprint className="w-5 h-5 text-cyan-400"/></div>
          <div><h2 className="text-lg font-bold">لوحة الاستخبارات</h2><p className="text-xs text-muted-foreground">APIs · URLs · مفاتيح · تشفير · بيانات حساسة</p></div>
          <Button onClick={doIntel} disabled={intelLoading||!iSess} size="sm" className="mr-auto gap-2 bg-cyan-600 hover:bg-cyan-700">{intelLoading?<Loader2 className="w-4 h-4 animate-spin"/>:<Scan className="w-4 h-4"/>}فحص</Button>
        </div>
        {!iSess&&<div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4 text-center text-sm text-amber-300"><AlertTriangle className="w-5 h-5 mx-auto mb-2"/>افتح ملفاً في التحليل أو التحرير أولاً</div>}
        {intel&&<div className="grid grid-cols-2 md:grid-cols-5 gap-3">
          {([["ssl","SSL/TLS",Lock,"text-red-400 bg-red-500/10 border-red-500/30"],["root","Root",Terminal,"text-orange-400 bg-orange-500/10 border-orange-500/30"],["crypto","Crypto",Key,"text-yellow-400 bg-yellow-500/10 border-yellow-500/30"],["secrets","Secrets",Fingerprint,"text-purple-400 bg-purple-500/10 border-purple-500/30"],["urls","URLs",Globe,"text-blue-400 bg-blue-500/10 border-blue-500/30"]] as const).map(([k,l,Ic,cls])=><button key={k} onClick={()=>{setIrCat(k);doRegex("",k);}} className={`p-3 rounded-xl border transition-all hover:scale-105 ${cls}`}><Ic className="w-5 h-5 mx-auto mb-1"/><div className="text-2xl font-bold">{intel[k as keyof IntelReport]?.length||0}</div><div className="text-xs font-medium">{l}</div></button>)}
        </div>}
        <div className="bg-card border border-border rounded-xl p-3 space-y-2">
          <div className="flex items-center gap-2"><Search className="w-4 h-4 text-cyan-400"/><span className="text-sm font-semibold">بحث Regex</span></div>
          <div className="flex gap-2"><input value={irPat} onChange={e=>setIrPat(e.target.value)} onKeyDown={e=>e.key==="Enter"&&doRegex()} placeholder="api[_-]?key|password" className="flex-1 bg-muted/30 border border-border rounded-lg px-3 py-2 text-sm font-mono text-right placeholder:text-muted-foreground/50" disabled={!iSess||irSearching}/><Button onClick={()=>doRegex()} disabled={!iSess||irSearching||!irPat.trim()}>{irSearching?<Loader2 className="w-4 h-4 animate-spin"/>:<Search className="w-4 h-4"/>}</Button></div>
          <div className="flex flex-wrap gap-1.5">{["SSL","Root","Crypto","Secrets","URLs"].map(c=><button key={c} onClick={()=>{setIrCat(c.toLowerCase());doRegex("",c.toLowerCase());}} className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${irCat===c.toLowerCase()?"bg-cyan-500/20 border-cyan-500/40 text-cyan-300":"bg-muted/30 border-border text-muted-foreground hover:text-foreground"}`}>{c}</button>)}</div>
        </div>
        {irRes.length>0&&<div className="bg-card border border-border rounded-xl overflow-hidden">
          <div className="px-3 py-2 border-b border-border bg-muted/20 flex items-center gap-2"><Terminal className="w-3.5 h-3.5 text-cyan-400"/><span className="text-xs font-semibold">{irRes.length} نتيجة</span></div>
          <div className="max-h-96 overflow-y-auto divide-y divide-border/50">{irRes.map((r,i)=><div key={i} className="px-3 py-2 hover:bg-muted/10"><div className="flex items-center gap-2 text-xs"><span className="text-cyan-400 font-mono truncate max-w-[200px]">{r.filePath}</span><span className="text-muted-foreground">:{r.line}</span><span className="mr-auto text-emerald-400 font-medium">{r.match}</span></div><div className="text-[11px] font-mono text-muted-foreground mt-0.5 truncate">{r.context}</div></div>)}</div>
        </div>}
        {intel&&irCat&&(intel[irCat as keyof IntelReport] as string[])?.length>0&&<div className="bg-card border border-border rounded-xl p-3 space-y-2 max-h-64 overflow-y-auto"><div className="text-sm font-semibold">{irCat.toUpperCase()}</div>{(intel[irCat as keyof IntelReport] as string[]).map((item,i)=><div key={i} className="text-xs font-mono bg-muted/20 rounded px-2 py-1 truncate text-muted-foreground">{item}</div>)}</div>}
      </div>}
    </div>
  </DashboardLayout>);
}
