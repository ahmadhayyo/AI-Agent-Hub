# HAYO AI AGENT — Workspace

## Overview

Full-stack AI agent SaaS platform (Arabic-first). pnpm monorepo with TypeScript throughout.

## Stack

- **Monorepo**: pnpm workspaces
- **Node.js**: 24 | **TypeScript**: 5.9 | **Package manager**: pnpm
- **Frontend**: React 18 + Vite + TailwindCSS + shadcn/ui (RTL Arabic)
- **Backend**: Express 5 + tRPC v11
- **Database**: PostgreSQL + Drizzle ORM
- **Auth**: JWT cookies via `jose` (email/password; first user = admin)
- **AI**: Multi-model via `llm.ts` streaming router — claude-sonnet-4-6 (default), gpt-4o, deepseek-chat, gemini-2.5-flash, groq-llama, mistral-large all supported in Chat; claude-haiku-4-5 for office tasks; claude-sonnet for App Builder code gen
- **App Builder**: Expo EAS Build integration (EXPO_ACCESS_TOKEN secret, account: ahmet80) — generates React Native APKs from natural language descriptions
- **Validation**: Zod v4

## Structure

```
artifacts/
├── api-server/          # Express + tRPC backend (port 8080)
│   └── src/hayo/
│       ├── router.ts    # All tRPC procedures (auth/conv/chat/agent/files/plans/admin)
│       ├── auth.ts      # JWT cookie auth (jose)
│       ├── db.ts        # PostgreSQL database operations
│       └── llm.ts       # Replit Anthropic AI integration
├── hayo-ai/             # React + Vite frontend (Arabic RTL)
│   └── src/             # 114 React pages/components
└── mockup-sandbox/      # Component preview server (canvas)

lib/
└── db/
    └── src/schema/index.ts   # Drizzle PostgreSQL schema (all tables)

shared/
└── const.ts             # COOKIE_NAME, UNAUTHED_ERR_MSG
```

## Key Features

- **AI Chat**: Multi-turn conversations with Claude AI (Arabic + English)
- **Multi-agent routing**: Agent, Agentic Executive, Dashboard/Analytics
- **Subscription plans**: Free / Basic ($19) / Pro ($49) — seeded in DB
- **Auth**: Email/password JWT; first registered = admin
- **File uploads**: PDF, Word, Excel, ZIP handling
- **Admin panel**: User management, plan management, code generation & management
- **BYOC**: Bring Your Own Code environment
- **Projects & Files**: Project management with file browser
- **Integrations**: GitHub, Google Drive (OAuth scaffolding) — fully rebuilt with multi-field dialog + test connection
- **Office Suite** (`/office`): 6-tab page (File Converter, PowerPoint AI, Word Reports, Excel Editor, AI Tools, OCR)
  - `POST /api/office/generate-pptx` — AI-powered PPTX with charts/tables/twoCol slides (Sonnet, ~50s, with progress bar)
  - `POST /api/office/generate-report` — Word DOCX from markdown AI output (Haiku, ~32s, with progress bar)
  - `POST /api/office/convert` — File format conversion (PDF/DOCX/XLSX/CSV/JSON/MD/HTML/PNG→various); PDF uses pdf-parse v2 (PDFParse class, load()+getText()); pdf-parse externalized in build.mjs
  - `POST /api/office/process-excel` — Excel AI analysis returning JSON + base64 xlsx
  - `POST /api/office/run-tool` — 6 AI tools: summarize/translate/grammar (Haiku), email/minutes/letter (Sonnet)
  - `POST /api/office/text-to-docx` — Convert plain text to DOCX (used by OCR download + AI Tools download)
  - Office routes are **public** (no auth required)
- **Reverse Engineering** (`/reverse`): Full binary analysis platform — 11 formats supported
- **HAYO THINK** (`/studies`): Strategic AI consultant — 4 categories (Engineering 🏗️, Commerce 💰, Investment 📊, General 🔬), SVG floor plans, DOCX export, follow-up Q&A. Powered by `callPowerAI` (Claude Opus → Gemini → Sonnet → DeepSeek). Routes: `POST /api/studies/generate`, `/follow-up`, `/export-docx`
  - **Supported Formats**: APK, EXE, DLL, EX4 (MT4), EX5 (MT5), IPA (iOS), JAR, AAR, DEX, SO/ELF, WASM
  - **Tab 1 — Analysis**: Upload any format → dedicated analyzer → AI analysis (explain/security/logic/full), file tree, format-specific metadata, vulnerability scanner (10 categories with severity levels), download ZIP
  - **Tab 2 — Edit & Build**: APKTool/format decompile → Monaco Editor → AI search → AI code modification → Rebuild
  - **Legal Disclaimer**: One-time dialog before entering
  - **Vulnerability Panel**: collapsible findings (critical/high/medium/low/info), evidence display, color-coded borders
  - **Credits**: `reverse_decompile:5`, `reverse_analyze:3`, `reverse_edit_session:10`, `reverse_ai_modify:3`, `reverse_ai_search:2`, `reverse_rebuild:5`
  - **APKTool 2.11.1** + **Java 21 (OpenJDK)** + readelf/strings/objdump/nm/file installed via Nix
  - **Backend**: `reverse-engineer.ts` service (~2500 lines) + endpoints in `routes/reverse.ts`
- **مصنع البرومبت / Prompt Factory** (`/prompt-factory`): AI-powered professional prompt generator
  - User writes any request → selects category (9 types) + target model (optional) → `callPowerAI()` generates full prompt package
  - **Output sections**: Professional prompt (copyable) + customizable variables + technical explanation + execution steps + recommended models + advanced tips + expected output example
  - **AI Model**: Uses `callPowerAI()` fallback chain: claude-opus-4-5 → gemini-2.5-pro → claude-sonnet-4-6 → gpt-4o → deepseek-reasoner
  - **Categories**: coding, creative, research, business, education, chat, analysis, SEO/content, e-commerce
  - **Backend**: `routes/prompt-factory.ts` → POST `/api/prompt-factory/generate` (auth required, no credits cost)
- **Project Completion Screen**: Full-page `/completion?id=...` route shows after code generation — displays project stats, file list with code preview, ZIP download, Copy Link, Share, BYOC, GitHub push, Vercel deploy buttons. Data stored in `localStorage` key `hayo-projects`; CodeAgent navigates to `/completion?id={projectId}` on success

## Subscription Code System (HAYO Business Model)

- **Business model**: Free tier → user pays → admin generates code → user redeems → 30-day access with credits
- **Code format**: `HAYO-XXXXXX-XXXXXX` (hex uppercase, 12 hex chars)
- **DB table**: `subscriptionCodes` — stores code, planId, durationDays, createdBy, usedBy, usedAt, expiresAt
- **Plans** (seeded): free (5 cred/day), starter (30 cred/day), pro (100 cred/day), business (400 cred/day)
- **Backend procedures**:
  - `codes.generate` (admin only) — generates 1-50 codes per call
  - `codes.list` (admin only) — all codes with status, user, plan info
  - `codes.deactivate` (admin only) — cancel unused code
  - `subscriptions.myActive` — user's active subscription from codes
  - `subscriptions.redeem` — validate & activate code, set 30-day expiry
  - `subscriptions.checkLimit` — check today's usage vs plan limit
  - `usage.credits` — daily credit usage, limit, and cost map
  - `system.makeAdmin` (admin) — promote user to admin role
- **Credits system** (db.ts):
  - `CREDIT_COSTS`: chat=2, war_room=10, agent_pipeline=30, pptx_generate=5, report_generate=6, office_tool=1
  - `checkCredits(userId, operation)` — checks daily credit limit before operation
  - `deductCredits(userId, operation)` — deducts credits + increments message count
- **Frontend**:
  - `CreditsBar` component: shows daily credits used/remaining with color-coded bar (green→amber→red)
  - Added to `/chat` page sidebar
  - `/payment` page: "لديك كود اشتراك؟" collapsible section, enter code → auto-redirect to chat
  - `/admin` panel: "كودات الاشتراك" tab — generate, view, copy, deactivate codes
- **Limit enforcement**: War Room checks credits before running (TOO_MANY_REQUESTS if exceeded)
- **Keep-alive**: server pings `/api/healthz` every 4 minutes to prevent Replit idle freeze
- **Payment info**: PayPal `fmf0038@gmail.com`, USDT ERC-20 / ETH `0x787e...`, USDT TRC-20 `TX92p...`, BTC `3DDVW...`
- **Contact for activation**: email `fmf0038@gmail.com` + Telegram `@fmf0038`

## Admin Info

- **Owner email**: `Fmf0038@gmail.com` (hard-coded as admin via `OWNER_EMAIL` constant in `db.ts`)
- **Password**: `6088amhA+` (or set `OWNER_PASSWORD` env var to override)
- **Owner seed**: `seedOwnerAccount()` runs at startup — creates owner account if not exists, restores admin role if downgraded
- **Admin panel**: `/admin` route
- **Telegram bot**: Bot integration support
- **i18n**: Arabic (primary) + English + 10+ languages
- **Logo**: AI brain logo at `artifacts/hayo-ai/public/logo.png` (generated, used via `${BASE_URL}logo.png`)

## tRPC Procedures

| Namespace | Procedures |
|-----------|-----------|
| `auth` | `login`, `register`, `logout`, `me` |
| `conversations` | `list`, `create`, `get`, `delete`, `update` |
| `chat` | `send` (calls Claude AI) |
| `agent` | `run` (agentic execution) |
| `files` | `upload`, `list`, `delete` |
| `plans` | `list` |
| `admin` | `users.list`, `plans.update` |

## Database Tables

`users`, `conversations`, `messages`, `files`, `plans`, `userPlans`, `integrations`, `projects`, `projectFiles`, `usageLogs`, `apiKeys`, `telegramBots`

## Development

```bash
# Start backend (port 8080)
pnpm --filter @workspace/api-server run dev

# Start frontend
pnpm --filter @workspace/hayo-ai run dev

# Push DB schema
pnpm --filter @workspace/db run push

# Seed default plans
pnpm --filter @workspace/scripts run seed-plans
```

## Environment Variables

- `DATABASE_URL` — PostgreSQL connection (auto-provided by Replit)
- `SESSION_SECRET` — JWT signing secret
- `AI_INTEGRATIONS_ANTHROPIC_API_KEY` — Free Anthropic API via Replit
- `AI_INTEGRATIONS_ANTHROPIC_BASE_URL` — Replit AI proxy URL

## Auth Notes

- Cookie name: `app_session_id` (set in `shared/const.ts`)
- First registered user automatically becomes `admin` role
- JWT expiry: 30 days
- Password hashed with SHA-256

## TypeScript

Every package extends `tsconfig.base.json` (`composite: true`). Run `pnpm run typecheck` from root to build the full dependency graph.
