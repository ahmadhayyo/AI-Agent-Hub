const { ipcRenderer } = require('electron');
  const FORMATS = ['APK','EXE','DLL','MSI','EX4','EX5','IPA','JAR','AAR','DEX','SO','WASM'];
  const FMT_ICON = {apk:'📱',exe:'💻',dll:'🔧',msi:'📦',ex4:'📊',ex5:'📊',ipa:'🍎',jar:'☕',aar:'📚',dex:'🤖',so:'⚙️',wasm:'🌐'};

  let state = { mode:'home', serverUrl:'', anthropicKey:'', deepseekKey:'', geminiKey:'', connected:false, loading:false, file:null, result:null, selectedFile:null };

  function toast(msg, type) {
    const t = document.createElement('div');
    t.className = 'toast toast-' + (type||'success');
    t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(() => t.remove(), 3000);
  }

  async function init() {
    const s = await ipcRenderer.invoke('get-settings');
    Object.assign(state, s);
    state.connected = !!state.serverUrl;
    render();
    ipcRenderer.on('show-settings', () => { state.mode = 'settings'; render(); });
    ipcRenderer.on('open-file', () => selectFile());
  }

  async function selectFile() {
    const f = await ipcRenderer.invoke('select-file');
    if (!f) return;
    state.file = f; state.result = null; state.mode = 'home'; render();
    analyzeFile();
  }

  async function analyzeFile() {
    if (!state.file) return;
    if (!state.serverUrl) { toast('اضبط رابط السيرفر في الإعدادات', 'error'); return; }
    state.loading = true; render();
    try {
      const r = await fetch(state.serverUrl + '/api/reverse/decompile', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileBase64: state.file.base64, fileName: state.file.name }),
      });
      if (!r.ok) throw new Error('فشل التحليل: ' + r.status);
      state.result = await r.json();
      toast('تم التحليل بنجاح ✅');
    } catch (e) { toast(e.message, 'error'); }
    state.loading = false; render();
  }

  async function cloneApp() {
    if (!state.file || !state.serverUrl) return;
    const newPkg = prompt('اسم الحزمة الجديد:', 'com.hayo.clone');
    const newName = prompt('اسم التطبيق الجديد:', 'Cloned App');
    if (!newPkg || !newName) return;
    state.loading = true; render();
    try {
      const r = await fetch(state.serverUrl + '/api/reverse/clone', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fileBase64: state.file.base64, fileName: state.file.name, newPackageName: newPkg, newAppName: newName }),
      });
      if (!r.ok) throw new Error('فشل الاستنساخ');
      const d = await r.json();
      if (d.downloadId) {
        const a = document.createElement('a');
        a.href = state.serverUrl + '/api/reverse/download/' + d.downloadId;
        a.download = newName + '.apk';
        a.click();
        toast('تم الاستنساخ! جاري التحميل...');
      }
    } catch (e) { toast(e.message, 'error'); }
    state.loading = false; render();
  }

  async function saveSettings() {
    const s = {
      serverUrl: document.getElementById('s-url')?.value?.trim() || '',
      anthropicKey: document.getElementById('s-anthropic')?.value?.trim() || '',
      deepseekKey: document.getElementById('s-deepseek')?.value?.trim() || '',
      geminiKey: document.getElementById('s-gemini')?.value?.trim() || '',
    };
    await ipcRenderer.invoke('save-settings', s);
    Object.assign(state, s);
    state.connected = !!s.serverUrl;
    state.mode = state.connected ? 'home' : 'home';
    toast('تم حفظ الإعدادات ✅');
    render();
  }

  function formatBytes(b) { if(b<1024)return b+' B';if(b<1048576)return(b/1024).toFixed(1)+' KB';return(b/1048576).toFixed(1)+' MB'; }
  function escapeHtml(s) { return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  function getFileIcon(name) {
    const ext = name.split('.').pop()?.toLowerCase();
    const m = {java:'☕',kt:'🟣',xml:'📄',json:'📋',txt:'📝',md:'📖',smali:'🔧',yml:'⚙️',properties:'🔧',html:'🌐',css:'🎨',js:'💛',asm:'⚙️',wat:'🌐',c:'⚡',h:'📎'};
    return m[ext] || '📄';
  }

  function renderTree(nodes, depth) {
    depth = depth || 0;
    return nodes.map(function(n) {
      if (n.type === 'folder') {
        return '<div class="folder" style="padding-right:' + (depth*12) + 'px" onclick="this.nextElementSibling.style.display=this.nextElementSibling.style.display===\'none\'?\'block\':\'none\'">📂 ' + n.name + '</div><div style="display:' + (depth<1?'block':'none') + '">' + renderTree(n.children||[], depth+1) + '</div>';
      }
      return '<div class="file" style="padding-right:' + (depth*12) + 'px" onclick="showFile(\'' + (n.path||'').replace(/'/g,"\\\'") + '\')">' + getFileIcon(n.name) + ' ' + n.name + '</div>';
    }).join('');
  }

  function showFile(filePath) {
    const f = (state.result?.files || []).find(function(x){return x.path === filePath;});
    const el = document.getElementById('file-content');
    if (!el) return;
    if (!f || !f.content) { el.innerHTML = '<div class="result-card"><p style="color:var(--muted)">ملف ثنائي — لا يمكن عرضه</p></div>'; return; }
    state.selectedFile = f;
    el.innerHTML = '<div class="result-card"><h3>' + getFileIcon(f.name) + ' ' + f.path + ' <span style="font-size:10px;color:var(--muted);font-weight:400">' + formatBytes(f.content.length) + '</span></h3><div class="code-view">' + escapeHtml(f.content.substring(0, 200000)) + '</div></div>';
  }

  function handleDrop(e) {
    e.preventDefault();
    const files = e.dataTransfer?.files;
    if (!files?.length) return;
    const f = files[0];
    const reader = new FileReader();
    reader.onload = function() {
      const b64 = reader.result.toString().split(',')[1] || '';
      state.file = { name: f.name, base64: b64, size: f.size };
      render();
      analyzeFile();
    };
    reader.readAsDataURL(f);
  }

  function render() {
    const app = document.getElementById('app');
    let h = '<div class="header">';
    h += '<div class="logo">🔬<span class="ver">v4</span></div>';
    h += '<div><div class="title">HAYO AI RE:TOOLKIT</div>';
    h += '<div class="subtitle">منصة الهندسة العكسية المتقدمة بالذكاء الاصطناعي</div>';
    h += '<div class="formats">' + FORMATS.map(function(f){return '<span class="fmt">'+f+'</span>';}).join('') + '</div></div>';
    h += '<div class="actions">';
    h += '<button class="btn" onclick="selectFile()">📂 فتح ملف</button>';
    if (state.result && state.file?.name?.endsWith('.apk')) h += '<button class="btn" onclick="cloneApp()">📋 استنساخ</button>';
    h += '<button class="btn" onclick="state.mode=\'webview\';render()">🌐 المنصة</button>';
    h += '<button class="btn" onclick="state.mode=\'settings\';render()">⚙️</button>';
    h += '</div></div>';

    if (state.mode === 'settings') {
      h += '<div class="settings-overlay" onclick="if(event.target===this){state.mode=\'home\';render();}"><div class="settings-panel">';
      h += '<h2>⚙️ إعدادات HAYO AI RE:TOOLKIT</h2>';
      h += '<div class="field"><label>🌐 رابط سيرفر HAYO AI</label><input id="s-url" type="url" placeholder="https://your-app.replit.app" value="' + (state.serverUrl||'') + '"/></div>';
      h += '<hr style="border-color:var(--border);margin:16px 0"/>';
      h += '<p style="font-size:12px;color:var(--primary);margin-bottom:12px">🔑 مفاتيح AI (اختياري)</p>';
      h += '<div class="field"><label>🟣 Claude Opus 4.6 (Anthropic)</label><input id="s-anthropic" type="password" placeholder="sk-ant-..." value="' + (state.anthropicKey||'') + '"/></div>';
      h += '<div class="field"><label>🔵 DeepSeek</label><input id="s-deepseek" type="password" placeholder="sk-..." value="' + (state.deepseekKey||'') + '"/></div>';
      h += '<div class="field"><label>🟢 Gemini Pro 3</label><input id="s-gemini" type="password" placeholder="AIza..." value="' + (state.geminiKey||'') + '"/></div>';
      h += '<div style="display:flex;gap:8px;margin-top:16px"><button class="btn btn-primary" onclick="saveSettings()">💾 حفظ</button><button class="btn" onclick="state.mode=\'home\';render()">إلغاء</button></div>';
      h += '</div></div>';
    }

    if (state.mode === 'webview' && state.serverUrl) {
      h += '<div class="webview-container"><iframe src="' + state.serverUrl + '/reverse-engineer" allow="clipboard-write"></iframe></div>';
    } else if (state.loading) {
      h += '<div class="content" style="display:flex;flex-direction:column;align-items:center;justify-content:center;flex:1">';
      h += '<div class="loader" style="width:48px;height:48px;border-width:4px;margin-bottom:16px"></div>';
      h += '<div style="font-size:16px;font-weight:600">جاري تحليل ' + (state.file?.name||'') + '...</div>';
      h += '<div class="progress" style="width:300px;margin-top:12px"><div class="progress-bar" style="width:60%"></div></div>';
      h += '</div>';
    } else if (state.result && state.result.success) {
      const r = state.result;
      h += '<div class="main"><div class="sidebar">';
      h += '<div style="font-size:12px;font-weight:700;margin-bottom:8px;color:var(--primary)">📁 الملفات (' + r.totalFiles + ')</div>';
      h += '<div class="file-tree">' + renderTree(r.structure || []) + '</div>';
      h += '</div><div class="content">';
      h += '<div style="display:flex;gap:12px;margin-bottom:16px;flex-wrap:wrap">';
      h += '<div class="result-card" style="flex:1;min-width:120px;text-align:center"><div style="font-size:28px">' + (FMT_ICON[r.fileType]||'📦') + '</div><div style="font-size:11px;color:var(--muted);margin-top:4px">' + (r.formatLabel||r.fileType?.toUpperCase()) + '</div></div>';
      h += '<div class="result-card" style="flex:1;min-width:120px;text-align:center"><div style="font-size:24px;font-weight:700;color:var(--primary)">' + r.totalFiles + '</div><div style="font-size:11px;color:var(--muted)">ملف</div></div>';
      h += '<div class="result-card" style="flex:1;min-width:120px;text-align:center"><div style="font-size:24px;font-weight:700;color:#06b6d4">' + formatBytes(r.totalSize||0) + '</div><div style="font-size:11px;color:var(--muted)">الحجم</div></div>';
      if (r.vulnerabilities) h += '<div class="result-card" style="flex:1;min-width:120px;text-align:center"><div style="font-size:24px;font-weight:700;color:#ef4444">' + r.vulnerabilities.length + '</div><div style="font-size:11px;color:var(--muted)">ثغرات</div></div>';
      h += '</div><div id="file-content"><div class="result-card"><p style="color:var(--muted);text-align:center">اختر ملفاً من الشجرة لعرضه</p></div></div>';
      h += '</div></div>';
    } else {
      h += '<div class="drop-zone" onclick="selectFile()" ondragover="event.preventDefault();this.classList.add(\'active\')" ondragleave="this.classList.remove(\'active\')" ondrop="handleDrop(event)">';
      h += '<div class="drop-icon">🔬</div><div class="drop-text">اسحب ملفاً هنا أو انقر للاختيار</div>';
      h += '<div class="drop-sub">APK · EXE · DLL · IPA · JAR · DEX · SO · WASM · EX4/5</div>';
      h += '<div class="drop-sub" style="margin-top:8px">حتى 500 ميغابايت</div>';
      if (!state.connected) h += '<div style="margin-top:16px;padding:8px 16px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:8px;font-size:11px;color:#ef4444">⚠️ اضبط رابط السيرفر في الإعدادات (⚙️) أولاً</div>';
      if (state.result && !state.result.success) h += '<div style="margin-top:12px;padding:8px 16px;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:8px;font-size:11px;color:#ef4444">❌ ' + (state.result.error||'فشل') + '</div>';
      h += '</div>';
    }

    h += '<div class="status"><span class="dot ' + (state.connected?'dot-green':'dot-red') + '"></span>';
    h += '<span>' + (state.connected ? 'متصل' : 'غير متصل') + '</span>';
    if (state.file) h += '<span>📄 ' + state.file.name + ' (' + formatBytes(state.file.size) + ')</span>';
    if (state.loading) h += '<span class="loader"></span>';
    h += '</div>';
    app.innerHTML = h;
  }

  init();
  