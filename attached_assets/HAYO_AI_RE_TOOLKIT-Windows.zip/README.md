# HAYO AI RE:TOOLKIT
## منصة الهندسة العكسية المتقدمة بالذكاء الاصطناعي

### التثبيت والتشغيل
```bash
npm install
npm start
```

### بناء ملف EXE (Windows)
```bash
npm install
npm run build
```

### الميزات
- تحليل 12+ صيغة: APK, EXE, DLL, IPA, JAR, DEX, SO, WASM, EX4/5
- ذكاء اصطناعي: Claude Opus 4.6, DeepSeek, Gemini Pro 3
- تفكيك + تعديل + بناء + توقيع + استنساخ
- واجهة عربية RTL

© 2025 HAYO AI