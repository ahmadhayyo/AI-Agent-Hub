const { app, BrowserWindow, Menu, ipcMain, dialog, shell } = require('electron');
const path = require('path');
const fs = require('fs');
const SETTINGS_PATH = path.join(app.getPath('userData'), 'settings.json');
function loadSettings() { try { return JSON.parse(fs.readFileSync(SETTINGS_PATH, 'utf8')); } catch { return { serverUrl: '', anthropicKey: '', deepseekKey: '', geminiKey: '' }; } }
function saveSettings(s) { fs.writeFileSync(SETTINGS_PATH, JSON.stringify(s, null, 2)); }
let mainWin;
function createWindow() {
  mainWin = new BrowserWindow({
    width: 1400, height: 900, minWidth: 900, minHeight: 600,
    title: 'HAYO AI RE:TOOLKIT', icon: path.join(__dirname, 'assets', 'icon.png'),
    backgroundColor: '#0a0a0f',
    webPreferences: { nodeIntegration: true, contextIsolation: false },
    autoHideMenuBar: true,
  });
  mainWin.loadFile('src/index.html');
}
ipcMain.handle('get-settings', () => loadSettings());
ipcMain.handle('save-settings', (_, s) => { saveSettings(s); return true; });
ipcMain.handle('select-file', async () => {
  const r = await dialog.showOpenDialog(mainWin, { properties: ['openFile'],
    filters: [
      { name: 'All Supported', extensions: ['apk','exe','dll','msi','ex4','ex5','ipa','jar','aar','dex','so','wasm','o','elf'] },
      { name: 'Android', extensions: ['apk','dex','aar'] },
      { name: 'Windows', extensions: ['exe','dll','msi'] },
      { name: 'Native', extensions: ['so','elf','o','wasm'] },
    ],
  });
  if (r.canceled || !r.filePaths.length) return null;
  const fp = r.filePaths[0];
  const buf = fs.readFileSync(fp);
  return { name: path.basename(fp), base64: buf.toString('base64'), size: buf.length };
});
app.whenReady().then(() => {
  const menu = [
    { label: 'ملف', submenu: [
      { label: 'فتح ملف...', accelerator: 'CmdOrCtrl+O', click: () => mainWin?.webContents.send('open-file') },
      { type: 'separator' },
      { label: 'الإعدادات', accelerator: 'CmdOrCtrl+,', click: () => mainWin?.webContents.send('show-settings') },
      { type: 'separator' },
      { label: 'خروج', role: 'quit' },
    ]},
    { label: 'عرض', submenu: [
      { label: 'ملء الشاشة', role: 'togglefullscreen' },
      { label: 'أدوات المطور', role: 'toggleDevTools' },
      { label: 'تكبير', role: 'zoomIn' },
      { label: 'تصغير', role: 'zoomOut' },
    ]},
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(menu));
  createWindow();
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });